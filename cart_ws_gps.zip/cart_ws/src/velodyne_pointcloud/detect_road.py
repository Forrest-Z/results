#!/usr/bin/env python2
# -*- coding: utf-8 -*-

"""Detects road points from LiDAR point cloud.
Find the transform values(yaw, pitch, roll, x, y, z) and publish topic `/dof_ip`.
eg:
rostopic pub /dof_ip std_msgs/String "data: '0,0.19,0,0,0,2'"

Transformed point cloud using `/dof_ip` published as `/transformed_pc`.
Road points published at `road_pc`.
Overlayed road points on filtered point cloud at `detected_road_pc`.
Thresholded heatmap of road at `road_heatmap`.

Dependencies:
tensorflow-gpu==1.4.0
Keras==2.1.4
numpy==1.15.4
CUDA==8.0.61
"""
__authors__ = "Thomas Paul, Nagarjuna Vemuri"
__credits__ = ["Nahas Pareekutty", "Mohan Kamatam", "Navin Rawther",
			"Aravindh K"]
__version__ = "0.1"

# run below command before running this script.
# rostopic pub /dof_ip std_msgs/String "data: '0,0.19,0,0,0,2'"

# # GPU warning silencer- Just disables the warning, doesn't enable AVX/FMA
import os
import sys
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import rospy
import ros_numpy
from std_msgs.msg import String
from sensor_msgs.msg import PointCloud2, Image
from geometry_msgs.msg import TransformStamped
from tf2_sensor_msgs.tf2_sensor_msgs import do_transform_cloud
from tf.transformations import quaternion_from_euler

import numpy as np
import keras
import tensorflow as tf
import ros_numpy
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats

## profile things
# import cProfile, pstats, StringIO

print '''
###############################################
## LIDAR ROAD DETECTION
###############################################

Detects road points from lidar point cloud.

Before running, find the transformation values(yaw, pitch, roll, x, y, z) and publish topic `/dof_ip`.
eg: rostopic pub /dof_ip std_msgs/String "data: '0,0.19,0,0,0,2'"

Transformed point cloud using `/dof_ip` is published as `/transformed_pc`.
Road points published as `/road_pc`.
Overlayed road points on filtered point cloud as `/detected_road_pc`.
Thresholded heatmap of road as `/road_heatmap`.

Dependencies:
tensorflow-gpu==1.4.0
Keras==2.1.4
numpy==1.15.4
CUDA==8.0.61

Note: The script has silenced the TF CPU warnings. If you are using a GPU, then you will be fine.
'''

PUB_TRANSFORMED_PC = None
PUB_ROAD_PC = None
PUB_ROAD_HEATMAP = None
PUB_DETECTED_ROAD_PC = None

DOF = [0]*6
MODEL = None
GRAPH = None

#################################################
## Detection code
#################################################
def get_features(x,y,z,r,rings):
	side_range=(-10, 10)
	fwd_range=(2, 27)
	res=.1
	min_height = -1.0
	max_height = 2.6
	
	# Norm factors
	r_norm = (0.0, 100.0)
	number_of_rings = 16.0
	max_points_per_grid = 100.0

	# calculate the image dimensions
	img_width = int((side_range[1] - side_range[0])/res)
	img_height = int((fwd_range[1] - fwd_range[0])/res)
	number_of_grids = img_height * img_width

	# FILTER POINTS.
	# INDICES FILTER - of values within the desired rectangle
	# Note left side is positive y axis in LIDAR coordinates
	ff = np.logical_and((x > fwd_range[0]), (x < fwd_range[1]))
	ss = np.logical_and((y > -side_range[1]), (y < -side_range[0]))
	zz = np.logical_and((z > min_height), (z < max_height))
	mask = np.logical_and(ff, ss)
	mask = np.logical_and(mask, zz)
	
	indices_mask = np.argwhere(mask).flatten() # boolean mask for selecting points

	# select the points that we are interested in
	x_lidar = x[indices_mask]
	y_lidar = y[indices_mask]
	z_lidar = z[indices_mask]
	r_lidar = r[indices_mask]
	rg_lidar = rings[indices_mask]
	# number_of_points = x_lidar.shape[0]
		
	# NORMALIZATION
	# Normalise the elevation, reflectance, and count
	# count will be normalised afterwards
	# Elevation
	clipped_z_lidar = np.clip(z_lidar, min_height, max_height)
	norm_z_lidar = (clipped_z_lidar - min_height) / (max_height - min_height)
	
	# Reflectance
	clipped_lidar_norm = np.clip(r_lidar, r_norm[0], r_norm[1])
	r_lidar_norm = (clipped_lidar_norm - r_norm[0]) / (r_norm[1] - r_norm[0])
	
	# MAPPING
	# Mappings from one point to grid 
	# CONVERT TO PIXEL POSITION VALUES - Based on resolution(grid size)
	x_img_mapping = (-y_lidar/res).astype(np.int32) # x axis is -y in LIDAR
	y_img_mapping = (x_lidar/res).astype(np.int32)  # y axis is -x in LIDAR; will be inverted later

	# SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
	# floor used to prevent issues with -ve vals rounding upwards
	x_img_mapping -= int(np.floor(side_range[0]/res))
	y_img_mapping -= int(np.floor(fwd_range[0]/res))

	# Linerize the mappings to 1D
	lidx = ((-y_img_mapping) % img_height) * img_width + x_img_mapping

	# Feature extraction
	# count of points per grid
	count_input = np.ones_like(norm_z_lidar)
	binned_count = np.bincount(lidx, count_input, minlength = number_of_grids)
	
	# sum reflectance
	binned_reflectance =  np.bincount(lidx, r_lidar_norm, minlength = number_of_grids)

	# sum elevation 
	binned_elevation = np.bincount(lidx, norm_z_lidar, minlength = number_of_grids)

	# Finding mean!
	binned_mean_reflectance = np.divide(binned_reflectance, binned_count, out=np.zeros_like(binned_reflectance), where=binned_count!=0.0)
	binned_mean_elevation = np.divide(binned_elevation, binned_count, out=np.zeros_like(binned_elevation), where=binned_count!=0.0)
	o_mean_elevation = binned_mean_elevation.reshape(img_height, img_width)

	# Standard devation stuff
	binned_sum_var_elevation = np.bincount(lidx, np.square(norm_z_lidar - o_mean_elevation[-y_img_mapping, x_img_mapping]), minlength = number_of_grids)
	binned_divide = np.divide(binned_sum_var_elevation, binned_count, out=np.zeros_like(binned_sum_var_elevation), where=binned_count!=0.0)
	binned_std_elevation = np.sqrt(binned_divide)

	# minimum and maximum
	sidx = lidx.argsort()
	idx = lidx[sidx]
	val = norm_z_lidar[sidx]

	m_idx = np.flatnonzero(np.r_[True,idx[:-1] != idx[1:]])
	unq_ids = idx[m_idx]

	o_max_elevation = np.zeros([img_height, img_width], dtype=np.float64)
	o_min_elevation = np.zeros([img_height, img_width], dtype=np.float64)

	o_max_elevation.flat[unq_ids] = np.maximum.reduceat(val, m_idx)
	o_min_elevation.flat[unq_ids] = np.minimum.reduceat(val, m_idx)
	
	rg_vals = rg_lidar[sidx] # grouped values of rings
	rg_val_uniq = np.unique(rg_vals)
	rg_val_uniq_hit = rg_vals[:, np.newaxis] == rg_val_uniq
	rg_reduced = np.logical_or.reduceat(rg_val_uniq_hit, m_idx)

	ring_img = np.zeros([img_height, img_width], dtype=np.float64)
	ring_img.flat[unq_ids] = np.count_nonzero(rg_reduced, axis=1)
	ring_img = ring_img / number_of_rings
	# Normalise count
	norm_binned_count = binned_count / max_points_per_grid
	# reshape all other things
	o_count            = norm_binned_count.reshape(img_height, img_width)
	o_mean_reflectance = binned_mean_reflectance.reshape(img_height, img_width)
	o_std_elevation    = binned_std_elevation.reshape(img_height, img_width)
	
	normed = np.dstack([o_count, o_mean_reflectance, o_max_elevation, o_min_elevation, o_mean_elevation, o_std_elevation, ring_img]) #, ring_img
	filtered = np.stack([x_lidar, y_lidar, z_lidar, r_lidar, rg_lidar]).T
	mappings = [x_img_mapping, y_img_mapping, lidx]
	return normed, filtered, mappings

def prob_thres(channel, threshold=0.9):
	_channel = np.zeros_like(channel)
	_channel[channel > threshold] = 1.0
	return _channel

#################################################
##  color helper
#################################################

def hsv_to_rgb(hsv):
    """
    convert hsv values in a numpy array to rgb values
    both input and output arrays have shape (M,3)
    """
    h = hsv[:, 0]
    s = hsv[:, 1]
    v = hsv[:, 2]

    r = np.empty_like(h)
    g = np.empty_like(h)
    b = np.empty_like(h)

    i = (h * 6.0).astype(np.int)
    f = (h * 6.0) - i
    p = v * (1.0 - s)
    q = v * (1.0 - s * f)
    t = v * (1.0 - s * (1.0 - f))

    idx = i % 6 == 0
    r[idx] = v[idx]
    g[idx] = t[idx]
    b[idx] = p[idx]

    idx = i == 1
    r[idx] = q[idx]
    g[idx] = v[idx]
    b[idx] = p[idx]

    idx = i == 2
    r[idx] = p[idx]
    g[idx] = v[idx]
    b[idx] = t[idx]

    idx = i == 3
    r[idx] = p[idx]
    g[idx] = q[idx]
    b[idx] = v[idx]

    idx = i == 4
    r[idx] = t[idx]
    g[idx] = p[idx]
    b[idx] = v[idx]

    idx = i == 5
    r[idx] = v[idx]
    g[idx] = p[idx]
    b[idx] = q[idx]

    idx = s == 0
    r[idx] = v[idx]
    g[idx] = v[idx]
    b[idx] = v[idx]

    # rgb = np.empty_like(hsv)
    # rgb[:, 0] = r
    # rgb[:, 1] = g
    # rgb[:, 2] = b
    return r, g, b


#################################################
## ROS THINGS
#################################################

def get_transform_details(data):
	global DOF
	rospy.loginfo(rospy.get_caller_id() + " Got Transform params(roll, pitch, yaw, x, y, z): %s", data.data)
	DOF = data.data.strip(')').strip('(').strip().split(",")
	DOF =   [float(x) for x in DOF]

def detect_road(data):
	## profile things
	# pr = cProfile.Profile()
	# pr.enable()

	global MODEL, DOF, PUB_TRANSFORMED_PC, PUB_ROAD_PC, PUB_ROAD_HEATMAP, PUB_DETECTED_ROAD_PC
	
	## transform the points to a common coordinate system
	roll, pitch, yaw = DOF[0], DOF[1], DOF[2]
	quat = quaternion_from_euler (roll, pitch, yaw)

	t = TransformStamped()
	t.transform.rotation.x = quat[0]
	t.transform.rotation.y = quat[1]
	t.transform.rotation.z = quat[2]
	t.transform.rotation.w = quat[3]
	t.transform.translation.x = DOF[3]
	t.transform.translation.y = DOF[4]
	t.transform.translation.z = DOF[5]
	
	pc_transformed = do_transform_cloud(data, t)
	pc_transformed.header = data.header

	## convert transformed pointcloud2 to numpy
	arr = ros_numpy.point_cloud2.pointcloud2_to_array(pc_transformed)
	_x = arr['x']
	_y = arr['y']
	_z = arr['z']
	_r = arr['intensity']
	_rn= arr['ring']
	
	## predict road
	features, filtered, mappings = get_features(_x, _y, _z, _r, _rn)
	with GRAPH.as_default():
		pred = MODEL.predict(np.expand_dims(features, axis=0))
	road_map, nonroad_map = pred[0,:,:,0], pred[0,:,:,1]
	road = prob_thres(road_map, threshold=0.9) # Float32

	## apply thresholding
	## 1. Appy thresholding using Z.
	min_height, max_height = [-1, 2.6]
	thres_z = 0.4 # ground clearance of maini 4s is 0.125
	norm_thres_z = (thres_z - min_height) / (max_height - min_height)
	thres_z_mask = features[:,:,2] > norm_thres_z
	
	## 2. apply ring threshold
	thres_ring = 1
	norm_thres_ring = thres_ring / 16.0
	thres_ring_mask = features[:,:,6] > norm_thres_ring

	## combine masks and apply to road prob
	mask = np.logical_and(thres_z_mask, thres_ring_mask)
	road[mask] = 0

	## get road points
	_labels = road[-mappings[1], mappings[0]]
	_arr = filtered[_labels == 1.]
	road_rgb = np.full((_arr.shape[0]), 16777215, dtype=np.float32) # pink - 16777471
	road_pts = np.core.records.fromarrays([_arr[:, 0], _arr[:, 1], 
										_arr[:, 2], _arr[:, 3], _arr[:, 4], road_rgb],
										names='x,y,z,intensity,ring,rgb')
	pc_road_pts = ros_numpy.point_cloud2.array_to_pointcloud2(road_pts)
	pc_road_pts.header = data.header

	## publish a new pc with detected road in different color
	hsv = np.zeros((_labels.shape[0], 3), dtype=np.float32)
	hsv[..., 0] = filtered[:, 4] /16
	hsv[..., 1] = 1.0
	hsv[..., 2] = 1.0
	r, g, b = hsv_to_rgb(hsv) # the values will be in [0, 1]

	rgb_pc = r *255 * 65536 + g * 255 * 256 + b * 255
	rgb_pc = rgb_pc.astype(np.uint32)
	rgb_pc[_labels == 1] =  16777215
	arr_filtered = np.core.records.fromarrays([filtered[:, 0], filtered[:, 1], 
										filtered[:, 2], filtered[:, 3], filtered[:, 4], rgb_pc],
										names='x,y,z,intensity,ring, rgb')
	pc_filtered = ros_numpy.point_cloud2.array_to_pointcloud2(arr_filtered)
	pc_filtered.header = data.header

	## heatmap road
	im_road_heatmap = ros_numpy.msgify(Image, road.astype(np.uint8) * 255, 'mono8')

	## publish
	PUB_ROAD_PC.publish(pc_road_pts)
	PUB_TRANSFORMED_PC.publish(pc_transformed)
	PUB_ROAD_HEATMAP.publish(im_road_heatmap)
	PUB_DETECTED_ROAD_PC.publish(pc_filtered)

	## stop profiling
	# print "PROFILE GENERATED"
	# pr.disable()
	# s = StringIO.StringIO()
	# sortby = 'cumulative'
	# ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
	# ps.print_stats()
	# print s.getvalue()
	
def init():
	global DOF, PUB_TRANSFORMED_PC, PUB_ROAD_PC, MODEL, GRAPH, PUB_ROAD_HEATMAP, PUB_DETECTED_ROAD_PC
	
	MODEL = keras.models.load_model('/home/tpk/workspace/rosws/src/road_detection/final_model.h5')
	GRAPH = tf.get_default_graph()
	# MODEL.summary()
	
	rospy.init_node('lidar_road_detection', anonymous=True)
	rospy.Subscriber("dof_ip", String, get_transform_details)
	rospy.Subscriber("velodyne_points", PointCloud2, detect_road)
	
	PUB_TRANSFORMED_PC = rospy.Publisher('transformed_pc', PointCloud2, queue_size=10)
	PUB_ROAD_PC = rospy.Publisher('road_pc', PointCloud2, queue_size=10)
	PUB_DETECTED_ROAD_PC = rospy.Publisher('detected_road_pc', PointCloud2, queue_size=10)
	PUB_ROAD_HEATMAP = rospy.Publisher('road_heatmap', Image, queue_size=10)
	
	rospy.spin()

if __name__ == '__main__':
	init()
