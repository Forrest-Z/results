#!/usr/bin/env python


import numpy as np
import math as MT
import constants as constant
import rospy
from sensor_msgs.msg import NavSatFix 
from std_msgs.msg import Float64, Int8
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped,TransformStamped
import constants1 as constant
import tf

# class constants():
#   def __init__(self):
#     self.waypoint_list=[[[65,1,np.pi/2],[65,2,np.pi/2],[65,3,np.pi/2]],[[4,1,np.pi/2],[4,2,np.pi/2],[4,3,np.pi/2]]]  
#     self.vehicle_pt_obj_actual = constant.vehicle_points( np.array([[0.5,0.5],[0.5,1.5],[0.5,2.5],[0.5,3.5],[1.5,0.5],[1.5,1.5],[1.5,2.5],[1.5,3.5]]),[0,2] )
#     self.waypoint_tree_list=constant.get_way_point_tree_list(self.waypoint_list)
#     self.offset_value=10

class values:
  def __init__(self,grid_on_x,grid_on_y,GRID_TEST,start_global):
    self.grid_on_x=grid_on_x
    self.grid_on_y=grid_on_y
    self.GRID_TEST=GRID_TEST
    self.start_global=start_global
    self.feed_map=True
    self.get_start_point=True


class waypoints():
    def __init__(self,input_co_ordinates,center):
        self.input_co_ordinates=input_co_ordinates
        self.center=center

### 
def transform_frame_co_ordinates(current_frame_waypoints_obj, frame_expected):
    displaced_matrix = np.array([frame_expected[0]-current_frame_waypoints_obj.center[0],frame_expected[1]-current_frame_waypoints_obj.center[1]])
    transformed_matrix=np.add(current_frame_waypoints_obj.input_co_ordinates,displaced_matrix)
    return waypoints(transformed_matrix,frame_expected)


### LANE CLASS
class vehicle_params():
  def __init__(self,lane_number,goal_lane,state):
    self.lane_number=lane_number
    self.goal_lane=goal_lane
    self.state=state

vehicle_state=vehicle_params(constant.present_lane,constant.goal_lane,constant.present_state)

def closest_index(lane_index,localized_point):
  lane_waypoints=constant.waypoints_list[lane_index]
  waypoints_tree=constant.waypoint_tree_list[lane_index]

  closest_idx=waypoints_tree.query(localized_point,1)[1]
  closest_coord=lane_waypoints[closest_idx][:2]
  prev_coord=lane_waypoints[closest_idx-1][:2]
  cl_vect=np.array(closest_coord)
  prev_vect=np.array(prev_coord)
  pos_vect=np.array(localized_point)
  val= np.dot(cl_vect-prev_vect,pos_vect-cl_vect)
  if val>0:
    temp=closest_idx
    closest_idx=(closest_idx+1)%len(lane_waypoints)
    if(closest_idx==0 and temp>0):
      closest_idx=temp
  return closest_idx

### FLOOR VALUE
def idx(value):
  return int(MT.floor(value))


### TRANSFORM VEHICLE CO-ORDINATES 
def transform_vehicle_co_ordinates(vehicle_point_object, next_state, angle_of_rotation):
    displaced_matrix = np.array([next_state[0]-vehicle_point_object.center[0],next_state[1]-vehicle_point_object.center[1]])
    transformed_matrix=np.add(vehicle_point_object.input_co_ordinates,displaced_matrix)
    return constant.vehicle_points(rotate_vehicle_co_ordinates(constant.vehicle_points(transformed_matrix,next_state),angle_of_rotation),next_state)
  
  
### ROTATE VEHICLE CO-ORDINATES     
def rotate_vehicle_co_ordinates(vehicle_point_object,angle_of_rotation):
    rotation_matrix = np.array([[np.cos(angle_of_rotation), np.sin(angle_of_rotation)], 
                                [-np.sin(angle_of_rotation), np.cos(angle_of_rotation)]])
    return np.add(vehicle_point_object.center,np.matmul(np.subtract(vehicle_point_object.input_co_ordinates,vehicle_point_object.center), rotation_matrix))


### CHECK VEHICLE IN SAFE POSITION  
def is_vehicle_in_safe_position(vehicle_point_object,grid):
  grid_on_x=len(grid[0])
  grid_on_y=len(grid)
  for point in vehicle_point_object.input_co_ordinates:
    if(is_within_grid( idx(point[0]),idx(point[1]),grid_on_x,grid_on_y) and  
       (grid[idx(point[0])][idx(point[1])]==0)):
      continue
    else:
      return False
  return True

### CHECK WITHIN GRID  
def is_within_grid(x,y,grid_on_x,grid_on_y):
  return (x>=0 and x<grid_on_x and y>=0 and y<grid_on_y)

def validate_safe(waypoints,vehicle_pt_obj_actual,grid):
  for wp in waypoints:
    #print(wp)
    transformed_coordinates=transform_vehicle_co_ordinates(vehicle_pt_obj_actual,[wp[0],wp[1]],wp[2])
    #print(transformed_coordinates.input_co_ordinates)
    if(not is_vehicle_in_safe_position(transformed_coordinates,grid)):
      return False
  return True



def successor_states(lane,lanes_available,state):
        """
        Provides the possible next states given the current state for the FSM discussed in the course,
        with the exception that lane changes happen instantaneously, so LCL and LCR can only transition back to KL.
        """
        if state in ("KL","STOP"):
            states = ["KL","STOP"]
            if lane != 0:
                states.append("LCL")
            if lane != (lanes_available-1):
                states.append("LCR")
        
        elif state in ("LCL", "LCR"):
            states = ["KL","STOP"] 
            
        elif state == "PLCL":
            states = ["KL","STOP"]
            if lane != 0:
                states.append("PLCL")
                states.append("LCL")
                
        elif state == "PLCR":
            states = ["KL","STOP"]
            if lane != (lanes_available-1):
                states.append("PLCR")
                states.append("LCR")
        return states
      

def calculate_cost(lane_num,goal_lane,localization,grid):
    waypoints=constant.waypoints_list[lane_num]
    near_index=closest_index(lane_num,localization)
    waypoints=waypoints[near_index:near_index + constant.offset_value]
    # waypoints=transform_waypoints(waypoints,localization)
    vehicle_pt_obj_actual = constant.vehicle_pt_obj_actual
    if(validate_safe(waypoints,vehicle_pt_obj_actual,grid) and len(waypoints)>=1):
      delta_d=float(abs(lane_num-goal_lane))
      cost= 1 - MT.exp(-(abs(delta_d) / len(waypoints)))
      return cost
    else:
      return float('inf')
    
    
def choose_next_state(localization,grid):
        lanes_available = len(constant.waypoints_list)
        costs = []
        states = successor_states(vehicle_state.lane_number,lanes_available,vehicle_state.state)
        print(states)
        for state in states:
          value=constant.lane_direction[state]
          if value!=None:
            lane_index=vehicle_state.lane_number + value
            cost = calculate_cost(lane_index,vehicle_state.goal_lane,localization,grid)
            costs.append({"cost" : cost, "state": state,"lane_index":lane_index})
          else:
            costs.append({"cost" : 100, "state": state,"lane_index":vehicle_state.lane_number})
        print(costs)   
        best = min(costs, key=lambda s: s['cost'])
        vehicle_state.lane_number=best["lane_index"]
        vehicle_state.state=best["state"]

        lane_to_be_selected = best["lane_index"]
        # pub = rospy.Publisher('/lane_index', Int8, queue_size=10)
        # pub.publish(lane_to_be_selected)
        return best["lane_index"]


        
def compass(value):
  global compass
  #print("Value:", value)
  compass = value.data

def localization(data):
  global current_location, compass
  lat = data.latitude
  long_ = data.longitude
  current_location = [lat, long_, compass]


def localization_test(msg):
  if(get_value.get_start_point==True):
    get_value.get_start_point=False
    quaternion = (
    msg.transform.rotation.x,
    msg.transform.rotation.y,
    msg.transform.rotation.z,
    msg.transform.rotation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    roll = euler[0]
    pitch = euler[1]
    yaw = euler[2]
    get_value.start_global =[msg.transform.translation.x,msg.transform.translation.y,yaw]
    localization = [msg.pose.pose.position.x, msg.pose.pose.position.y]
    lane_num = 0
    waypoints=constant.waypoints_list[lane_num]
    near_index=closest_index(lane_num,localization)
    waypoints=waypoints[near_index:near_index + constant.offset_value]
    print(waypoints)
    glob_waypoints=np.array([[w[0],w[1]] for w in waypoints])
    waypoint_obj=waypoints(glob_waypoints,[0,0])
    local_waypoints=transform_frame_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)])
    
    pub = rospy.Publisher('/local_trajectory', Path, queue_size=50)
    path_pub=Path()
    path_pub.header.frame_id='laser'
    for i in range(len(waypoints)):#
      new_pose=PoseStamped()
      path_now=waypoints[i]
      # quaternion_map=tf.transformations.quaternion_from_euler(0.0, 0.0, path_now[2])
      new_pose.header.seq=i+1
      new_pose.header.frame_id='laser'
      new_pose.pose.position.x=path_now[0]
      new_pose.pose.position.y=path_now[1]
      new_pose.pose.position.y=path_now[2]
      new_pose.pose.orientation.x= path_now[3]
      new_pose.pose.orientation.y= path_now[4]
      new_pose.pose.orientation.z= path_now[5]
      new_pose.pose.orientation.w= path_now[6]
      # new_pose.pose.orientation=path_now[3]
      path_pub.poses.append(new_pose)
    # rate = rospy.Rate(50)
    # start_time=time.time()
    pub.publish(path_pub)


def feed_map(msg):
  if(get_value.feed_map==True):
    get_value.feed_map=False
    print('FEEDING THE MAP IN')
    local_grid=msg.data
    grid_on_x=msg.info.width
    grid_on_y=msg.info.height
    resolution=msg.info.resolution

    local_grid=np.flipud(np.rot90(np.reshape(local_grid,(grid_on_x,grid_on_y))))
    local_grid[local_grid<0]=100
    local_grid[local_grid>=50]=1
    local_grid[local_grid != 0]=1
    #get_value.GRID_TEST=np.pad(local_grid,H.constants_lookup.local_const.GRID_OFFSET_VALUE,pad_with)
    get_value.grid_on_x=get_value.grid_on_y=get_value.GRID_TEST.shape[0] 
  

get_value=values(0,0,np.array([]),[])

if __name__== "__main__":

  rospy.init_node( 'planner', anonymous=True)      
  #sub_compasss = rospy.Subscriber('/compass_angle', Float64, compass)
  #sub_gps = rospy.Subscriber('/fix', NavSatFix, localization)
  rospy.Subscriber('/local_map', OccupancyGrid, feed_map)
  sub_gps = rospy.Subscriber('/gps_transform', TransformStamped, localization_test)
  # sub_grid = rospy.Subscriber('/local_map', OccupancyGrid, grid)

  
  rospy.spin()