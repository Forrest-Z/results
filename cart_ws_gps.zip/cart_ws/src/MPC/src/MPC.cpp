#include "MPC.h"
#include <cppad/cppad.hpp>
#include <cppad/ipopt/solve.hpp>
#include "Eigen-3.3/Eigen/Core"

using CppAD::AD;

// Number of steps
size_t N = 20 ;

// Timestep size
double dt = MPC_DT ;

// Velocity reference
double ref_v = 1.4 ;

// This value assumes the model presented in the classroom is used.
//
// It was obtained by measuring the radius formed by running the vehicle in the
// simulator around in a circle with a constant steering angle and velocity on a
// flat terrain.
//
// Lf was tuned until the the radius formed by the simulating the model
// presented in the classroom matched the previous radius.
//
// This is the length from front to CoG that has a similar radius.
const double Lf = 0.83 ;


size_t x_start = 0;
size_t y_start = x_start + N;
size_t psi_start = y_start + N;
size_t v_start = psi_start + N;
size_t cte_start = v_start + N;
size_t epsi_start = cte_start + N;
size_t delta_start = epsi_start + N;
size_t a_start = delta_start + N - 1;

class FG_eval 
{
	public:
	// Fitted polynomial coefficients
	Eigen::VectorXd coeffs;
	FG_eval(Eigen::VectorXd coeffs) { this->coeffs = coeffs; }


	//// MVP3.5 Mysore

	// (1) Level 1. Drift to left. Turn OK
	double wCTE = 0.9 ; 
	double wEPSI = 0.6 ; 
	double wVErr = 0.0 ; 
	double wSteerAct = 0.5 ; 
	double wThrottleAct = 0.0 ; 
	double wSteerChange = 5000.0 ; 
	double wThrottleChange = 0.0 ; 

	typedef CPPAD_TESTVECTOR(AD<double>) ADvector;
	void operator()(ADvector& fg, const ADvector& vars) 
	{
		
		// Reset cost
		fg[0] = 0;

		// Increment cost error w.r.t reference values
		for( int t = 0 ; t < N ; t++ )  
		{
			// Increment cost for CTE
			fg[0] += wCTE * CppAD::pow( vars[cte_start + t], 2) ;

			// Increment cost for angle error
			fg[0] += wEPSI * CppAD::pow( vars[epsi_start + t], 2) ;

			// Increment cost for speed deviation error
			fg[0] += wVErr * CppAD::pow( vars[v_start + t] - ref_v, 2) ;
		}

		// Increment cost for steering and throttle
		for( int t = 0 ; t < N-1 ; t++ )  
		{
			fg[0] += wSteerAct * CppAD::pow( vars[delta_start + t], 2) ;
			fg[0] += wThrottleAct * CppAD::pow( vars[a_start + t], 2) ;
		}

		// Increment cost for steering and throttle changes
		for( int t = 0 ; t < N-2 ; t++ ) 
		{
			fg[0] += wSteerChange * CppAD::pow( vars[delta_start + t + 1] - vars[delta_start + t], 2 ) ;
			fg[0] += wThrottleChange * CppAD::pow( vars[a_start + t + 1] - vars[a_start + t], 2 ) ;
		}

		// Set values for first time step
		fg[1 + x_start] = vars[x_start];
		fg[1 + y_start] = vars[y_start];
		fg[1 + psi_start] = vars[psi_start];
		fg[1 + v_start] = vars[v_start];
		fg[1 + cte_start] = vars[cte_start];
		fg[1 + epsi_start] = vars[epsi_start];

		// Set values for rest of the time steps
		for (int t = 1; t < N; t++) 
		{
			// The state at time t.
			AD<double> x0 = vars[x_start + t - 1];
			AD<double> y0 = vars[y_start + t - 1];
			AD<double> psi0 = vars[psi_start + t - 1];
			AD<double> v0 = vars[v_start + t - 1];
			AD<double> cte0 = vars[cte_start + t - 1];
			AD<double> epsi0 = vars[epsi_start + t - 1];

			// The state at time t+1 .
			AD<double> x1 = vars[x_start + t];
			AD<double> y1 = vars[y_start + t];
			AD<double> psi1 = vars[psi_start + t];
			AD<double> v1 = vars[v_start + t];
			AD<double> cte1 = vars[cte_start + t];
			AD<double> epsi1 = vars[epsi_start + t];

			// Actuation at time t.
			AD<double> delta0 = vars[delta_start + t - 1];
			AD<double> a0 = vars[a_start + t - 1];

			AD<double> x0_sq = x0 * x0 ;
			AD<double> x0_cb = x0_sq * x0 ;

			// y at time t
			AD<double> f0 = coeffs[0] + ( coeffs[1] * x0 ) + ( coeffs[2] * x0_sq ) ; //+ ( coeffs[3] * x0_cb ) ;

			// Angle at time t (slope of curve)
			AD<double> psides0 = CppAD::atan( coeffs[1] + ( 2 * coeffs[2] * x0 ) ) ; //+ ( 3 * coeffs[3] * x0_sq ) );

			// Update constraints for next state
			fg[1 + x_start + t] = x1 - (x0 + v0 * CppAD::cos(psi0) * dt);
			fg[1 + y_start + t] = y1 - (y0 + v0 * CppAD::sin(psi0) * dt);
			fg[1 + psi_start + t] = psi1 - (psi0 - v0 * (delta0 / Lf) * dt);
			fg[1 + v_start + t] = v1 - (v0 + a0 * dt);
			fg[1 + cte_start + t] = cte1 - ((f0 - y0) + (v0 * CppAD::sin(epsi0) * dt));
			fg[1 + epsi_start + t] = epsi1 - ((psi0 - psides0) - v0 * delta0 / Lf * dt);
		}

	}
};

//
// MPC class definition implementation.
//
MPC::MPC() {}
MPC::~MPC() {}

void MPC::AdjustLatency( double& px, double& py, double& psi, double& v, double steer_curr, double throttle_curr, double latency ) 
{
	px += v * cos(psi) * latency ;
	py += v * sin(psi) * latency ;
	psi -= v * (steer_curr / Lf) * latency ;
	v += throttle_curr * latency ;
}

vector<double> MPC::Solve(Eigen::VectorXd state, Eigen::VectorXd coeffs) 
{
	bool ok = true;
	typedef CPPAD_TESTVECTOR(double) Dvector;

	// Number of variables
	size_t n_vars = N * NUM_STATE + (N-1) * NUM_ACTRS ;
	
	// Number of constraints
	size_t n_constraints = N * NUM_STATE ;

	// Initial value of the independent variables.
	// SHOULD BE 0 besides initial state.
	Dvector vars(n_vars);

	for (int i = 0; i < n_vars; i++) 
	{
		vars[i] = 0;
	}

	// Set the initial variable values
	vars[x_start] = state[0] ;
	vars[y_start] = state[1] ;
	vars[psi_start] = state[2] ;
	vars[v_start] = state[3] ;
	vars[cte_start] = state[4] ;
	vars[epsi_start] = state[5] ;

	// Lower and upper limits for x
	Dvector vars_lowerbound(n_vars);
	Dvector vars_upperbound(n_vars);

	// Set all non-actuators upper and lowerlimits
	// to the max negative and positive values.
	for (int i = 0; i < delta_start; i++) 
	{
		vars_lowerbound[i] = -1.0e19;
		vars_upperbound[i] = 1.0e19;
	}

	// Set steering limits to +- 25 deg
	for (int i = delta_start; i < a_start; i++) 
	{
		vars_lowerbound[i] = -0.785;
		vars_upperbound[i] = 0.785;
	}

	// Set acceleration limits to +- 1 
	for (int i = a_start; i < n_vars; i++) 
	{
		vars_lowerbound[i] = -1.0;
		vars_upperbound[i] = 1.0;
	}

	// Lower and upper limits for the constraints
	Dvector constraints_lowerbound(n_constraints);
	Dvector constraints_upperbound(n_constraints);

	// Set setpoints to zero
	for (int i = 0; i < n_constraints; i++) 
	{
		constraints_lowerbound[i] = 0;
		constraints_upperbound[i] = 0;
	}

	// Set setpoints of first state 
	constraints_lowerbound[x_start] = state[0] ;
	constraints_lowerbound[y_start] = state[1] ;
	constraints_lowerbound[psi_start] = state[2] ;
	constraints_lowerbound[v_start] = state[3] ;
	constraints_lowerbound[cte_start] = state[4] ;
	constraints_lowerbound[epsi_start] = state[5] ;

	constraints_upperbound[x_start] = state[0] ;
	constraints_upperbound[y_start] = state[1] ;
	constraints_upperbound[psi_start] = state[2] ;
	constraints_upperbound[v_start] = state[3] ;
	constraints_upperbound[cte_start] = state[4] ;
	constraints_upperbound[epsi_start] = state[5] ;

	// Set coeffs
	FG_eval fg_eval(coeffs);

	//
	// NOTE: You don't have to worry about these options
	//
	// options for IPOPT solver
	std::string options;
	// Uncomment this if you'd like more print information
	options += "Integer print_level  0\n";
	// NOTE: Setting sparse to true allows the solver to take advantage
	// of sparse routines, this makes the computation MUCH FASTER. If you
	// can uncomment 1 of these and see if it makes a difference or not but
	// if you uncomment both the computation time should go up in orders of
	// magnitude.
	options += "Sparse  true        forward\n";
	options += "Sparse  true        reverse\n";
	// NOTE: Currently the solver has a maximum time limit of 0.5 seconds.
	// Change this as you see fit.
	options += "Numeric max_cpu_time          0.5\n";

	// place to return solution
	CppAD::ipopt::solve_result<Dvector> solution;

	// solve the problem
	CppAD::ipopt::solve<Dvector, FG_eval>(
	options, vars, vars_lowerbound, vars_upperbound, constraints_lowerbound,
	constraints_upperbound, fg_eval, solution);

	// Check some of the solution values
	ok &= solution.status == CppAD::ipopt::solve_result<Dvector>::success;

	// Cost
	auto cost = solution.obj_value;
	//std::cout << "Cost " << cost << std::endl;

	vector<double> result ;

	result.push_back( solution.x[delta_start] ) ;
	result.push_back( solution.x[a_start] ) ;

	for( int val = 0 ; val < N-1 ; val++ )
	{
		result.push_back( solution.x[x_start + val + 1] ) ;

		result.push_back( solution.x[y_start + val + 1] ) ;
	}

	return( result ) ;
}

///////////
////////// MPC Tuning

//////// Mysore

	// Stable for level 6
//	double wCTE = 0.8 ; 
//	double wEPSI = 1.0 ; 
//	double wVErr = 0.0 ; 
//	double wSteerAct = 0.5 ; 
//	double wThrottleAct = 0.0 ; 
//	double wSteerChange = 30.0 ; 
//	double wThrottleChange = 0.0 ; 

	// Stable for level 7. Excellent turn. Oscillate in straight
//	double wCTE = 1.0 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 60.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Stable for level 7. Excellent turn. CTE higher. Slight oscillate in straight (1)
//	double wCTE = 0.8 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 60.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Stable for level 7. Excellent turn. CTE lower than (1). Slight oscillate in straight (2)
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 100.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Stable for level 7. Good turn. CTE higher than (2). Slight oscillate in straight. Lesser than (2) (3)
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.5 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 100.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Stable for level 7. Excellent turn. CTE lower than (3). Slight oscillate in straight. Lesser than (3) (4)
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 400.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Stable for level 7. Excellent turn. CTE same as (4). Slight oscillate in straight. Lesser than (4) (5)
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 1000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

	// Working for SDB1-Magna speed 4
//	double wCTE = 0.9 ; 
//	double wEPSI = 0.7 ;
//	double wVErr = 0.0 ;
//	double wSteerAct = 0.5 ; 
//	double wThrottleAct = 0.0 ; 
//	double wSteerChange = 2000.0 ; 
//	double wThrottleChange = 0.0 ; 


	// Slight wobble for level 5
	// Working 20181121
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 0.6 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 5000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;


////// Pune 

	// Pune slight wobble
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.0 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 2000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

// 	For level 5. High wobble. Low error
//	double wCTE = 0.9 ; //0.01 ;
//	double wEPSI = 1.2 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 5000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;

// 	For level 5. Low wobble. Low error. Wobble near SDB6
//	double wCTE = 0.8 ; //0.01 ;
//	double wEPSI = 1.2 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 10000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;


//	For level 5. Low wobble. Ok in fountain.
//	double wCTE = 1.8 ; //0.01 ;
//	double wEPSI = 1.2 ; //0.01 ;
//	double wVErr = 0.0 ; //0.003 ;
//	double wSteerAct = 0.5 ; //0.05 ;
//	double wThrottleAct = 0.0 ; //0.01 ;
//	double wSteerChange = 22000.0 ; //50.0 ;
//	double wThrottleChange = 0.0 ; //0.02 ;
