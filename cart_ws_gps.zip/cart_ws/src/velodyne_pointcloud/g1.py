#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__authors__ = "Thomas Paul, Vimal, Sharath"
__version__ = "1.0"
'''
rostopic pub /dof_ip std_msgs/String "data: '0,0.19,0,0,0,2'"
'''
# # GPU warning silencer- Just disables the warning, doesn't enable AVX/FMA
import os
import sys
from nav_msgs.msg import OccupancyGrid

import rospy
import ros_numpy
from std_msgs.msg import String
from sensor_msgs.msg import PointCloud2, Image
from geometry_msgs.msg import TransformStamped, Pose, Quaternion, Point
from tf2_sensor_msgs.tf2_sensor_msgs import do_transform_cloud
from tf.transformations import quaternion_from_euler
import matplotlib.pyplot as plt
import numpy as np
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats


##########
# Transform
##########
DOF = [0]*6
PUB_TRANSFORMED_PC = None

def get_transform_details(data):
	global DOF
	rospy.loginfo(rospy.get_caller_id() + " Got Transform params(roll, pitch, yaw, x, y, z): %s", data.data)
	DOF = data.data.strip(')').strip('(').strip().split(",")
	DOF =   [float(x) for x in DOF]



#################################################
## Grid generation code
#################################################
def get_grid(x,y,z,r,rings):
	# TODO: modify the parameters
	# Lidar is at (0,0,0)
	side_range=(-15, 15) # 10 meters to the right and 10 meters to the left
	fwd_range=(-15,15) # 2 meters from front to 27 meters. -5 means 5 meters behind
	min_height = -1.0# -1m below the lidar
	max_height = 3

	res= 0.2# grid size of 0.1m X 0.1m
	point_threshold = 5
	#
	# print(z)
	# calculate the image/grid dimensions
	grid_width = int((side_range[1] - side_range[0])/res)
	grid_height = int((fwd_range[1] - fwd_range[0])/res)
	number_of_grids = grid_height * grid_width

	# FILTER POINTS.
	# INDICES FILTER - of values within the desired rectangle
	# Note left side is positive y axis in LIDAR coordinates
	ff = np.logical_and((x > fwd_range[0]), (x < fwd_range[1]))
	ss = np.logical_and((y > -side_range[1]), (y < -side_range[0]))
	zz = np.logical_and((z > min_height), (z < max_height))
	mask = np.logical_and(ff, ss)
	mask = np.logical_and(mask, zz)
	
	indices_mask = np.argwhere(mask).flatten() # boolean mask for selecting points

	# select the points that we are interested in
	x_lidar = x[indices_mask]
	y_lidar = y[indices_mask]
	z_lidar = z[indices_mask]
	# r_lidar = r[indices_mask]
	# rg_lidar = rings[indices_mask]
		
	# MAPPING
	# Mappings from one point to grid 
	# CONVERT TO PIXEL POSITION VALUES - Based on resolution(grid size)
	x_img_mapping = (-y_lidar/res).astype(np.int32) # x axis is -y in LIDAR
	y_img_mapping = (x_lidar/res).astype(np.int32)  # y axis is -x in LIDAR; will be inverted later


	#I changed
	#x_img_mapping = (x_lidar/res).astype(np.int32) # x axis is -y in LIDAR
	#y_img_mapping = (y_lidar/res).astype(np.int32)  # y axis is -x in LIDAR; will be inverted later
	##################

	# SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
	# floor used to prevent issues with -ve vals rounding upwards
	x_img_mapping -= int(np.floor(side_range[0]/res))
	y_img_mapping -= int(np.floor(fwd_range[0]/res))

	#I changed
	#x_img_mapping -= int(np.floor(fwd_range[0]/res))
	#y_img_mapping -= int(np.floor(side_range[0]/res))
	#####################

	# Linerize the mappings to 1D
	lidx = ((-y_img_mapping) % grid_height) * grid_width + x_img_mapping


	#I changed
	#lidx = ((y_img_mapping) % grid_height) * grid_width + x_img_mapping
	######################

	# count of points per grid
	count_input = np.ones_like(y_lidar)
	binned_count = np.bincount(lidx, count_input, minlength = number_of_grids)
	grid_count = binned_count.reshape(grid_height, grid_width)

	# max z per grid
	sidx = lidx.argsort()
	idx = lidx[sidx]
	val = z_lidar[sidx]

	m_idx = np.flatnonzero(np.r_[True,idx[:-1] != idx[1:]])
	unq_ids = idx[m_idx]

	o_max_elevation = np.zeros([grid_height, grid_width], dtype=np.float64)
	o_max_elevation.flat[unq_ids] = np.maximum.reduceat(val, m_idx)


	# grid making
	grid = np.zeros_like(grid_count)
	# grid[grid_count > point_threshold] = 100
	grid[o_max_elevation > 0.4] = 100
	return grid,res,grid_width, grid_height

#################################################
## ROS THINGS
#################################################

def generate_grid_callback(data):
	# TODO: assign point cloud here
	# TODO: transform pc
	global PUB_TRANSFORMED_PC, DOF


	roll, pitch, yaw = DOF[0], DOF[1], DOF[2]
	quat = quaternion_from_euler (roll, pitch, yaw)

	t = TransformStamped()
	t.transform.rotation.x = quat[0]
	t.transform.rotation.y = quat[1]
	t.transform.rotation.z = quat[2]
	t.transform.rotation.w = quat[3]
	t.transform.translation.x = DOF[3]
	t.transform.translation.y = DOF[4]
	t.transform.translation.z = DOF[5]
	
	pc_transformed = do_transform_cloud(data, t)
	pc_transformed.header = data.header

	# publish transformed
	PUB_TRANSFORMED_PC.publish(pc_transformed)

	pc = pc_transformed
	## convert transformed pointcloud2 to numpy
	#print(pc)
	arr = ros_numpy.point_cloud2.pointcloud2_to_array(pc)
	_x = arr['x']
	_y = arr['y']
	_z = arr['z']
	#_r = arr['intensity']
	#_rn= arr['ring']
	
	## predict road
	grid, res,grid_width, grid_height = get_grid(_x, _y, _z, 0, 0)
	
	grid_msg = OccupancyGrid()
	grid_msg.header.stamp = rospy.Time.now()
	grid_msg.header.frame_id = "local_map"
	
	grid_msg.info.resolution = res
	grid_msg.info.width = grid_width
	grid_msg.info.height = grid_height

	
	grid_msg.info.origin = Pose(Point(0.,0., 0.),
							Quaternion(0., 0., 0., 1.))

	grid = np.rot90(np.flipud(grid),1)
	flat_grid = grid.ravel()
	grid_msg.data = list(np.round(flat_grid, decimals = 3))

	pub = rospy.Publisher('/local_map', OccupancyGrid, queue_size=1)
	pub.publish(grid_msg)



	# x=[]
	# y=[]
	# for i in range(len(grid)):
	# 	 for k in range(len(grid[0])):
	# 		 if(grid[i][k]!=0):
	# 			 x.append(i)
	# 			 y.append(k)
	# plt.scatter(x,y)
	# plt.show()
    

			
	## TODO: publish grid

	
def init():
	global PUB_TRANSFORMED_PC
	rospy.init_node('lidar_grid', anonymous=True)
	rospy.Subscriber("dof_ip", String, get_transform_details)
	rospy.Subscriber("/velodyne_points", PointCloud2, generate_grid_callback)
	PUB_TRANSFORMED_PC = rospy.Publisher('transformed_pc', PointCloud2, queue_size=10)
	rospy.spin()

if __name__ == '__main__':
	init()
