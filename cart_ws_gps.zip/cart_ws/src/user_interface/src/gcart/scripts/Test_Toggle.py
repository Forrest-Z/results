# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow11.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow11(object):
    def setupUi(self, MainWindow11):
        MainWindow11.setObjectName("MainWindow11")
        MainWindow11.resize(400, 300)
        self.centralWidget = QtWidgets.QWidget(MainWindow11)
        self.centralWidget.setObjectName("centralWidget")
        self.widget = QtWidgets.QWidget(self.centralWidget)
        self.widget.setGeometry(QtCore.QRect(90, 20, 261, 191))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(11, 11, 11, 11)
        self.verticalLayout.setSpacing(6)
        self.verticalLayout.setObjectName("verticalLayout")
        self.stackedWidget = QtWidgets.QStackedWidget(self.widget)
        self.stackedWidget.setObjectName("stackedWidget")
        self.page = QtWidgets.QWidget()
        self.page.setObjectName("page")
        self.pushButton = QtWidgets.QPushButton(self.page)
        self.pushButton.setGeometry(QtCore.QRect(70, 70, 89, 25))
        self.pushButton.setObjectName("pushButton")
        self.stackedWidget.addWidget(self.page)
        self.page_2 = QtWidgets.QWidget()
        self.page_2.setObjectName("page_2")
        self.radioButton = QtWidgets.QRadioButton(self.page_2)
        self.radioButton.setGeometry(QtCore.QRect(50, 50, 112, 23))
        self.radioButton.setObjectName("radioButton")
        self.stackedWidget.addWidget(self.page_2)
        self.verticalLayout.addWidget(self.stackedWidget)
        self.toolButton = QtWidgets.QToolButton(self.widget)
        self.toolButton.setObjectName("toolButton")
        self.verticalLayout.addWidget(self.toolButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        MainWindow11.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(MainWindow11)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 400, 22))
        self.menuBar.setObjectName("menuBar")
        MainWindow11.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(MainWindow11)
        self.mainToolBar.setObjectName("mainToolBar")
        MainWindow11.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(MainWindow11)
        self.statusBar.setObjectName("statusBar")
        MainWindow11.setStatusBar(self.statusBar)

        self.retranslateUi(MainWindow11)
        self.stackedWidget.setCurrentIndex(1)
        print type(self.stackedWidget.currentIndex())
        # self.pushButton_2.clicked.connect(self.stackedWidget.setCurrentIndex(self.stackedWidget.currentIndex())
        self.pushButton_2.clicked.connect(self.toggle1)
        # self.pushButton_2.clicked.connect(self.stackedWidget.update)
        QtCore.QMetaObject.connectSlotsByName(MainWindow11)

    def toggle1(self):
        self.stackedWidget.setCurrentIndex(self.stackedWidget.currentIndex()^1)

    def retranslateUi(self, MainWindow11):
        _translate = QtCore.QCoreApplication.translate
        MainWindow11.setWindowTitle(_translate("MainWindow11", "MainWindow11"))
        self.pushButton.setText(_translate("MainWindow11", "PushButton"))
        self.radioButton.setText(_translate("MainWindow11", "RadioButton"))
        self.toolButton.setText(_translate("MainWindow11", "..."))
        self.pushButton_2.setText(_translate("MainWindow11", "PushButton"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow11 = QtWidgets.QMainWindow()
    ui = Ui_MainWindow11()
    ui.setupUi(MainWindow11)
    MainWindow11.show()
    sys.exit(app.exec_())
