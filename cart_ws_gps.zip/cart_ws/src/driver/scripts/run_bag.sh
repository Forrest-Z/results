#!/usr/bin/env bash

mkdir ~/bagfiles
cd ~/bagfiles
rosbag record -a