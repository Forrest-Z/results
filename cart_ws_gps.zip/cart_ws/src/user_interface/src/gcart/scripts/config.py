#!/usr/bin/env python

#host = "http://localhost:8080"
# host = "https://mobilebackend-1291.appspot.com"
# host = "https://mobilebackend-1291.appspot.com"
host = "https://us-central1-golfcart-f28c0.cloudfunctions.net/api/"