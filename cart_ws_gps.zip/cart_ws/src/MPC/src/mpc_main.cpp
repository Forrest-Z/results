#include "ros/ros.h"
#include <fstream>
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Float64.h"
#include "std_msgs/UInt16.h"
#include "nav_msgs/Path.h"
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/TransformStamped.h"
#include "nav_msgs/Odometry.h"
#include "tf/tf.h"
#include <math.h>
#include <chrono>
#include <iostream>
#include <thread>
#include <vector>
#include "Eigen-3.3/Eigen/Core"
#include "Eigen-3.3/Eigen/QR"
#include "MPC.h"
#include <dbw/steerCart.h>
#include <dbw/startCart.h>
//#include <gps_waypoints/getLineSegment.h>
//#include <gcart/GolfCartBooking.h>



constexpr double pi() { return M_PI; }
double deg2rad(double x) { return x * pi() / 180; }
double rad2deg(double x) { return x * 180 / pi(); }
#define SPDCTRL_2_MPS	0.00136
#define MIN_WP_DIST 	10
#define MIN_TGT_DIST 	5

// Evaluate a polynomial.
double polyeval(Eigen::VectorXd coeffs, double x) 
{
	double result = 0.0;
	for (int i = 0; i < coeffs.size(); i++) 
	{
		result += coeffs[i] * pow(x, i);
	}
	return result;
}


MPC mpc;

// Fit a polynomial.
// Adapted from
// https://github.com/JuliaMath/Polynomials.jl/blob/master/src/Polynomials.jl#L676-L716
Eigen::VectorXd polyfit(Eigen::VectorXd xvals, Eigen::VectorXd yvals, int order) 
{
	assert(xvals.size() == yvals.size());
	assert(order >= 1 && order <= xvals.size() - 1);
	Eigen::MatrixXd A(xvals.size(), order + 1);

	for (int i = 0; i < xvals.size(); i++) 
	{
		A(i, 0) = 1.0;
	}

	for (int j = 0; j < xvals.size(); j++) 
	{
		for (int i = 0; i < order; i++) 
		{
			A(j, i + 1) = A(j, i) * xvals(j);
		}
	}

	auto Q = A.householderQr();
	auto result = Q.solve(yvals);
	return result;
}

double curr_x ;
double curr_y ;
double curr_theta ;
double curr_v ;
int curr_v_level ;
double curr_delta ;
double curr_throttle ;

unsigned char steerReceived = 0 ;
unsigned char gpsReceived = 0 ;
unsigned char compassReceived = 0 ;
unsigned char speedReceived = 0 ;
unsigned char locReceived = 0 ;

void steerCallback( const std_msgs::Float32::ConstPtr& msg )
{
        //printf( "steer recvd\n" ) ;
	steerReceived = 1 ;
	curr_delta = deg2rad( -msg->data ) ;
}

void gpsCallback(const geometry_msgs::TransformStamped::ConstPtr& msg )
{
    	//printf( "gps recvd\n" ) ;
	gpsReceived = 1 ;
        locReceived = 1 ;

	curr_x = msg->transform.translation.x ;
        curr_y = msg->transform.translation.y ;
	
}

void compassCallback(const std_msgs::Float64::ConstPtr& msg )
{

        //printf( "cmps recvd\n" ) ;
	compassReceived = 1 ;
	curr_theta = deg2rad( 360 - msg->data ) ; // SDB1 GEC

	if( curr_theta > rad2deg(359) )
	{
		curr_theta -= rad2deg(360) ;
	}
	
}

std::string appStatus = "IDLE" ;

void appCallback(const std_msgs::String::ConstPtr& msg )
{
	appStatus = msg->data ;
	std::cout << "In mode - " << appStatus << std::endl ;
}
	

void speedCallback(const std_msgs::UInt16::ConstPtr& msg )
{
	
        //printf( "speed recvd\n" ) ;
	speedReceived = 1 ;
	curr_v_level = msg->data ;
	curr_v = msg->data * SPDCTRL_2_MPS ;
}

std::vector<geometry_msgs::PoseStamped> currentPath ;

void pathCallback(const nav_msgs::Path::ConstPtr& msg )
{
	currentPath = msg->poses ;

}



double distPts( double x0, double y0, double x1, double y1 )
{
	return( sqrt( pow( x1 - x0, 2 ) + pow( y1 - y0, 2 ) ) ) ;
}

int main( int argc, char **argv )
{
	ros::init(argc, argv, "mpc");

	ros::NodeHandle n;

	ros::Subscriber steer_sub = n.subscribe( "/currentSteerAngle", 1, steerCallback );
        ros::Subscriber gps_sub = n.subscribe( "/gps_transform", 1, gpsCallback ) ;
        //ros::Subscriber compass_sub = n.subscribe( "/compass_angle", 1, compassCallback ) ;
        ros::Subscriber compass_sub = n.subscribe( "/mavros/global_position/compass_hdg", 1, compassCallback ) ;
	ros::Subscriber speed_sub = n.subscribe( "/currentSpeed", 1, speedCallback );
        ros::Subscriber app_sub = n.subscribe( "/gcart_status", 1, appCallback ) ;
        ros::Subscriber path_sub = n.subscribe( "/mpc_trajectory", 1, pathCallback ) ;

	ros::ServiceClient steerService = n.serviceClient<dbw::steerCart>("steerCart");
	ros::ServiceClient startService = n.serviceClient<dbw::startCart>("startCart");
	//ros::ServiceClient getWayPoint = n.serviceClient<gps_waypoints::getLineSegment>("/get_line_segment");
	//ros::ServiceClient finishTrip = n.serviceClient<gcart::GolfCartBooking>("/golf_cart_booking_finish_push");

	ros::Rate loop_rate( 1/MPC_DT ) ;

	//float nextWPx = 0 ;
	//float nextWPy = 0 ;

	int accelCount = 25 ;

	dbw::startCart startServInp ;

	/*

	vector<double> waypoints_x ; 
	vector<double> waypoints_y ; 

	std::ifstream in( argv[1] ) ;
	if (!in.is_open()) return 1;

	std::string line;
	while (std::getline(in,line))
	{
		std::istringstream ss(line);
		std::string token;
		int count=0;
		std::cout << "ss=" << line << std::endl;
		geometry_msgs::Point waypoint;
		while(std::getline(ss, token, ',')) {
			if(count == 0)
				waypoint.x = boost::lexical_cast<float>(token);
			else if(count == 1)
				waypoint.y = boost::lexical_cast<float>(token);
			else if(count == 2)
				waypoint.z = boost::lexical_cast<float>(token);
			count++;
			}
			//waypointsList.push_back(waypoint);

			waypoints_x.push_back( waypoint.x ) ;
			waypoints_y.push_back( waypoint.y ) ;

			printf( "Point - %f, %f\n", waypoint.x, waypoint.y ) ;
	}

	int numWaypoints = waypoints_x.size() ;

	double target_x = waypoints_x[ numWaypoints - 1 ] ;
	double target_y = waypoints_y[ numWaypoints - 1 ] ;

	unsigned int seqIndex = 0 ;

	printf( "Target - %f, %f\n", target_x, target_y ) ;

	unsigned int firststop = false ;

	float stopx = 48 ;
	float stopy = 1;

	*/

	while( ros::ok() )
	{
		ros::spinOnce();

		if( ! ( steerReceived && locReceived && speedReceived && compassReceived ) )
			continue ;


		double px = curr_x ;
		double py = curr_y ;
		double psi = curr_theta ;

		double v = 1.6 ;// = curr_v ;
		double steer_curr = curr_delta ;
		double throttle_curr = 0 ; //curr_throttle ;

		double latency = 0.1 ;

		//mpc.AdjustLatency( px, py, psi, v, steer_curr, throttle_curr, latency ) ;

		/*

		if( distPts( px, py, target_x, target_y ) < MIN_TGT_DIST )
		{
	
			startServInp.request.level = 0 ;
			startService.call( startServInp ) ; 

			break ;
		}

		if( distPts( px, py, target_x, target_y ) < MIN_TGT_DIST )
		{
	
			startServInp.request.level = 0 ;
			startService.call( startServInp ) ; 

			break ;
		}
		*/



		vector<double> ptsx ; 
		vector<double> ptsy ;

		/*

		float minDist = MIN_WP_DIST ;
		unsigned int minIndex = seqIndex ;

		for( int wpC = seqIndex ; wpC < numWaypoints ; wpC++ )
		{
			double ptDist = distPts( px, py, waypoints_x[wpC], waypoints_y[wpC] ) ;

			if( ptDist < MIN_WP_DIST )
			{
				ptsx.push_back( waypoints_x[wpC] ) ;
				ptsy.push_back( waypoints_y[wpC] ) ;

				if( ptDist < minDist )
				{
					minDist = ptDist ;
					minIndex = wpC ;
				}
				
			}
			else
				break ;
		}

		seqIndex = minIndex ;
		*/

		if( currentPath.size() == 0 )
		{
			startServInp.request.level = 0 ;
			startService.call( startServInp ) ;
			continue;
		}

		for( int pCount = 0 ; pCount < currentPath.size() ; pCount++ )
		{
			ptsx.push_back( currentPath[pCount].pose.position.x ) ;
			ptsy.push_back( currentPath[pCount].pose.position.y ) ;
		}

		


		// Transform waypoints to vehicle coordinates
		for( unsigned int wPt = 0 ; wPt < ptsx.size() ; wPt++ )
		{
			double px_Offset = ptsx[wPt] - px ;
			double py_Offset = ptsy[wPt] - py ;

			ptsx[wPt] = px_Offset * cos(psi) + py_Offset * sin(psi) ;
			ptsy[wPt] = py_Offset * cos(psi) - px_Offset * sin(psi) ; 
		}

		// Convert points to VectorXd (for polyfit)
		// Pointers to start of vector
		double * ptrx = &ptsx[0] ;
		double * ptry = &ptsy[0] ;

		// Map to VectorXd
		Eigen::Map<Eigen::VectorXd> ptsx_transform( ptrx, ptsx.size() ) ;
		Eigen::Map<Eigen::VectorXd> ptsy_transform( ptry, ptsy.size() ) ;

		// Fit waypoints to 3-degree polynomial curve
		auto coeffs = polyfit( ptsx_transform, ptsy_transform, 2 ) ;

		// Define CTE as the error between start of desired trajectory
		// and current vehicle position
		double cte = polyeval( coeffs, 0 ) ;

		// Define orientation error as the difference between
		// vehicle orientation (0) and the approx tangent of trajectory
		// at the zero position
		double epsi = -atan( coeffs[1] ) ;

		// Prepare state vector
		Eigen::VectorXd state(6) ;

		state << 0, 0, 0, v, cte, epsi ; 

		double steer_value;
		double throttle_value;
		vector<double> results ;


		//cout << "state: " << state << endl ;
		//cout << "coeffs: " << coeffs << endl ;

		results = mpc.Solve( state, coeffs ) ;

		steer_value = results[0] * ANG_2_STEER  ;
		throttle_value = results[1] * ACC_2_THRTL ;

		std::cout << ">>> Steer :" << rad2deg( -steer_value ) << ", Throttle : " << throttle_value << std::endl ;

		dbw::steerCart steerServInp ;
		steerServInp.request.angle = rad2deg( -steer_value ) ;
		steerService.call( steerServInp ) ; 

		accelCount += 1 ;

		if( appStatus.compare( "TO_PICKUP_POINT" ) != 0 && appStatus.compare( "TO_DESTINATION" ) != 0 )
		{
			startServInp.request.level = 0 ;
			startService.call( startServInp ) ; 

			std::cout << ">>>>>>>>>>>>>> Speed 0" << std::endl ;
		}
		else
		{
			if( accelCount >= 30 )
			{
				accelCount = 0 ;

				if( curr_v_level < 560 )
				{
					startServInp.request.level = 1 ;
					startService.call( startServInp ) ; 
					std::cout << ">>>>>>>>>>>>>> Speed 1" << std::endl ;
				}
				else if( curr_v_level < 720 )
				{
					startServInp.request.level = 2 ;
					startService.call( startServInp ) ; 
					std::cout << ">>>>>>>>>>>>>> Speed 2" << std::endl ;
				}
				else if( curr_v_level >= 720 )
				{
					startServInp.request.level = 3 ;
					startService.call( startServInp ) ; 
					std::cout << ">>>>>>>>>>>>>> Speed 3" << std::endl ;
				}

			}
		}
				
			

		loop_rate.sleep();
	}

  return 0;

}
