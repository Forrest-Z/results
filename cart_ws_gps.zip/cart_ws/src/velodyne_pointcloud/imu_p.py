#!/usr/bin/env python
from sensor_msgs.msg import Imu
import rospy
import numpy as np
import tf

def callback(msg):
    quaternion = (
        msg.orientation.x,
        msg.orientation.y,
        msg.orientation.z,
        msg.orientation.w)
    eul = tf.transformations.euler_from_quaternion(quaternion)
    # roll = euler[0]
    # pitch = euler[1]
    # yaw = euler[2]
    # eul=tf.transformations.euler_from_quaternion(msg.orientation)
    print(eul[0]*180/np.pi,eul[1]*180/np.pi,eul[2]*180/np.pi)

if __name__== "__main__":

    rospy.init_node( 'quater', anonymous=True) 
    rospy.Subscriber('/mavros/imu/data', Imu, callback)
    rospy.spin()
  