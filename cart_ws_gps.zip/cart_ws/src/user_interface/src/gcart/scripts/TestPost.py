#!/usr/bin/env python

import requests
import rospy
import geocoder
import datetime
import json

from gcart.srv import *
from config import *
import sys
import datetime
import rospy
import time
from sensor_msgs.msg import NavSatFix
from gcart.srv import *
import requests
import json
from std_msgs.msg import String
# from golf_cart_push import *
from gps_distance import gps_distance_fn
from math import fabs
# from easydict import EasyDict as edict


def GolfCartBookingFinish_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'golfcart/finishTour'
    data={
    "name": req.name,
    "bookingReference": req.bookingReference
        }
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data=json.dumps(data), headers=headers)

    print(r.content)
    datastore = json.loads(r.content)

    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    #resp.bookingref = datastore['reference']
    return resp

def GolfCartBookingAccept_handler(req):
    print "Requested [%s]" % (req.name)

    # url = host+'/_ah/api/golfCartApi/v1/golfCart/booking/accept/' + req.name
    url = host+'golfcart/acceptBooking'
    # r = requests.get(url)
    print "2"
    data={
    "name": req.name,
    "bookingReference": req.bookingReference
        }
    print "3"
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data=json.dumps(data), headers=headers)
    print "5"
    print(r.content)
    datastore = json.loads(r.content)
    print "6"

    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    #resp.bookingref = datastore['reference']
    return resp


def GolfCartBookingStarted_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'golfcart/startTour'
    # url = "https://us-central1-golfcart-f28c0.cloudfunctions.net/api/golfcart/startTour"
    data={
    "name": req.name,
    "bookingReference": req.bookingReference,
    "OTP": req.OTP
        }
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data=json.dumps(data), headers=headers)

    

    print(r.content)
    datastore = json.loads(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    #resp.bookingref = datastore['reference']
    return resp

def GolfCartReleaseBooking_handler(req):
    print "Release Requested for cart [%s]" % (req.name)

    url = host+'golfcart/releaseBooking' # release the cart api call

    data={
    "name": req.name,
    "bookingReference": req.bookingReference
        }
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data=json.dumps(data), headers=headers)

    datastore = json.loads(r.content)
    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']       # status fetched back should be available
    resp.bookingref = ""
    return resp


def GolfCartBookingArrival_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'golfcart/alertArrival'
    data={
    "name": req.name,
    "bookingReference": req.bookingReference
        }
    
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    
    r = requests.post(url, data=json.dumps(data), headers=headers)

    print(r.content)
    datastore = json.loads(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    #resp.bookingref = datastore['reference']
    return resp

def GolfCartBookingAssigned_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'golfcart/currentBookings/' + req.name
    
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore[0]['status']
    resp.bookingref = datastore[0]['reference']
    return resp



rospy.init_node('TestPost')

sGCBAR = rospy.Service('golf_cart_booking_arrival_push',
                      GolfCartBooking, GolfCartBookingArrival_handler)
sGCBAC = rospy.Service('golf_cart_booking_accept_push',
                    GolfCartBooking, GolfCartBookingAccept_handler)
sGCBST = rospy.Service('golf_cart_booking_started_push',
                      GolfCartBooking, GolfCartBookingStarted_handler)
sGCBFI = rospy.Service('golf_cart_booking_finish_push',
                      GolfCartBooking, GolfCartBookingFinish_handler)

sGCRBO = rospy.Service('golf_cart_release_booking',
                      GolfCartBooking, GolfCartReleaseBooking_handler)

sGCBAS = rospy.Service('golf_cart_booking_assigned_pull',
                      GolfCartBooking, GolfCartBookingAssigned_handler)

bookingid = "book-2jqgq5uzy"
OTP = "9975"

# rospy.wait_for_service('golf_cart_booking_assigned_pull')
# execute = rospy.ServiceProxy('golf_cart_booking_assigned_pull', GolfCartBooking)
# resp1 = execute("Mys_cart1","","")

# rospy.wait_for_service('golf_cart_booking_accept_push')
# execute = rospy.ServiceProxy('golf_cart_booking_accept_push', GolfCartBooking)
# resp1 = execute("Mys_cart1", bookingid,"")

# rospy.wait_for_service('golf_cart_booking_arrival_push')
# execute = rospy.ServiceProxy('golf_cart_booking_arrival_push', GolfCartBooking)
# resp1 = execute("Mys_cart1",bookingid,"")

# rospy.wait_for_service('golf_cart_booking_started_push')
# execute = rospy.ServiceProxy('golf_cart_booking_started_push', GolfCartBooking)
# resp1 = execute("Mys_cart1", bookingid,OTP)
            

# rospy.wait_for_service('golf_cart_booking_finish_push')
# execute = rospy.ServiceProxy('golf_cart_booking_finish_push', GolfCartBooking)
# resp1 = execute("Mys_cart1", bookingid,"")


rospy.wait_for_service('golf_cart_release_booking')
execute = rospy.ServiceProxy('golf_cart_release_booking', GolfCartBooking)
resp1 = execute("Mys_cart1",bookingid,"")



print "##############"

print resp1.status

if ("Error: Error: OTP doesn't match" == resp1.status):
    print "OTP Error" 
