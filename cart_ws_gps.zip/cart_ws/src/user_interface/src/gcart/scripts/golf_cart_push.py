from tkinter import *
import sys
import rospy
# from gcart.srv import *
# from golf_cart_app_main_client import cart_has_started
from std_msgs.msg import String

top = Tk()
###images
image_pick    = PhotoImage(file='00_To_Pick-up.png')
image_start   = PhotoImage(file='01_Ride-START-button.png')
image_enroute = PhotoImage(file='02_ONROUTE.png')
image_Reached = PhotoImage(file='03_DESTINATION_REACHED_button.png')
image_idle    = PhotoImage(file='04_Cart_IDEL.png')



gcart_status="IDLE"
def cart_started_callback():
    global B1, GUI_to_Cart_topic_handle 
    global image_idle, image_pick, image_start, image_enroute, image_Reached 

    print("in button call back: ", gcart_status)
    if gcart_status =="WAITING":
        # B1.configure(image=image_enroute)
        GUI_to_Cart_topic_handle.publish("Start_button_pressed")
    if gcart_status =="REACHED_DESTINATION":    
        # B1.configure(image=image_start)
        GUI_to_Cart_topic_handle.publish("Release_button_pressed")
    B1.flash()
    
def status_callback(status):
    global B1, gcart_status 
    # print("in topic call back: ", status.)
    print("in topic call back: ", status.data)                
    if status.data =="IDLE":
        gcart_status="IDLE"
    elif status.data =="TO_PICKUP_POINT":
        gcart_status="TO_PICKUP_POINT"
    elif status.data =="WAITING":
        gcart_status="WAITING"
    elif status.data =="TO_DESTINATION":
        gcart_status="TO_DESTINATION"
    elif status.data =="REACHED_DESTINATION":
        gcart_status="REACHED_DESTINATION"

# B1 = Button(top,  image=image_idle,  command = cart_started_callback )
B1 = Button(top,  image=image_idle,  command = cart_started_callback )

GUI_to_Cart_topic_handle = 1

if __name__ == "__main__":
    try:
        rospy.init_node('golf_cart_GUI')
    
        rospy.Subscriber("/gcart_status",String, status_callback)
        GUI_to_Cart_topic_handle = rospy.Publisher("/gui_to_gcart",String, queue_size=1, latch=True )
        rate =rospy.Rate(2)
        B1.pack()
        while not rospy.is_shutdown():
        # while True:
            if gcart_status =="IDLE":
                B1.configure(image=image_idle)
            elif gcart_status =="TO_PICKUP_POINT":
                B1.configure(image=image_pick)
            elif gcart_status =="WAITING":
                B1.configure(image=image_start)
                # GUI_to_Cart_topic_handle.publish("Start_button_pressed")
                print("Start button pressed") 
            elif gcart_status =="TO_DESTINATION":
                B1.configure(image=image_enroute)
            elif gcart_status =="REACHED_DESTINATION":
                B1.configure(image=image_Reached)
                # GUI_to_Cart_topic_handle.publish("Release_button_pressed")
            top.update_idletasks()
            top.update()
        # top.mainloop()
            # rate.sleep()
    except rospy.ROSInterruptException:
        pass
        
