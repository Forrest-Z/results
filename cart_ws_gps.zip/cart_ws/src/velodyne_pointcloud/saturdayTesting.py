#!/usr/bin/env python


import numpy as np
import math as MT
import constants as constant
import rospy
from sensor_msgs.msg import NavSatFix 
from std_msgs.msg import Float64, Int8
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped,TransformStamped
import constants2 as constant
import tf
import matplotlib.pyplot as plt
import time

class values:
  def __init__(self,grid_on_x,grid_on_y,resolution,GRID_TEST,start_global):
    self.grid_on_x=grid_on_x
    self.grid_on_y=grid_on_y
    self.resolution=resolution
    self.GRID_TEST=GRID_TEST
    self.start_global=start_global
    self.feed_map=True
    self.get_start_point=True
    self.got_compass=False
    self.compass=0
    self.path=[]
    self.lane_change = True
    self.start_time = time.time()
    self.lane_obstacle_counter=[0,0]



        

class waypoints():
    def __init__(self,input_co_ordinates,center):
        self.input_co_ordinates=input_co_ordinates
        self.center=center

### LANE CLASS
class vehicle_params():
  def __init__(self,lane_number,goal_lane,state):
    self.lane_number=lane_number
    self.goal_lane=goal_lane
    self.state=state

def transform_frame_co_ordinates(current_frame_waypoints_obj,localization):
    wp_list=[]
    for wp in current_frame_waypoints_obj.input_co_ordinates:
      psi=localization[2]
      px_Offset = wp[0] - localization[0]
      py_Offset = wp[1] - localization[1]  
      ptsx = px_Offset * MT.cos(psi) + py_Offset * MT.sin(psi) 
      ptsy = py_Offset * MT.cos(psi) - px_Offset * MT.sin(psi)
      wp_list.append([ptsx,ptsy])
    
    return constant.vehicle_points(np.array(wp_list), localization)

def closest_index(lane_index,localized_point):
  lane_waypoints=constant.waypoints_list[lane_index]
  waypoints_tree=constant.waypoint_tree_list[lane_index]
  closest_idx=waypoints_tree.query(localized_point,1)[1]
  closest_coord=lane_waypoints[closest_idx][:2]
  prev_coord=lane_waypoints[closest_idx-1][:2]
  cl_vect=np.array(closest_coord)
  prev_vect=np.array(prev_coord)
  pos_vect=np.array(localized_point)
  val= np.dot(cl_vect-prev_vect,pos_vect-cl_vect)
  if val>0:
    temp=closest_idx
    closest_idx=(closest_idx+1)%len(lane_waypoints)
    if(closest_idx==0 and temp>0):
      closest_idx=temp
  return closest_idx,lane_waypoints[closest_idx:closest_idx+constant.offset_value]

### FLOOR VALUE
def idx(value):
  return int(MT.floor(value))


### TRANSFORM VEHICLE CO-ORDINATES 
def transform_vehicle_co_ordinates(vehicle_point_object, next_state, angle_of_rotation):
    displaced_matrix = np.array([next_state[0]-vehicle_point_object.center[0],next_state[1]-vehicle_point_object.center[1]])
    transformed_matrix=np.add(vehicle_point_object.input_co_ordinates,displaced_matrix)
    return constant.vehicle_points(rotate_vehicle_co_ordinates(constant.vehicle_points(transformed_matrix,next_state),angle_of_rotation),next_state)
  
  
### ROTATE VEHICLE CO-ORDINATES     
def rotate_vehicle_co_ordinates(vehicle_point_object,angle_of_rotation):
    rotation_matrix = np.array([[np.cos(angle_of_rotation), -np.sin(angle_of_rotation)], 
                                [np.sin(angle_of_rotation), np.cos(angle_of_rotation)]])
    return np.add(vehicle_point_object.center,np.matmul(np.subtract(vehicle_point_object.input_co_ordinates,vehicle_point_object.center), rotation_matrix))


### CHECK VEHICLE IN SAFE POSITION  
def is_vehicle_in_safe_position(vehicle_point_object,grid):
  grid_on_x=len(grid[0])
  grid_on_y=len(grid)
  for point in vehicle_point_object.input_co_ordinates:
    if(is_within_grid( idx(point[0]),idx(point[1]),grid_on_x,grid_on_y) and  
       (grid[idx(point[0])][idx(point[1])]==0)):
      continue
    else:
      return False
  return True

### CHECK WITHIN GRID  
def is_within_grid(x,y,grid_on_x,grid_on_y):
  return (x>=0 and x<grid_on_x and y>=0 and y<grid_on_y)

# def validate_safe(waypoints,vehicle_pt_obj_actual,grid,lane_num):
#   counter=0
#   for wp in waypoints:
#     counter+=1
#     #print(wp)
#     transformed_coordinates=transform_vehicle_co_ordinates(vehicle_pt_obj_actual,[wp[0],wp[1]],wp[2])
    
#     #print(transformed_coordinates.input_co_ordinates)
#     if(not is_vehicle_in_safe_position(transformed_coordinates,grid)):
#       print('validate_safe')
#       get_value.lane_obstacle_counter[lane_num]+=1
#       print("CHK",get_value.lane_obstacle_counter[lane_num])
#       if(counter<constant.minimum_count_obstacle_taken):
#         return False
#       elif(get_value.lane_obstacle_counter[lane_num]>constant.multiple_check_frames) :
#         get_value.lane_obstacle_counter[lane_num]=0
#         return False
#   get_value.lane_obstacle_counter[lane_num]=0
#   return True
def validate_safe(waypoints,vehicle_pt_obj_actual,grid,lane_num):
  for wp in waypoints:
    #print(wp)
    transformed_coordinates=transform_vehicle_co_ordinates(vehicle_pt_obj_actual,[wp[0],wp[1]],wp[2])
    #print(transformed_coordinates.input_co_ordinates)
    if(not is_vehicle_in_safe_position(transformed_coordinates,grid)):
      return False
  return True



# def successor_states(lane,lanes_available,state,localization):
#         """
#         Provides the possible next states given the current state for the FSM discussed in the course,
#         with the exception that lane changes happen instantaneously, so LCL and LCR can only transition back to KL.
#         """
#         if state in ("KL","STOP"):
#             states = ["KL","STOP"]
#             if lane != 0:
#                 states.append("LCL")
#             if lane != (lanes_available-1):
#                 states.append("LCR")
        
#         # elif state in ("LCL", "LCR"):
#         #     waypoints_lst=constant.waypoints_list[lane]
#         #     near_index=closest_index(lane,[localization[0],localization[1]])
#         #     cte=MT.sqrt((localization[0]-waypoints_lst[near_index][0])**2+
#         #     (localization[1]-waypoints_lst[near_index][1])**2)
#         #     if(cte<0.2):
#         #       states = ["KL","STOP"]
#         #     else:
#         #        states = [state,"STOP"]
        
#         # elif state in ("LCL", "LCR"):
#         #     states = ["KL","STOP"]

#         elif state =="LCL":
#              states = ["PLCL","STOP"]

#         elif state =="LCR":
#              states = ["PLCR","STOP"]

#         elif state == "PLCL":
#             print('cte',calculate_cte(lane,localization),state)
#             if(calculate_cte(lane,localization)<0.5):
              
#                 states = ["KL","STOP"]
#             else:
#                 states = ["PLCL","STOP"]
                
#         elif state == "PLCR":
#             print('cte',calculate_cte(lane,localization),state)
#             if(calculate_cte(lane,localization)<0.5):
#                 states = ["KL","STOP"]
#             else:
#                 states = ["PLCR","STOP"]
#         return states


def successor_states(lane,lanes_available,state,localization):
        """
        Provides the possible next states given the current state for the FSM discussed in the course,
        with the exception that lane changes happen instantaneously, so LCL and LCR can only transition back to KL.
        """
        if state in ("KL"):
            states = ["KL","STOP"]
            if get_value.lane_change == True:
              if lane != 0:
                  states.append("LCL")
              if lane != (lanes_available-1):
                  states.append("LCR")
            else:
              states.append("STAY")

        elif state in ("STOP"):
            if get_value.lane_change == True:
                states = ["KL","STOP"]
            elif get_value.preparing_lane_change==True:
                states = [get_value.preparing_to,"STOP"]
            else:
                states = ["STOP","STAY"]
        
        elif state =="LCL":
            get_value.lane_change = False
            states = ["PLCL","STOP"]

        elif state =="LCR":
            get_value.lane_change = False
            states = ["PLCR","STOP"]

        elif state == "PLCL":
            get_value.preparing_lane_change=True
            get_value.preparing_to="PLCL"
            #print('cte',calculate_cte(lane,localization),state)
            if(calculate_cte(lane,localization)<0.5):
                get_value.preparing_lane_change=False
                get_value.start_time = time.time()
                states = ["STAY","STOP"]
            else:
                states = ["PLCL","STOP"]
                
        elif state == "PLCR":
            get_value.preparing_lane_change=True
            get_value.preparing_to="PLCR"
            #print('cte',calculate_cte(lane,localization),state)
            if(calculate_cte(lane,localization)<0.5):
                get_value.preparing_lane_change=False
                get_value.start_time = time.time()
                states = ["STAY","STOP"]
            else:
                states = ["PLCR","STOP"]


        elif state == "STAY":
            # get_value.lane_change = False
            # states = ["STOP"]
            #if get_value.timer < get_value.wait_time:
            # print("TIME:", get_value.start_time - time.time())
            if get_value.start_time - time.time() < constant.wait_time:
              states=["STAY","STOP"]
            else :
              get_value.lane_change = True
              states=["KL","STOP"]
        return states
      
def calculate_cte(lane,localization):
    near_index,waypoints_lst=closest_index(lane,[localization[0],localization[1]])
    wp=waypoints_lst[:4]
    wp_x=[w[0] for w in wp]
    wp_y=[w[1] for w in wp]
    coeff=np.polyfit(wp_x,wp_y,2)
    cte=abs(np.polyval(coeff,localization[0])-localization[1])
    # print("CTE:",cte)
    # print("lane:",lane)
    return cte

def calculate_cost(lane_num,goal_lane,localization,grid):
    near_index,waypoints_set=closest_index(lane_num,[localization[0],localization[1]])
    wp_xy=np.array([[w[0]*1/get_value.resolution,w[1]*1/get_value.resolution] for w in waypoints_set])
    waypoint_obj=constant.vehicle_points(wp_xy,[localization[0]*1/get_value.resolution,localization[1]*1/get_value.resolution])
    local_wp=transform_vehicle_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)],localization[2])#0-
    #local_wp=transform_frame_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2),localization[2]])#0-
    
    #print(local_wp.input_co_ordinates)
    #waypoint_obj=waypoints(wp_xy,[localization[0]*1/get_value.resolution,localization[1]*1/get_value.resolution])
    #local_wp=transform_frame_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)])
    #local_wp=transform_frame_co_ordinates(waypoint_obj,[0,75])
    #get_value.path=local_wp.input_co_ordinates
    wp_theta=np.array([[w[2]-localization[2]] for w in waypoints_set])
    local_waypoint_set=np.hstack((local_wp.input_co_ordinates,wp_theta))
    # get_value.path=local_waypoint_set
    #show_path(local_waypoint_set,constant.vehicle_pt_obj_actual)
    if(validate_safe(local_waypoint_set,constant.vehicle_pt_obj_actual,grid,lane_num) and len(local_waypoint_set)>=1):
      delta_d=float(abs(lane_num-goal_lane))
      #print(delta_d)
      cost= 1 - MT.exp(-(abs(delta_d) / len(local_waypoint_set)))
      return cost,near_index,local_waypoint_set
    else:
      #print('in')
      return float('inf'),near_index,local_waypoint_set
    # get_value.path=
    
    
def choose_next_state(localization,grid):
        lanes_available = len(constant.waypoints_list)
        costs = []
        print('choose_next_state-vehicle_state.lane_number',vehicle_state.lane_number)
        states = successor_states(vehicle_state.lane_number,lanes_available,vehicle_state.state,localization)
        #print('states',states)
        for state in states:
          # print('--------------------------------------------')
          # print('selected state',state)
          value=constant.lane_direction[state]
          if value!=None:
            lane_index=vehicle_state.lane_number + value
            #print('selected state',state)
            # print('lane_index',lane_index)
            cost,near_index,path = calculate_cost(lane_index,vehicle_state.goal_lane,localization,grid)
            costs.append({"cost" : cost, "state": state,"lane_index":lane_index,"near_index":near_index,"path":path})
            #print("cost" , cost,'\n', "state": state,'\n',"lane_index":lane_index,'\n',"near_index":near_index)
          else:
            costs.append({"cost" : 100, "state": state,"lane_index":vehicle_state.lane_number,"near_index":0,"path":[]})
        #print(costs)   
        best = min(costs, key=lambda s: s['cost'])
        vehicle_state.lane_number=best["lane_index"]
        vehicle_state.state=best["state"]
        get_value.path=best["path"]
        # print('-----------------------')
        # print('STATE SELECTED : ',best["state"])
        # print('LANE INDEX',best["lane_index"])
        # print('-----------------------')
        return best["lane_index"],best["near_index"]


        
#def compass(value):
#  global compass
#  #print("Value:", value)
#  compass = value.data

#def localization(data):
#  global current_location, compass
#  lat = data.latitude
#  long_ = data.longitude
#  current_location = [lat, long_, compass]


def trigger_behaviour_planning(msg):
  if(get_value.get_start_point==True and get_value.feed_map==False):
    print('Behavior Planner Triggered!')
    # print(get_value.lane_obstacle_counter)
    get_value.get_start_point=False
    yaw = np.deg2rad(get_value.compass)
    #yaw=0
    get_value.start_global =[msg.transform.translation.x, msg.transform.translation.y, yaw]
    # br = tf.TransformBroadcaster()
    # br.sendTransform((msg.transform.translation.x, msg.transform.translation.y, 0),
    #                   tf.transformations.quaternion_from_euler(0, 0, yaw),
    #                   rospy.Time.now(),
    #                     "base_link",
    #                    "world")
    print('input point',get_value.start_global,yaw)
    get_value.start_global =[msg.transform.translation.x, msg.transform.translation.y, yaw]
    lane_index,near_index=choose_next_state(get_value.start_global,get_value.GRID_TEST)
    pub = rospy.Publisher('/local_trajectory', Path, queue_size=50)
    print('len(get_value.path)',len(get_value.path))
    path_pub=Path()
    path_pub.header.frame_id='local_map'
    for i in range(len(get_value.path)):#
      
      new_pose=PoseStamped()
      path_now=get_value.path[i]
      # print('path_now[2]',path_now[2]*180/np.pi)
      quaternion_map=tf.transformations.quaternion_from_euler(0.0, 0.0, path_now[2])
      new_pose.header.seq=i+1
      new_pose.header.frame_id='local_map'
      new_pose.pose.position.x=path_now[0]/(1/get_value.resolution)
      new_pose.pose.position.y=path_now[1]/(1/get_value.resolution)
      #print(new_pose.pose.position.x,new_pose.pose.position.y)
      new_pose.pose.position.z=0
      new_pose.pose.orientation.x= quaternion_map[0]
      new_pose.pose.orientation.y= quaternion_map[1]
      new_pose.pose.orientation.z= quaternion_map[2]
      new_pose.pose.orientation.w= quaternion_map[3]
      # new_pose.pose.orientation=path_now[3]
      path_pub.poses.append(new_pose)
      # rate = rospy.Rate(50)
      # start_time=time.time()
    pub.publish(path_pub)
    #print('path published')
    get_value.feed_map=True
    #get_value.is_processing=True
    get_value.get_start_point=True



def feed_map(msg):
  if(get_value.feed_map==True and get_value.got_compass):
  #if(get_value.feed_map==True):
    print('FEEDING THE MAP IN')
    get_value.feed_map=False
    local_grid=msg.data
    grid_on_x=msg.info.width
    grid_on_y=msg.info.height
    resolution=msg.info.resolution
    local_grid=np.flipud(np.rot90(np.reshape(local_grid,(grid_on_x,grid_on_y))))
    local_grid[local_grid != 0]=1
    get_value.GRID_TEST=local_grid
    get_value.resolution=resolution
    get_value.grid_on_x=get_value.grid_on_y=get_value.GRID_TEST.shape[0]

    # X=[]
    # Y=[]
    # for i in range(len(get_value.GRID_TEST)):
    #   for j in range(len(get_value.GRID_TEST[0])):
    #     if(get_value.GRID_TEST[i][j]==1):
    #         X.append(i)
    #         Y.append(j)
    # plt.scatter(X,Y)
    # plt.show()
  
def show_path(path,vehicle_pt_obj_act):
  X=[]
  Y=[]
  Theta=[]
  X     += [p[0] for p in path]
  Y     += [p[1] for p in path]
  Theta+=[p[2] for p in path]
  for i in range(len(X)-1):
    Xj=[]
    Yj=[]
    vehicle_pt_obj_now=transform_vehicle_co_ordinates(vehicle_pt_obj_act,[X[i],Y[i]], Theta[i])
    rev=vehicle_pt_obj_now.input_co_ordinates
    revI=rev[:4]
    revL=rev[4:]
    revF=np.concatenate([revI,revL[::-1]])
    l=np.append(revF,[revF[0]],axis=0)
    for i in l:
      Xj.append(i[0])
      Yj.append(i[1])
    plt.plot(Xj,Yj)
  plt.plot(X,Y, color='black')
  X=[]
  Y=[]
  for i in range(len(get_value.GRID_TEST)):
    for j in range(len(get_value.GRID_TEST[0])):
      if(get_value.GRID_TEST[i][j]==1):
          X.append(i)
          Y.append(j)
  plt.scatter(X,Y)
  plt.show()


get_value=values(0,0,0,np.array([]),[])
vehicle_state=vehicle_params(constant.present_lane,constant.goal_lane,constant.present_state)

def compass_callback(compass_data):
  #print('GOT COMPASS')
  inp=compass_data.data
  get_value.compass=360-inp
  get_value.got_compass=True

if __name__== "__main__":
  rospy.init_node( 'behavioural_planner', anonymous=True)      
  rospy.Subscriber('/local_map', OccupancyGrid, feed_map)
  rospy.Subscriber('/mavros/global_position/compass_hdg', Float64, compass_callback)
  rospy.Subscriber('/gps_transform', TransformStamped, trigger_behaviour_planning)
  rospy.spin()