#!/usr/bin/env python

import rospy
from sensor_msgs.msg import NavSatFix , Imu
from std_msgs.msg import Float64
from geometry_msgs.msg import TransformStamped
import message_filters
import numpy as np
import math

res = []
imu_value = []
comp= 0
 
def compass(value):
    global comp
    #print("Value:", value)
    print('comp',comp)
    comp = np.deg2rad(360-value.data)


def imu(data):
    global imu_value
    x = data.linear_acceleration.x
    y = data.linear_acceleration.y
    z = data.linear_acceleration.z
    #print(x,y,z, "I m here")
    imu_value = [x,y,z]

def fix(value):
    global res, imu_values, comp
    lat = value.latitude
    long_ = value.longitude
    res.append([lat, long_])
    print("g")
    print([lat, long_])
    np.save("./result.npy",res)




def position(value):
    #global res, imu_values, comp
    x = value.transform.translation.x
    y = value.transform.translation.y
    # z = value.transform.translation.z
    # quaternion_x = value.transform.rotation.x
    # quaternion_y = value.transform.rotation.y
    # quaternion_z = value.transform.rotation.z
    # quaternion_w = value.transform.rotation.w
    
    if(len(res)>0):
        x1=res[-1][0]
        y1=res[-1][1]
        dist=math.sqrt((x-x1)**2 + (y-y1)**2)
        if(dist>0.2):
            res.append([x,y,comp])
            
    elif(len(res)==0):
         res.append([x,y,comp])
    print(len(res))
    print(comp)
    #print([lat, long_])
    np.save("result.npy",res)



# def callback(sub_2, sub_3):
#     rospy.logerr("utf")
#     print("3")


if __name__== "__main__":

    rospy.init_node( 'sync', anonymous=True)  
    
    sub_compasss = rospy.Subscriber('/mavros/global_position/compass_hdg', Float64, compass)
    #sub_imu = rospy.Subscriber('/sensor_imu', Imu, imu)
    #sub_gps = rospy.Subscriber('/fix', NavSatFix, fix)
    #sub_xyz = rospy.Subscriber('/gps', NavSatFix, fix)
    sub_xyz = rospy.Subscriber('/gps_transform', TransformStamped, position)
    rospy.spin()
  
