#include "plcClass.hpp"
#include <stdio.h>
#include <iostream>
#include <errno.h>
#include <string>
#include <unistd.h>
#include "ros/ros.h"
#include "ros/console.h"
#include "dbw/startComm.h"
#include "dbw/stopComm.h"
#include "dbw/startCart.h"
#include "dbw/stopCart.h"
#include "dbw/steerCart.h"
#include "dbw/emergencyStop.h"
#include "dbw/cartIndicator.h"
#include "dbw/emgBrakeReset.h"
#include "std_msgs/Float32.h"
#include "std_msgs/UInt16.h"

using namespace std;

PLC_MODBUS plcObj ;
unsigned char emergencyStopFlag=0;

bool startComm( dbw::startComm::Request  &req,
		dbw::startComm::Response  &res )
{
	ROS_INFO( "Request: Start Comm, Device: %s", req.device_name.c_str() ) ;

	if( plcObj.setupModbusComm( req.device_name.c_str() ) != -1)
	{
		if(plcObj.connectPLC() == -1)
		{
			ROS_INFO( "Error connecting to PLC" ) ;
			res.status = 1 ;
			return true;
		}	
	}
	else
	{
		ROS_INFO( "Error setting up MODBUS connection" ) ;
		res.status = 2 ;
		return true;
	}

	usleep(100000);
	res.status = 0 ;
	return true;
}

bool stopComm( dbw::stopComm::Request  &req,
		dbw::stopComm::Response  &res )
{
	ROS_INFO( "Request: Stop Comm") ;
	plcObj.closeModbusComm();
	res.status = 0 ;
	return true;
}

bool startCart( dbw::startCart::Request  &req,
		dbw::startCart::Response  &res )
{
	res.status = 0 ;

	if(emergencyStopFlag == 1)
		return true;

	ROS_INFO( "Request: Start Command - %d", req.level ) ;
	plcObj.setVehicleDirection(plcObj.VEHICLE_FORWARD_DIRECTION);

	plcObj.resetVehicleBrakes() ;

	//setpoint between 0 and 10
	ROS_INFO( "Changing speed to %d", req.level ) ;
	plcObj.setVehicleSpeed(req.level);
	return true;
}

bool stopCart( dbw::stopCart::Request  &req,
		dbw::stopCart::Response  &res )
{
	res.status = 0 ;
	ROS_INFO( "Request: Stop Command") ;
	ROS_INFO( "Changing speed to 0" ) ;
	plcObj.setVehicleSpeed(0);
	plcObj.setVehicleBrakes();
	return true;
}

bool steerCart( dbw::steerCart::Request  &req,
		dbw::steerCart::Response  &res )
{
	res.status = 0 ;
	float steerAngle=0;

	if(emergencyStopFlag == 1)
		return true;

	ROS_INFO( "Request: Steer Command") ;
	plcObj.readSteeringAngle(steerAngle);
	ROS_INFO( "current steering angle is %f", steerAngle);
	steerAngle = req.angle ;

	plcObj.setSteeringAngle(steerAngle);
	ROS_INFO("changing steering angle to %f", steerAngle);
	return true;
}

bool emergencyStop( dbw::emergencyStop::Request  &req,
					dbw::emergencyStop::Response  &res )
{
	res.status = 0 ;
	ROS_INFO( "Request: Emergency Stop Command") ;

	emergencyStopFlag = req.toggle;
	
	//setpoint between 0 and 10
	plcObj.setVehicleSpeed(0);
	if(emergencyStopFlag == 1)
		plcObj.setVehicleBrakes();
	else
		plcObj.resetVehicleBrakes();

	return true;
}

bool cartIndicator( dbw::cartIndicator::Request  &req,
					dbw::cartIndicator::Response  &res )
{
	res.status = 0 ;

	ROS_INFO( "Request: cartIndicator - %d", req.type ) ;
	plcObj.cartIndicator(req.type);

	return true;
}

bool emgBrakeReset( dbw::emgBrakeReset::Request  &req,
					dbw::emgBrakeReset::Response  &res )
{
	res.status = 0 ;

	ROS_INFO( "Request: emgBrakeReset" ) ;
	plcObj.resetEmgBrakes() ;

	return true;
}

int main(int argc, char **argv)
{
	ros::init( argc, argv, "dbwCart" );
	ros::NodeHandle n;

	ros::ServiceServer startCartService = n.advertiseService("startCart", startCart );
	ros::ServiceServer stopCartService = n.advertiseService("stopCart", stopCart );
	ros::ServiceServer startCommService = n.advertiseService("startComm", startComm );
	ros::ServiceServer stopCommService = n.advertiseService("stopComm", stopComm );
	ros::ServiceServer steerCartService = n.advertiseService("steerCart", steerCart );
	ros::ServiceServer emergencyStopService = n.advertiseService("emergencyStop", emergencyStop );
	ros::ServiceServer cartIndicatorService = n.advertiseService("cartIndicator", cartIndicator );
	ros::ServiceServer emgBrakeResetService = n.advertiseService("emgBrakeReset", emgBrakeReset );

	ros::Publisher steer_pub = n.advertise<std_msgs::Float32>("currentSteerAngle",1);
	ros::Publisher speed_pub = n.advertise<std_msgs::UInt16>("currentSpeed",1);


	if(argc < 2)
	{
		cout << "dev name missing in argument" << endl;
		exit(-1);
	}

	if(plcObj.setupModbusComm(argv[1]) != -1){
		if(plcObj.connectPLC() != -1){

		}
		else{
			cout << "error connecting to plc" << endl;
			return -1;
		}
			
	}
	else{
		cout << "error setting up modbus" << endl;
		return -1;
	}


	ros::Rate loop_rate(10);
	std_msgs::Float32 steerAngle;
	float readAngle=0;
	std_msgs::UInt16 cartSpeed;
	uint16_t readSpeed; 
	uint8_t cartMode=0;

	int count=0;

	//Wait till cart is put to Auto Mode
	while(cartMode != 1){
		plcObj.readSteeringAngle(readAngle);

		std::cout << "Angle" << readAngle << std::endl  ;

		plcObj.readCartMode(cartMode);
		std::cout << "Cart in manual mode, switch to auto" << std::endl;
		usleep(1000000);

	}

	ROS_INFO( "Ready to accept controls..." ) ;

	while(ros::ok())
	{
		if( ++count == 1 ){
			plcObj.readSteeringAngle(readAngle);
			steerAngle.data = readAngle;
			steer_pub.publish(steerAngle);


			plcObj.readCartSpeed(readSpeed);
			cartSpeed.data = readSpeed;
			speed_pub.publish(cartSpeed);

			uint8_t rvalue ;
			uint16_t dvalue ;
			unsigned int madd ;
			unsigned int dadd ;
		
			/*
			madd = 0x806 ;
			plcObj.readM( madd, rvalue ) ;
			printf( "\tM%d:\t%d", madd - 0x800, rvalue );

			madd = 0x8CB ;
			plcObj.readM( madd, rvalue ) ;
			printf( "\tM%d:\t%d", madd - 0x800, rvalue );

			madd = 0x995 ;
			plcObj.readM( madd, rvalue ) ;
			printf( "\tM%d:\t%d", madd - 0x800, rvalue );

			madd = 0x996 ;
			plcObj.readM( madd, rvalue ) ;
			printf( "\tM%d:\t%d", madd - 0x800, rvalue );

			madd = 0x997 ;
			plcObj.readM( madd, rvalue ) ;
			printf( "\tM%d:\t%d", madd - 0x800, rvalue );

			dadd = 0x1192 ;
			plcObj.readD( dadd, dvalue ) ;
			printf( "\tD%d:\t%d", dadd - 0x1000, dvalue );

			dadd = 0x17D0 ;
			plcObj.readD( dadd, dvalue ) ;
			printf( "\tD%d:\t%d", dadd - 0x1000, dvalue );

			printf( "\n" ) ;
			*/

			count=0;
		}

		ros::spinOnce();
		loop_rate.sleep();
	}
	ros::spin();

	return 0;
}
