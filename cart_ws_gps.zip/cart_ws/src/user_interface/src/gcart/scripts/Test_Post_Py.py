import requests
import json


def GolfCartLocationUpdater_handler():

    address = "Location" 
    print("Returning [%s]" % (address))
    url = 'https://us-central1-golfcart-f28c0.cloudfunctions.net/api/golfcart/updateLocation/' 
    print(url)
    data={
            "name": "Mys_cart1",
            "location": 
                     {
                        "latitude": 12.55555,
                        "longitude": 77.55555
                    }
        }
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    data1 = json.dumps(data)
    print data1
    r = requests.post(url, data=data1, headers=headers)
    print(r.content)
    return address

def GolfCartBookingAssigned_handler(req):
    print "Requested [%s]" % (req)

    url = 'https://us-central1-golfcart-f28c0.cloudfunctions.net/api/'+'golfcart/' + req
    print url
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = r.content
    return resp


GolfCartLocationUpdater_handler()
# GolfCartBookingAssigned_handler("Mys_cart1")