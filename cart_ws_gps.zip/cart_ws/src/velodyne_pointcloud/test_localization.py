#!/usr/bin/env python
from geometry_msgs.msg import TransformStamped
import rospy
import numpy as np



if __name__== "__main__":

    rospy.init_node( 'fake', anonymous=True) 
    # 0.05103129,  0.00906348,  0.01998733,  0.03285   , -0.02379   ,
    #    -0.01408   ,  0.999078     
    localization = TransformStamped()
    localization.transform.translation.x = 0.05103129
    localization.transform.translation.y =  0.00906348
    localization.transform.translation.z = 0.01998733
    localization.transform.rotation.x = 0.03285
    localization.transform.rotation.y = -0.02379
    localization.transform.rotation.z = -0.01408
    localization.transform.rotation.w = 0.999078  
    pub = rospy.Publisher('/gps_transform', TransformStamped, queue_size=10)
    while not rospy.is_shutdown():
        pub.publish(localization)
    rospy.spin()
  