var map;
var markers = [];
var flightPlanCoordinates = [];

function initMap() {
	map = new google.maps.Map(document.getElementById('map'), {
	  zoom: 17,
	  center: {lat: 12.360698, lng:76.596178},
	  mapTypeId: 'terrain'
	});
	flightPlanCoordinates = geo;
	buildPoints();
  }

function buildPoints(){
	console.log(flightPlanCoordinates.length);
	var image = 'cart.png';
	for(var i in flightPlanCoordinates){
		var cityCircle = new google.maps.Marker({
			//strokeColor: '#ff1a1a',
			//strokeOpacity: 0.8,
			//strokeWeight: 2,
			//fillColor: '#ff1a1a',
			//fillOpacity: 0.35,
			map: map,
			position : flightPlanCoordinates[i],
			//center : flightPlanCoordinates[i],
			//radius : 6,
			icon: image
		  });
		markers.push(cityCircle);
	}
	console.log("cleared markers");
	showMarkers();
}

function setMapOnAll(map) {
	for (var i = 0; i < markers.length; i++) {
	  markers[i].setMap(map);
	}
}

function showMarkers(){
	setMapOnAll(map);
}

function clearMarkers() {
	setMapOnAll(null);
}

function deleteMarkers() {
	clearMarkers();
	markers = [];
}

setInterval(function(){
	$.getScript("globals.js");
	//alert('hi');
	newflightPlanCoordinates = geo;
	if(JSON.stringify(newflightPlanCoordinates) != JSON.stringify(flightPlanCoordinates)){
		flightPlanCoordinates = newflightPlanCoordinates;
		deleteMarkers();
    	buildPoints();
	}	
}, 500);
