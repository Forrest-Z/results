#!/usr/bin/env python


import rospy
from std_msgs.msg import String


def status_callback(status):
    print status.data

while 1:

    rospy.init_node('Test_Ros_Sub')

    rospy.Subscriber("/eta",String, status_callback)
