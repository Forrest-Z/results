#!/usr/bin/env python

import sys
import datetime
import rospy
import time
from sensor_msgs.msg import NavSatFix
from gcart.srv import *
import requests
import json
from std_msgs.msg import String
# from golf_cart_push import *
from gps_distance import gps_distance_fn
from math import fabs
# from easydict import EasyDict as edict
import math

runAssignFlag = True
trip_start_flag = False
Release_cart_flag = False
otp_wrong_status_flag = False
OTP = "0000"
latitude = 0.0
longitude = 0.0
iteration_flag = 0

update_count=0
# Added for BookingReference
bookingReference = ""

def check_if_cart_assigned(name):
    rospy.wait_for_service('golf_cart_booking_assigned_pull')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_booking_assigned_pull', GolfCartBooking)
            resp1 = execute(name,"","")
            print( "Cart assigned" )
            print( resp1.status )
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1)
            continue

def accept_cart_booking(name):
    rospy.wait_for_service('golf_cart_booking_accept_push')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_booking_accept_push', GolfCartBooking)

            resp1 = execute(name, bookingReference,"")
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue

# Need to change
def cart_has_arrived(name):
    rospy.wait_for_service('golf_cart_booking_arrival_push')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_booking_arrival_push', GolfCartBooking)
            resp1 = execute(name, bookingReference,"")
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue

def cart_has_started(name):
    rospy.wait_for_service('golf_cart_booking_started_push')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_booking_started_push', GolfCartBooking)
            resp1 = execute(name, bookingReference, OTP)
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue

def cart_tour_has_finished(name):
    rospy.wait_for_service('golf_cart_booking_finish_push')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_booking_finish_push', GolfCartBooking)
            resp1 = execute(name, bookingReference,"")
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue

def change_map():
    str1 = """var geo = ["""
    str2 ="{lat: "+str(latitude)+", "+"lng: "+str(longitude)+"}"
    str3 = """];"""
    filestr = str1+str2+str3

    #Path_Variable
    with open("/home/stgat/gcart_ws/web/public/globals.js", 'w') as outfile:
        outfile.write(filestr)

def update_cart_location(name):
    global update_count
    update_count += 1
    if(update_count % 5):
        rospy.wait_for_service('golf_cart_location_updater')
        try:
            update_location = rospy.ServiceProxy('golf_cart_location_updater', GolfCartLocation)
            t = datetime.datetime.now().isoformat()
            #latitude = 12.358130
    	    #longitude = 76.596344
            resp1 = update_location(name, latitude, longitude, 'available')
            change_map()

            return resp1.address
        except rospy.ServiceException, ex:
            print "Service call failed: %s"%ex

def usage():
    return "usage: %s [<GolfCart Name>]"%sys.argv[0]

def gps_callback(data):
    global latitude
    global longitude
    latitude = data.latitude
    longitude = data.longitude
    # print("lat long are :")
    # print( latitude, longitude )

def gui_callback(msg):
    global trip_start_flag, Release_cart_flag, OTP, otp_wrong_status_flag
    msg1 = msg.data.split(":") 
    if msg1[0] == "Start_button_pressed":
        print("OTP received for verification")
        OTP = msg1[-1]
        trip_start_flag = True
        
    elif msg1[0] == "Release_button_pressed":
        print("Button pressed in GUI for Release cart")
        Release_cart_flag = True 


# function to release the cart from booking 
def cart_status(name):
    rospy.wait_for_service('golf_cart_status')
    while True:
        try:
            print "Checking cart's Status"
            execute = rospy.ServiceProxy('golf_cart_status', GolfCartBooking)
            resp1 = execute(name,"", "")
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(5) 
            continue


# function to release the cart from booking 
def release_cart_booking(name):
    rospy.wait_for_service('golf_cart_release_booking')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_release_booking', GolfCartBooking)
            resp1 = execute(name,bookingReference, "")
            return resp1
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue

# function to fetch pick and destination GPS coordinates
def fetch_pick_dest_gps(name):
    rospy.wait_for_service('golf_cart_pick_dest_gps')
    while True:
        try:
            execute = rospy.ServiceProxy('golf_cart_pick_dest_gps', PickDestGPS)
            resp1 = execute(name)
            # return resp1
            return resp1.pick_latitude, resp1.pick_longitude, resp1.dest_latitude, resp1.dest_longitude
        except rospy.ServiceException, ex:
            time.sleep(1) 
            continue    


if __name__ == "__main__":
    
    global Release_cart_flag    
    name = "Mys_cart1"
    # if len(sys.argv) == 2:
    #     name = str(sys.argv[0])
    # else:
    #     print usage()
    #     sys.exit(1)

    rospy.init_node('golf_cart_app_main_client')
    runAssignFlag = True

    #Path_Variable
    # rospy.Subscriber("/mavros/global_position/global", NavSatFix, gps_callback)
    rospy.Subscriber("/fix", NavSatFix, gps_callback)
    gCart_Status = rospy.Publisher("/gcart_status",String, queue_size=1, latch=True )
    # Added for publishing ETA
    ETA = rospy.Publisher("/eta",String, queue_size=1, latch=True )
    cart_Speed = 7.0 / 3.6 # Kmph to mpmins 

    rospy.Subscriber("/gui_to_gcart",String, gui_callback)
    GPS_radius = 7.0           #### adjust this parameter as per the GPS accuracy


    rate =rospy.Rate(2)

    while not rospy.is_shutdown():
        
        pick_latitude   = 0.0
        pick_longitude  = 0.0
        dest_latitude   = 0.0
        dest_longitude  = 0.0

        #svs1 resp =edict({"status":"available"})
        
        # print "svs 0"
        # print "hello"
        resp = cart_status(name)
        # print "hello"
        #svs1 resp.status = "available"
        # print "svs 1"
        print resp.status

        

        while resp.status == "available":
            gCart_Status.publish("IDLE")
            ETA.publish("Calculating")
            resp = cart_status(name)
            #svs1 resp.status = "initiated"
            # time.sleep(0.3)
            # print "entered 1"
            update_cart_location(name)
            # print("Cart Available")
            # print "exited 1"

        # resp = check_if_cart_assigned(name)
        # time.sleep(0.3)
        # update_cart_location(name)
        # # while resp.status != "initiated" and resp.status != "booked":

        # print "svs 2"
        print resp.status

        while resp.status != "initiated":
            # print "Entered 2"
            gCart_Status.publish("IDLE")
            resp = check_if_cart_assigned(name)
            #Added for booking reference
            # print "exited 2"
            # time.sleep(0.3)
            update_cart_location(name)
        print("Assigned confirmed")

        #SSS
        # resp = check_if_cart_assigned(name)
        bookingReference = resp.bookingref

        # print "svs 3"
        print resp.status
        
        while resp.status != "accepted":
            #--- Cart is accepting the booking and updating the booking table status.
            resp = accept_cart_booking(name)
            update_cart_location(name)
            ### get coordinates of pick-up point and destination
        print resp.status
        pick_latitude, pick_longitude, dest_latitude, dest_longitude = fetch_pick_dest_gps(name)
        print("Booking Confirmed")
        print resp.status


        
        # resp = cart_has_arrived(name)       ### comment this to use GPS relate update
        while resp.status != "arrived":
            gCart_Status.publish("TO_PICKUP_POINT") ## gcart is moving to pickup point
            dist = gps_distance_fn(latitude, longitude, pick_latitude, pick_longitude)
            # print("GPS: current", latitude," : ", longitude," Pick: ", pick_latitude,": ", pick_longitude)
            print("Distance to pick point: ", dist)
            secs = math.ceil(dist / cart_Speed)
            mins = int ( secs / 60 )
            secs = int(secs % 60)
            eta = str(mins) + " mins : " + str(secs) +" secs"  
            ETA.publish(eta)

            if (fabs(dist) <= GPS_radius):   # gcart is around 3m near the picking point
            # if (fabs(dist) <= 5.0):
                resp = cart_has_arrived(name)
            # resp = cart_status(name)
            # time.sleep(0.3)
            update_cart_location(name)
        ETA.publish("Calculating")
        print("Cart Arrived for Pickup")

        # resp = cart_has_started(name)  ### comment this to use button feature to start the cart 

        # print "svs 5"
        print resp.status
        
        trip_start_flag   = False               #### GUI button press will make this flag true
        while resp.status != "enroute":
            # resp = cart_status(name)
            # Changed for taking current booking status as per new API
            resp = check_if_cart_assigned(name)
            # print "svs 6"
            if trip_start_flag == True:              ### this trip_start flag becomes True when Start Ride button is pressed in GUI
                resp = cart_has_started(name)
                if resp.status == "Error: Error: OTP doesn't match":
                    otp_wrong_status_flag = True
                else:
                    otp_wrong_status_flag = False
            
            if otp_wrong_status_flag == True:
                trip_start_flag = False
                gCart_Status.publish("WRONG_OTP")
            elif otp_wrong_status_flag == False and trip_start_flag == False:      
                gCart_Status.publish("WAITING")        ### waiting for user to press start button
            # time.sleep(0.3)
            # update_cart_location(name)
        print("Cart has Started",resp.status)
        
        while resp.status == "enroute":
            gCart_Status.publish("TO_DESTINATION")
            dist = gps_distance_fn(latitude, longitude, dest_latitude, dest_longitude)
            # print("GPS: current", latitude," : ", longitude," Dest: ", dest_latitude,": ", dest_longitude)
            print("Distance to destination point: ", dist)

            secs = math.ceil( dist / cart_Speed )
            mins = int( secs / 60 )
            secs = int(secs % 60)
            eta = str(mins) + " mins : " + str(secs) +" secs"  
            ETA.publish(eta)

            if (fabs(dist) <= GPS_radius):
                resp = cart_tour_has_finished(name)
                
            # resp = cart_status(name)
            update_cart_location(name)
            print("Cart is enRoute to destination")
            # time.sleep(0.3)         
        ETA.publish(" Reached ")
        if resp.status == "reached":
            print("Reached")
        else:
            print( "Cart status : ", resp.status )


        #Release_cart_flag = False  # true for auto release required, False for gui release button 
        while Release_cart_flag!=True :
            #print "Release_cart_flag: ", Release_cart_flag
            gCart_Status.publish("REACHED_DESTINATION")
            time.sleep(0.3)
        print "Release_cart_flag: ", Release_cart_flag
        ### Added service call to release the Cart
        resp = release_cart_booking(name)
        #rate.sleep()
        #### remove the break to continue the loop        
        # break
    #print "[%s] = %s, %s"%(name, resp.status, resp.reference)


