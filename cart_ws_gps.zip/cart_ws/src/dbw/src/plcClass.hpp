#ifndef __PLC_MODBUS_HPP__
#define __PLC_MODBUS_HPP__

#include <modbus/modbus.h>

class PLC_MODBUS{
	private:
		modbus_t *ctx;
	public:	
		static const int SLAVE_ID 				= 0x0001; //slave address

		static const int BIT_ON					= 1;
		static const int BIT_OFF				= 0;

		//Input Relays
		static const int ADDR_AUTO_MAN_SWITCH_X1		= 0x0401; //X1
		static const int ADDR_EMGNCY_SWITCH_X2			= 0x0402; //X2

		//Output Relays
		static const int ADDR_STEER_DIR_Y0			= 0x0500; //Y0

		//Bit Relays
		// M203 steering speed
		// M200 direction 1 left 0 right
		// M1 - X1
		// M2 - X2
		// Encoder output 605 (l) to 482 (r)
		// 	after scaling 270 (l) to 200 (r)
		// Speed set point D16 (700 to 2000)
		// Forward - M223
		// Reverse - M224
		// Brake dir - m210 1 apply 0 release
		// brake energize - m211
		// m220 horn
		// m221 right
		// m222 left
				
			
		static const int ADDR_AUTO_SWITCH_M6			= 0x0806; 
		static const int ADDR_AUTO_OK_M0			= 0x0800;

		static const int ADDR_BRAKE_CMD_M210			= 0x08D2;
		static const int ADDR_BRAKE_SPEED_M211			= 0x08D3;

		static const int ADDR_EMG_SWTCH_M7			= 0x0807;
		static const int ADDR_EMG_BRAKE_STAT_M226		= 0x08E2;

		static const int ADDR_HORN_M220				= 0x08DC;
		static const int ADDR_RIGHT_INDICATOR_M221		= 0x08DD;
		static const int ADDR_LEFT_INDICATOR_M222		= 0x08DE;
		static const int CART_HORN				= 1;
		static const int CART_RIGHT_INDICATOR 			= 2;
		static const int CART_LEFT_INDICATOR 			= 3;

		static const int ADDR_CART_FWD_M223			= 0x08DF; 
		static const int ADDR_CART_REV_M224			= 0x08E0; 
		static const int ADDR_SPEED_SETPT_D40			= 0x1028; 
		static const int ADDR_SPEED_AOUT_D16			= 0x1010;
		static const int VEHICLE_FORWARD_DIRECTION 		= 1;
		static const int VEHICLE_REVERSE_DIRECTION 		= 2;
		static const int VEHICLE_NEUTRAL_DIRECTION 		= 3;

		static const int ADDR_STEER_SETPT_D400			= 0x1190; 
		static const int ADDR_CURR_STEER_ANGLE_D30		= 0x101E;
		static const float MIN_STEERING_ANGLE			= -45.0;
		static const float MAX_STEERING_ANGLE			= +45.0;


	

	public:
		PLC_MODBUS();
		//~PLC_MODBUS();
		int setupModbusComm(const char* devName);
		int connectPLC();
		int closeModbusComm();
		int readBit(int addr,uint8_t& value);
		int readRegister(int addr,int16_t& value);
		int writeBit(int addr,uint8_t value);
		int writeRegister(int addr,int16_t value);
		int setSteeringAngle(float inputAngle);
		int readSteeringAngle(float& steeringAngle);
		int readCartSpeed(uint16_t& currentSpeed);
		int setVehicleDirection(int direction);
		int setVehicleSpeed(int speed);
		int readCartMode(uint8_t& value);
		int setVehicleBrakes();
		int resetVehicleBrakes();
		int cartIndicator(int indicatorType);
		int resetEmgBrakes();
		int readM( int, uint8_t& ) ;
		int readD( int, uint16_t& ) ;
};

#endif
