
# for python 3.6 and qtconsole 4.3.1
# from PyQt5.QtWebEngineWidgets import QWebEngineView as QWebView,QWebEnginePage as QWebPage
# from PyQt5.QtWebEngineWidgets import QWebEngineSettings as QWebSettings

from PyQt5.QtWebKitWidgets import *   # for python 2.7 with ROS
# from PyQt5.QtCore import pyqtSlot, QUrl
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QWidget, QAction, QTabWidget,QVBoxLayout, QHBoxLayout, QProgressBar, QDial
from PyQt5.QtWidgets import *
# from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

import rospy
from std_msgs.msg import String
import sys

 
class QWidget_Tab1(QWidget):
    # def __init__(self,parent):
    def __init__(self):
        # super(QWidget, self).__init__(parent)
        super(QWidget, self).__init__()
        self.button_image= QIcon('04_Cart_IDLE.png')
        self.gcart_status ="IDLE"
        # Create first tab
        self.layout = QVBoxLayout(self)
        self.browser = QWebView()
        self.browser.setUrl(QUrl("https://www.google.com/maps/dir/12.3580971,76.5957407/GEC-2+Fountain/@12.3581311,76.5945101,18.25z/") )
        self.layout.addWidget(self.browser)
        
        
        # create horizontal layout object
        self.Hlayout = QHBoxLayout()
        self.Vlayout_inH = QVBoxLayout()
        # create status button to widget
        self.pushButton_status = QPushButton()
        
        self.pushButton_status.setIcon(self.button_image)
        self.pushButton_status.setIconSize(QSize(540,244))
        self.pushButton_status.clicked.connect(self.status_pushButton_callback )

        # Add status button to widget
        # self.layout.addWidget(self.pushButton_status)
        self.Volume1 = QDial()
        self.batteryCart = QProgressBar()
        self.batteryInvertor = QProgressBar()
        self.Vlayout_inH.addWidget(self.Volume1)
        self.Vlayout_inH.addWidget(self.batteryCart)
        self.Vlayout_inH.addWidget(self.batteryInvertor)

        self.Hlayout.addLayout(self.Vlayout_inH)
        # Add status button to Hlayout widget
        self.Hlayout.addWidget(self.pushButton_status)
        
        # self.layout.addLayout(self.Hlayout)
        self.layout.addLayout(self.Hlayout)

        self.setLayout(self.layout)

    def status_pushButton_callback(self):
        # global gcart_status
        try:
            print("in button call back: ", self.gcart_status)
            if self.gcart_status =="WAITING":
                GUI_to_Cart_topic_handle.publish("Start_button_pressed")
                print("Start button pressed") 
            if self.gcart_status =="REACHED_DESTINATION":    
                GUI_to_Cart_topic_handle.publish("Release_button_pressed")
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)

    def button_img_update(self, gcart_status ):
        try:
        # global gcart_status
            self.gcart_status = gcart_status
            print ("in function button_img_update, gcart_status: ", gcart_status)
            if gcart_status =="IDLE":
                self.button_image = QIcon('04_Cart_IDLE.png')
            elif gcart_status =="TO_PICKUP_POINT":
                self.button_image = QIcon('00_To_Pick-up.png')
            elif gcart_status =="WAITING":
                self.button_image = QIcon('01_Ride-START-button.png')
                print("Press Start button") 
            elif gcart_status =="TO_DESTINATION":
                self.button_image = QIcon('02_ONROUTE.png')
            elif gcart_status =="REACHED_DESTINATION":
                self.button_image = QIcon('03_DESTINATION_REACHED_button.png')

            self.pushButton_status.setIcon(self.button_image)
            self.pushButton_status.setIconSize(QSize(540,244))
            # self.pushButton_status.paintEvent()
            self.pushButton_status.update()  
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)  
