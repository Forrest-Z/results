#!/usr/bin/env python
import time
import rospy
from std_msgs.msg import String
i = 0

rospy.init_node('Test_Ros_Pub')
ETA = rospy.Publisher("/eta",String, queue_size=1, latch=True )

for i in range(100):
    ETA.publish(str(i))
    time.sleep(0.25)