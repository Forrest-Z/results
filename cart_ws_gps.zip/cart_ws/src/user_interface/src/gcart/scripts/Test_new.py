from PyQt5 import QtWidgets
from ui import Ui_MainWindow
from package import update

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # label from .ui -> .py
        # self.ui.label_1.setText("need to change this")

    def setupUi(self):
        self.ui.verticalLayout = QtWidgets.QVBoxLayout(self.ui)
        # self.ui.browser = QWebView()
        # URL_map= "https://www.google.com"
        # self.ui.browser.load(QUrl(URL_map))
        # self.ui.browser.setMinimumWidth(900)
        # self.ui.verticalLayout.addWidget(self.ui.browser)
        self.ui.lblTime = QtWidgets.QLabel()
        self.ui.lblTime.setObjectName("lblTime")
        self.ui.lblTime.setText("Initially")
        self.ui.verticalLayout.addWidget(self.ui.lblTime)

#../package/update.py
def label_update(obj): #obj is the object self
    obj.ui.lblTime.setText("no problem")