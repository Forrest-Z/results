#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__authors__ = "Thomas Paul, Vimal, Sharath"
__version__ = "1.0"

# # GPU warning silencer- Just disables the warning, doesn't enable AVX/FMA
import os
import sys
from nav_msgs.msg import OccupancyGrid

import rospy
import ros_numpy
from std_msgs.msg import String
from sensor_msgs.msg import PointCloud2, Image
from geometry_msgs.msg import TransformStamped, Pose, Quaternion, Point
#from tf2_sensor_msgs.tf2_sensor_msgs import do_transform_cloud
from tf.transformations import quaternion_from_euler
import matplotlib.pyplot as plt
import numpy as np
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats

#################################################
## Grid generation code
#################################################
def get_grid(x,y,z,r,rings):
	# TODO: modify the parameters
	# Lidar is at (0,0,0)
	side_range=(-15, 15) # 10 meters to the right and 10 meters to the left
	fwd_range=(0,30) # 2 meters from front to 27 meters. -5 means 5 meters behind
	min_height = -1.0# -1m below the lidar
	max_height = 3

	res= 0.2# grid size of 0.1m X 0.1m
	point_threshold = 2
	#
	# print(z)
	# calculate the image/grid dimensions
	grid_width = int((side_range[1] - side_range[0])/res)
	grid_height = int((fwd_range[1] - fwd_range[0])/res)
	number_of_grids = grid_height * grid_width

	# FILTER POINTS.
	# INDICES FILTER - of values within the desired rectangle
	# Note left side is positive y axis in LIDAR coordinates
	ff = np.logical_and((x > fwd_range[0]), (x < fwd_range[1]))
	ss = np.logical_and((y > -side_range[1]), (y < -side_range[0]))
	zz = np.logical_and((z > min_height), (z < max_height))
	mask = np.logical_and(ff, ss)
	mask = np.logical_and(mask, zz)
	
	indices_mask = np.argwhere(mask).flatten() # boolean mask for selecting points

	# select the points that we are interested in
	x_lidar = x[indices_mask]
	y_lidar = y[indices_mask]
	# z_lidar = z[indices_mask]
	# r_lidar = r[indices_mask]
	# rg_lidar = rings[indices_mask]
		
	# MAPPING
	# Mappings from one point to grid 
	# CONVERT TO PIXEL POSITION VALUES - Based on resolution(grid size)
	x_img_mapping = (-y_lidar/res).astype(np.int32) # x axis is -y in LIDAR
	y_img_mapping = (x_lidar/res).astype(np.int32)  # y axis is -x in LIDAR; will be inverted later


	#I changed
	#x_img_mapping = (x_lidar/res).astype(np.int32) # x axis is -y in LIDAR
	#y_img_mapping = (y_lidar/res).astype(np.int32)  # y axis is -x in LIDAR; will be inverted later
	##################

	# SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
	# floor used to prevent issues with -ve vals rounding upwards
	x_img_mapping -= int(np.floor(side_range[0]/res))
	y_img_mapping -= int(np.floor(fwd_range[0]/res))

	#I changed
	#x_img_mapping -= int(np.floor(fwd_range[0]/res))
	#y_img_mapping -= int(np.floor(side_range[0]/res))
	#####################

	# Linerize the mappings to 1D
	lidx = ((-y_img_mapping) % grid_height) * grid_width + x_img_mapping


	#I changed
	#lidx = ((y_img_mapping) % grid_height) * grid_width + x_img_mapping
	######################

	# count of points per grid
	count_input = np.ones_like(y_lidar)
	binned_count = np.bincount(lidx, count_input, minlength = number_of_grids)
	grid_count = binned_count.reshape(grid_height, grid_width)

	grid = np.zeros_like(grid_count)
	grid[grid_count > point_threshold] = 100
	return grid,res,grid_width, grid_height

#################################################
## ROS THINGS
#################################################

def generate_grid_callback(data):
	# TODO: assign point cloud here

	pc = data
	## convert transformed pointcloud2 to numpy
	#print(pc)
	arr = ros_numpy.point_cloud2.pointcloud2_to_array(pc)
	_x = arr['x']
	_y = arr['y']
	_z = arr['z']
	#_r = arr['intensity']
	#_rn= arr['ring']
	
	## predict road
	grid, res,grid_width, grid_height = get_grid(_x, _y, _z, 0, 0)
	
	grid_msg = OccupancyGrid()
	grid_msg.header.stamp = rospy.Time.now()
	grid_msg.header.frame_id = "local_map"
	
	grid_msg.info.resolution = res
	grid_msg.info.width = grid_width
	grid_msg.info.height = grid_height

	
	grid_msg.info.origin = Pose(Point(0.,0., 0.),
							Quaternion(0., 0., 0., 1.))

	grid = np.rot90(np.flipud(grid),1)
	flat_grid = grid.ravel()
	grid_msg.data = list(np.round(flat_grid, decimals = 3))

	pub = rospy.Publisher('/local_map', OccupancyGrid, queue_size=1)
	pub.publish(grid_msg)



	# x=[]
	# y=[]
	# for i in range(len(grid)):
	# 	 for k in range(len(grid[0])):
	# 		 if(grid[i][k]!=0):
	# 			 x.append(i)
	# 			 y.append(k)
	# plt.scatter(x,y)
	# plt.show()
    

			
	## TODO: publish grid

	
def init():
	rospy.init_node('lidar_grid', anonymous=True)
	rospy.Subscriber("/pointcloud_transformed", PointCloud2, generate_grid_callback)
	
	rospy.spin()

if __name__ == '__main__':
	init()
