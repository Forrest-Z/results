#include "plcClass.hpp"
#include <iostream>
#include <errno.h>
#include <string>
#include <unistd.h>

using namespace std;

PLC_MODBUS::PLC_MODBUS(){
	ctx = NULL;
}

int PLC_MODBUS::setupModbusComm(const char* deviceName){
	cout << "device name is " << deviceName << endl;
	ctx = modbus_new_rtu(deviceName, 9600, 'E', 8, 1);
	if (ctx == NULL) {
		cout << "Unable to allocate libmodbus context" << endl;
		return -1;
	}

	modbus_set_slave(ctx, SLAVE_ID);
}

int PLC_MODBUS::connectPLC(){
	if (modbus_connect(ctx) == -1) {
		cout << "Connection failed: " << modbus_strerror(errno) << endl;
		modbus_free(ctx);
		return -1;
	}
	//modbus_set_debug(ctx, true);
}

int PLC_MODBUS::closeModbusComm(){
	modbus_close(ctx);
	//modbus_free(ctx);
}

int PLC_MODBUS::readBit(int addr,uint8_t& value){

	if (modbus_read_bits(ctx,addr,1,&value) == -1) 
	{
		cout << "error reading bit at addr = " << addr << endl; 
		return -1;
	}
	return 0;
}

int PLC_MODBUS::writeBit(int addr,uint8_t value){
	if (modbus_write_bit(ctx,addr,value) == -1) 
	{
		cout << "error writing bit at addr = " << addr << endl; 
		return -1;
	}
	//cout << "setting M at addr =" << addr << endl;
	return 0;
}

int PLC_MODBUS::readRegister(int addr,int16_t& value){
	uint16_t temp=0;
	if (modbus_read_registers(ctx,addr,1,&temp) == -1) 
	{
		cout << "error reading register at addr = " << addr << endl; 
		return -1;
	}
	else{
		value = (int16_t)temp;
	}
	return 0;
}

int PLC_MODBUS::writeRegister(int addr,int16_t value){
	//cout << "writing value = " << value << ", addr= " << addr << endl;
	if (modbus_write_register(ctx,addr,value) == -1) 
	{
		cout << "error write register at addr = " << addr << endl; 
		return -1;
	}
	return 0;
}


