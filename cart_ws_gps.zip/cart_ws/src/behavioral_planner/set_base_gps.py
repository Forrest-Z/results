#!/usr/bin/env python
from sensor_msgs.msg import NavSatFix
import rospy
import numpy as np



if __name__== "__main__":

    rospy.init_node( 'base_gps', anonymous=True) 
        
    base_location = NavSatFix()
    base_location.latitude = 12.35807102
    base_location.longitude = 76.59601651
    base_location.altitude =  771.56
    # 12.35807102, 76.59601651, 771.56
    pub = rospy.Publisher('/base_gps', NavSatFix, queue_size=10)
    while not rospy.is_shutdown():
        pub.publish(base_location)
    rospy.spin()
  