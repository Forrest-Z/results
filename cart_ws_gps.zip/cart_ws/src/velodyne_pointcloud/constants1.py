import numpy as np
from scipy.spatial import KDTree




### INPUT VEHICLE CO-ORDINATES
class vehicle_points():
  def __init__(self,input_co_ordinates,center):
    self.input_co_ordinates=input_co_ordinates
    self.center=center

def get_way_point_tree_list(waypoint_list):
  waypoint_tree_list=[]
  for lane_waypoints in waypoint_list:
    re_created_wp=[[w[0],w[1]] for w in lane_waypoints]
    waypoints_tree=KDTree(re_created_wp)
    waypoint_tree_list.append(waypoints_tree)
  return waypoint_tree_list

def cut_gps(x, n=0):
    waypoints = []
    for i in range(0,len(x), n):
        # waypoints.append([x[i][0],x[i][1], x[i][2]])
        waypoints.append([x[i][0],x[i][1],x[i][2],x[i][3],x[i][4],x[i][5],x[i][6]])
    #print("Wow:",len(waypoints))
    return waypoints

# def read_waypoints():
  # lane_1 = np.load('./home/stgat/graph/Fina/lane_1.npy') 
  # lane_2 = np.load('./home/stgat/graph/Final/lane_2.npy')
  # waypoints_lane_1 = cut_gps(lane_1,1 )
  # waypoints_lane_2 = cut_gps(lane_2,1 )
  # waypoints_list = [waypoints_lane_1,waypoints_lane_2]
  # waypoint_tree_list=get_way_point_tree_list(waypoints_list)

  # return waypoints_list,waypoint_tree_list

def read_waypoints():
  
  lane_1 = np.load('/home/stgat/graph/Final/lane_data/parking_2.npy') 
  #print('',lane_1)
  waypoints_lane_1 = cut_gps(lane_1,1 )
  waypoints_list = [waypoints_lane_1]
  waypoint_tree_list=get_way_point_tree_list(waypoints_list)

  return waypoints_list,waypoint_tree_list


  
#waypoint_list=[[[65,1,np.pi/2],[65,2,np.pi/2],[65,3,np.pi/2]],[[4,1,np.pi/2],[4,2,np.pi/2],[4,3,np.pi/2]]]  
#waypoint_tree_list=get_way_point_tree_list(waypoint_list)
vehicle_pt_obj_actual = vehicle_points( np.array([[0.5,0.5],[0.5,1.5],[0.5,2.5],[0.5,3.5],[1.5,0.5],[1.5,1.5],[1.5,2.5],[1.5,3.5]]),[0,2] )
lane_direction = {"PLCL": -1, "LCL": -1, "LCR": 1, "PLCR": 1,"KL":0,"STOP":None}
offset_value=1000
present_lane=0
goal_lane=0
present_state="KL"

##############################################################################
waypoints_list,waypoint_tree_list=read_waypoints()
angle = np.deg2rad(270)