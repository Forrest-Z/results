#include "plcClass.hpp"
#include <iostream>
#include <errno.h>
#include <string>
#include <unistd.h>

using namespace std;


int PLC_MODBUS::setSteeringAngle(float inputAngle){

	int success = -1;
	
	if(inputAngle < MIN_STEERING_ANGLE)
		inputAngle = MIN_STEERING_ANGLE;
	else if(inputAngle > MAX_STEERING_ANGLE)
		inputAngle = MAX_STEERING_ANGLE;


	if(!writeRegister(ADDR_STEER_SETPT_D400,inputAngle)){
		success = 1;
	}
	else{
		success = -1;
	}

	if (success < 0)
		cout << "Error setting steering angle " << success << endl;

	return success;
}

int PLC_MODBUS::readSteeringAngle(float& currentAngle){
	int success = -1;
	int16_t value=0;

	//Read steering angle, the value is in between -45, +45
	if(!readRegister(ADDR_CURR_STEER_ANGLE_D30,value)){
		currentAngle = value;
		success = 0;
	}

	if (success == -1)
		cout << "Error reading steering angle" << endl;
	
	return success;
}

int PLC_MODBUS::readCartSpeed(uint16_t& currentSpeed){
	int success = -1;
	int16_t value=0;

	//Read speed setpoint
	if(!readRegister(ADDR_SPEED_AOUT_D16,value)){
		currentSpeed = value;
		success = 0;
	}

	if (success == -1)
		cout << "Error reading steering angle" << endl;
	
	return success;
}

int PLC_MODBUS::setVehicleDirection(int direction){
	int success = 0;
	if(direction == VEHICLE_FORWARD_DIRECTION){
		if(writeBit(ADDR_CART_FWD_M223,BIT_ON) == -1){
			cout << "Error setting Forward direction" << endl;
			success = -1;
		}
	}
	else if(direction == VEHICLE_REVERSE_DIRECTION){
		if(writeBit(ADDR_CART_REV_M224,BIT_ON) == -1){
			cout << "Error setting Reverse direction" << endl;
			success = -1;
		}	
	}
	else if(direction == VEHICLE_NEUTRAL_DIRECTION){
		if(writeBit(ADDR_CART_FWD_M223,BIT_OFF) == -1){
			cout << "Error setting Neutral direction-1" << endl;
			success = -1;
		}
		if(writeBit(ADDR_CART_REV_M224,BIT_OFF) == -1){
			cout << "Error setting Neutral direction-2" << endl;
			success = -1;
		}	
	}
	return success;				
}

int PLC_MODBUS::setVehicleSpeed(int speed){
	int success = -1;
	int16_t vehSpeed = speed;

	if(!writeRegister(ADDR_SPEED_SETPT_D40,vehSpeed)){
		success = 0;
	}
	else{
		cout << "Error setting speed" << endl;
		success = -1;
	}

	return success;
}

int PLC_MODBUS::readCartMode(uint8_t& cartMode){
	int success = -1;
	uint8_t value=0;

	//Read speed setpoint
	if(!readBit( ADDR_AUTO_SWITCH_M6, value)){
		cartMode = value;
		success = 0;
	}

	if (success == -1)
		cout << "Error reading cart mode" << endl;
	
	return success;
}

int PLC_MODBUS::setVehicleBrakes(){
	int success = -1;

	if(!writeBit(ADDR_BRAKE_CMD_M210,BIT_ON)){
		if(!writeBit(ADDR_BRAKE_SPEED_M211,BIT_ON)){
			success = 0;
		}
	}
	else{
		cout << "Error setting brakes" << endl;
		success = -1;
	}

	return success;
}

int PLC_MODBUS::resetVehicleBrakes(){
	int success = -1;

	if(!writeBit(ADDR_BRAKE_CMD_M210,BIT_OFF)){
		if(!writeBit(ADDR_BRAKE_SPEED_M211,BIT_ON)){
			success = 0;
		}
	}
	else{
		cout << "Error resetting brakes" << endl;
		success = -1;
	}

	return success;
}


int PLC_MODBUS::resetEmgBrakes(){
	int success = -1;

	if(!writeBit(ADDR_EMG_BRAKE_STAT_M226,BIT_OFF)){
		success = 0;
	}
	else{
		cout << "Error resetting emg brakes" << endl;
		success = -1;
	}

	return success;
}

int PLC_MODBUS::cartIndicator(int indicatorType){
	int success = -1;

	if(indicatorType == CART_HORN){
		if(!writeBit(ADDR_HORN_M220,BIT_ON)){
			success = 0;
		}
	}
	else if(indicatorType == CART_RIGHT_INDICATOR){
		if(!writeBit(ADDR_RIGHT_INDICATOR_M221,BIT_ON)){
			success = 0;
		}
	}
	else if(indicatorType == CART_LEFT_INDICATOR){
		if(!writeBit(ADDR_LEFT_INDICATOR_M222,BIT_ON)){
			success = 0;
		}
	}

	if(success < 0){
		cout << "Error setting indicator" << endl;
	}

	return success;
}

int PLC_MODBUS::readM( int address, uint8_t& Mval){
	int success = -1;
	uint8_t value=0;

	//Read speed setpoint
	if(!readBit( address, value)){
		Mval = value;
		success = 0;
	}

	if (success == -1)
		cout << "Error reading M value" << endl;
	
	return success;
}

int PLC_MODBUS::readD( int address, uint16_t& Dval ){
	int success = -1;
	int16_t value=0;

	//Read speed setpoint
	if(!readRegister(address,value)){
		Dval = value;
		success = 0;
	}

	if (success == -1)
		cout << "Error reading D value" << endl;
	
	return success;
}
