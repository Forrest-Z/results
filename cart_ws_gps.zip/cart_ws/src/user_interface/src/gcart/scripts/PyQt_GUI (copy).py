#!/usr/bin/env python

# for python 3.6 and qtconsole 4.3.1
# from PyQt5.QtWebEngineWidgets import QWebEngineView as QWebView,QWebEnginePage as QWebPage
# from PyQt5.QtWebEngineWidgets import QWebEngineSettings as QWebSettings

from PyQt5.QtWebKitWidgets import *   # for python 2.7 with ROS
# from PyQt5.QtCore import pyqtSlot, QUrl
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QWidget, QAction, QTabWidget,QVBoxLayout, QHBoxLayout, QProgressBar, QDial, QSlider
# from PyQt5.QtWidgets import *

# # from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

from PyQt5 import QtCore, QtGui, QtWidgets


import rospy
from std_msgs.msg import String
import sys, os

import subprocess
import time
import rviz
import datetime
from weather import Weather, Unit

global I
I = 1
 
class App(QMainWindow):
 
    def __init__(self):
        super(App, self).__init__()
        # super().__init__()
        self.title = 'Golf Cart'
        self.left = 0
        self.top = 0
        self.width = 300
        self.height = 200
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
    
        
        self.table_widget = MyTableWidget(self)
        self.setCentralWidget(self.table_widget)

        self.setGeometry(70, 50, 1100, 700)
        self.show()
 
class MyTableWidget(QWidget):        
 
    def __init__(self, parent):   
        try:
            super(QWidget, self).__init__(parent)
            self.layout = QVBoxLayout(self)

            # Initialize tab screen
            self.tabs = QTabWidget()
            self.tab1 = QWidget_Tab1()	
            self.tab2 = QWidget_Tab2()
            # self.tabs.resize(300,200) 
            self.tab3 = QWidget_Tab3()
            self.tab4 = QWidget_Tab4()
            # self.tab4 = QWidget()
            self.tabs.resize(500,1100) 
            
            # Add tabs
            self.tabs.addTab(self.tab1,"            Tracking            ")
            #svs2 self.tabs.addTab(self.tab2,"            Admin          ")
            self.tabs.addTab(self.tab3,"            Admin            ")
            self.tabs.addTab(self.tab4,"            Sensor Visual          ")

         
            # Add tabs to widget        
            self.layout.addWidget(self.tabs)

            self.setLayout(self.layout)
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)
 
 

def status_callback(status, ex):
    global gcart_status
    # print("in topic call back: ", status.)
    print("in topic call back: ", status.data)                
    if status.data =="IDLE":
        gcart_status="IDLE"
    elif status.data =="TO_PICKUP_POINT":
        gcart_status="TO_PICKUP_POINT"
    elif status.data =="WAITING":
        gcart_status="WAITING"
    elif status.data =="TO_DESTINATION":
        gcart_status="TO_DESTINATION"
    elif status.data =="REACHED_DESTINATION":
        gcart_status = "REACHED_DESTINATION" 
    elif status.data == "WRONG_OTP":
        gcart_status = "WRONG_OTP"
    elif status.data == "URL":
        gcart_status = "URL"

    
    ex.table_widget.tab1.button_img_update(gcart_status) 


########################################################################################################################
###########TAB1 code#############################################################################################################
 
class QWidget_Tab1(QWidget):
    # def __init__(self,parent):
    def __init__(self):
        try:
            # super(QWidget, self).__init__(parent)
            super(QWidget, self).__init__()
            self.cwd="/home/infyav/Desktop/GCart_WS/GCart_App/src/gcart/scripts/"
            # self.button_image= QIcon(self.cwd+'04_Cart_IDLE.png')
            self.button_image= QIcon(self.cwd+'04.png')
            self.gcart_status ="IDLE"
            # Create first tab
            self.layout = QHBoxLayout(self)
            self.Vlayout_1 = QVBoxLayout()
            self.Vlayout = QVBoxLayout()
            
            
            # Adding MapWeb View to Tab 1
            self.browser = QWebView()
            #URL_map= "https://www.infosys.com/"
            #URL_map= "https://www.google.com/maps/dir/?api=1&origin=12.3580971,76.5957407&destination=12.3614909,76.5927556&travelmode=car&waypoints=12.359471,76.594878|12.359377,76.593537&key=AIzaSyBIPnVbRmfooSKZleUxQjXc4QqcHSvo1D4"
            # URL_map = "http://172.20.9.70:8000/"
            URL_map = "https://www.google.com/"
            self.browser.setUrl(QUrl(URL_map) )
            self.browser.setMinimumWidth(900)
            self.Vlayout_1.addWidget(self.browser)


            #Adding Logo 
            # self.pic = QtWidgets.QLabel()
            # self.pic.setPixmap(QPixmap(self.cwd + "/Logo.jpg"))

            #creating time widget
            self.lblDate = QtWidgets.QLabel()
            self.lblDateSpace = QtWidgets.QLabel()
            self.lblTemp = QtWidgets.QLabel()
            self.lblTempSpace = QtWidgets.QLabel()
            weather = Weather(unit=Unit.CELSIUS)
            lookup = weather.lookup_by_location('Mysore')
            condition = lookup.condition
            today = datetime.datetime.now()
            self.display_date = today.strftime("%A, %d %b %Y, Mysore")
            deg = u"\u2103"
            self.display_weather = "Weather: " + condition.temp+deg+"  " + condition.text
  
            # Create Stacked Widget
            self.createStackWidget()
            

            #Creating GIF for GCart
            self.gif = QtWidgets.QLabel()
            movie = QtGui.QMovie(self.cwd+"gcart.gif")
            self.gif.setMovie(movie)
            movie.start()
            self.gif.setMaximumWidth(300)

            # create status button to widget
            self.pushButton_status = QPushButton()
            self.pushButton_status.setIcon(self.button_image)
            self.pushButton_status.setIconSize(QSize(290,130))
            self.pushButton_status.clicked.connect(self.status_pushButton_callback )
            self.pushButton_status.setMaximumWidth(300)



            # Adding Time and Weather, Gif, stacked Widget, Pushbutton status.
            # self.Vlayout.addWidget(self.pic)
            self.Vlayout.addWidget(self.lblDate)
            self.Vlayout.addWidget(self.lblDateSpace)
            self.Vlayout.addWidget(self.lblTemp)
            self.Vlayout.addWidget(self.lblTempSpace)
            self.Vlayout.addWidget(self.gif)
            self.Vlayout.addWidget(self.stackedWidget)
            self.Vlayout.addWidget(self.pushButton_status)

            # Adding Sub layouts to the main layout
            self.layout.addLayout(self.Vlayout_1)
            self.layout.addLayout(self.Vlayout)

            # self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
            
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)

    def createStackWidget(self):
        self.stackedWidget = QtWidgets.QStackedWidget()
        self.stackedWidget.setGeometry(QtCore.QRect(100, 30, 321, 167))
        self.stackedWidget.setObjectName("stackedWidget")
        self.page_5 = QtWidgets.QWidget()
        self.page_5.setObjectName("page_5")
        self.widget = QtWidgets.QWidget(self.page_5)
        self.widget.setGeometry(QtCore.QRect(0, 80, 301, 50))
        self.widget.setObjectName("widget")
        self.gridLayout = QtWidgets.QGridLayout(self.widget)
        self.gridLayout.setContentsMargins(0,0,0,0)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName("gridLayout")
        self.lblETA = QtWidgets.QLabel(self.widget)
        self.lblETA.setObjectName("lblETA")
        self.gridLayout.addWidget(self.lblETA, 0, 0,1,1)
        # self.gridLayout.addWidget(self.lblETA)
        self.lblTime = QtWidgets.QLabel(self.widget)
        self.lblTime.setObjectName("lblTime")
        self.gridLayout.addWidget(self.lblTime, 0, 1)
        # self.gridLayout.addWidget(self.lblTime)
        self.lblSpace = QtWidgets.QLabel(self.widget)
        # self.gridLayout.addWidget(self.lblSpace,1,0)
        self.lblSpace2 = QtWidgets.QLabel(self.widget)
        # self.gridLayout.addWidget(self.lblSpace2,1,1)
        
        self.btnES = QtWidgets.QPushButton(self.widget)
        self.btnES.setObjectName("btnES")
        self.btnES.setStyleSheet("background-color: red;" "font: bold;" "color: white")
        # self.btnES.move(10,10)
        
        
        # Added for image Button
        # image= QIcon(self.cwd+'06.png')
        # self.btnES.setIcon(image)
        # self.btnES.setIconSize(QSize(336,51))

        self.gridLayout.addWidget(self.btnES,2,0)
        # self.gridLayout.addWidget(self.btnES, 1, 0, 1, 1)
        self.stackedWidget.addWidget(self.page_5)
        self.page_6 = QtWidgets.QWidget()
        self.page_6.setObjectName("page_6")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.page_6)
        self.gridLayout_2.setContentsMargins(0,0,0,0)
        self.gridLayout_2.setSpacing(0)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.lblOTP = QtWidgets.QLabel(self.page_6)
        self.lblOTP.setObjectName("lblOTP")
        self.gridLayout_2.addWidget(self.lblOTP, 0, 0, 1, 1)
        self.btn5 = QtWidgets.QPushButton(self.page_6)
        self.btn5.setObjectName("btn5")
        self.gridLayout_2.addWidget(self.btn5, 3, 1, 1, 1)
        self.btn6 = QtWidgets.QPushButton(self.page_6)
        self.btn6.setObjectName("btn6")
        self.gridLayout_2.addWidget(self.btn6, 3, 2, 1, 1)
        self.btn7 = QtWidgets.QPushButton(self.page_6)
        self.btn7.setObjectName("btn7")
        self.gridLayout_2.addWidget(self.btn7, 4, 0, 1, 1)
        self.btn8 = QtWidgets.QPushButton(self.page_6)
        self.btn8.setObjectName("btn8")
        self.gridLayout_2.addWidget(self.btn8, 4, 1, 1, 1)
        self.btn9 = QtWidgets.QPushButton(self.page_6)
        self.btn9.setObjectName("btn9")
        self.gridLayout_2.addWidget(self.btn9, 4, 2, 1, 1)
        self.btn0 = QtWidgets.QPushButton(self.page_6)
        self.btn0.setObjectName("btn0")
        self.gridLayout_2.addWidget(self.btn0, 5, 0, 1, 1)
        self.btn1 = QtWidgets.QPushButton(self.page_6)
        self.btn1.setObjectName("btn1")
        self.gridLayout_2.addWidget(self.btn1, 2, 0, 1, 1)
        self.btn2 = QtWidgets.QPushButton(self.page_6)
        self.btn2.setObjectName("btn2")
        self.gridLayout_2.addWidget(self.btn2, 2, 1, 1, 1)
        self.btn3 = QtWidgets.QPushButton(self.page_6)
        self.btn3.setObjectName("btn3")
        self.gridLayout_2.addWidget(self.btn3, 2, 2, 1, 1)
        self.btn4 = QtWidgets.QPushButton(self.page_6)
        self.btn4.setObjectName("btn4")
        self.gridLayout_2.addWidget(self.btn4, 3, 0, 1, 1)
        self.btnbck = QtWidgets.QPushButton(self.page_6)
        self.btnbck.setObjectName("btnbck")
        self.gridLayout_2.addWidget(self.btnbck, 5, 1, 1, 2)
        self.lineEditOTPDisplay = QtWidgets.QLineEdit(self.page_6)
        self.lineEditOTPDisplay.setObjectName("lineEditOTPDisplay")
        self.lineEditOTPDisplay.setMaxLength(4)
        self.gridLayout_2.addWidget(self.lineEditOTPDisplay, 0, 1, 1, 2)
        self.stackedWidget.addWidget(self.page_6)
        self.stackedWidget.raise_()

        # Creating Button Click Events...
        self.btn0.clicked.connect (self.button_clicked0)
        self.btn1.clicked.connect (self.button_clicked1)
        self.btn2.clicked.connect (self.button_clicked2)
        self.btn3.clicked.connect (self.button_clicked3)
        self.btn4.clicked.connect (self.button_clicked4)
        self.btn5.clicked.connect (self.button_clicked5)
        self.btn6.clicked.connect (self.button_clicked6)
        self.btn7.clicked.connect (self.button_clicked7)
        self.btn8.clicked.connect (self.button_clicked8)
        self.btn9.clicked.connect (self.button_clicked9)
        self.btnbck.clicked.connect (self.button_clickedbck)
        
        self.retranslateUi(self)
        self.stackedWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(self)
        
    def retranslateUi(self, QWidget):
        _translate = QtCore.QCoreApplication.translate
        QWidget.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.lblDate.setText(_translate("MainWindow", self.display_date))
        self.lblTemp.setText(_translate("MainWindow", self.display_weather))
        self.lblETA.setText(_translate("MainWindow", "Estimated Time of Arrival: "))
        self.lblTime.setText(_translate("MainWindow", "XX mins"))
        self.btnES.setText(_translate("MainWindow", "Emergency Stop"))
        self.lblOTP.setText(_translate("MainWindow", "Enter OTP"))
        self.btn5.setText(_translate("MainWindow", "5"))
        self.btn6.setText(_translate("MainWindow", "6"))
        self.btn7.setText(_translate("MainWindow", "7"))
        self.btn8.setText(_translate("MainWindow", "8"))
        self.btn9.setText(_translate("MainWindow", "9"))
        self.btn0.setText(_translate("MainWindow", "0"))
        self.btn1.setText(_translate("MainWindow", "1"))
        self.btn2.setText(_translate("MainWindow", "2"))
        self.btn3.setText(_translate("MainWindow", "3"))
        self.btn4.setText(_translate("MainWindow", "4"))
        self.btnbck.setText(_translate("MainWindow", "Backspace"))

    
    def check_otp_size(self):
        length=0
        if(self.lineEditOTPDisplay.text()==''):
            length=0
        else:
            length = len(str(self.lineEditOTPDisplay.text()))
            #print(length)
        if(length>=4):
            QtWidgets.QMessageBox.critical(QtWidgets.QWidget(), "Warning", "OTP has only 4 digits.")
            return False
        return True

    def button_clicked0(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'0')
        
    def button_clicked1(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'1')

    def button_clicked2(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'2')

    def button_clicked3(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'3')

    def button_clicked4(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'4')

    def button_clicked5(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'5')

    def button_clicked6(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'6')

    def button_clicked7(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'7')

    def button_clicked8(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'8')

    def button_clicked9(self):
        if(self.check_otp_size()):
            self.lineEditOTPDisplay.setText(self.lineEditOTPDisplay.text()+'9')

    def button_clickedbck(self):
        curr_value = self.lineEditOTPDisplay.text()
        if(curr_value == ''):
            QtWidgets.QMessageBox.critical(QtWidgets.QWidget(), "Warning", "No digits to erase.")
        else:
            self.lineEditOTPDisplay.setText(curr_value[:-1])


    def status_pushButton_callback(self):
        # global gcart_status
        try:
            print("in button call back: ", self.gcart_status)
            if self.gcart_status =="WAITING":
                otp = self.lineEditOTPDisplay.text()
                GUI_to_Cart_topic_handle.publish("Start_button_pressed:"+str(otp))
                print("Start button pressed") 
            if self.gcart_status =="REACHED_DESTINATION":    
                GUI_to_Cart_topic_handle.publish("Release_button_pressed")
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)

    def button_img_update(self, gcart_status ):
        try:
            
        # global gcart_status
            self.gcart_status = gcart_status
            self.OTP_text = "Enter OTP"
            print ("in function button_img_update, gcart_status: ", gcart_status)
            if gcart_status =="IDLE":
                self.stackedWidget.setCurrentIndex(0)
                # self.button_image = QIcon(self.cwd+'04_Cart_IDLE.png')
                self.button_image = QIcon(self.cwd+'04.png')
            elif gcart_status =="TO_PICKUP_POINT":
                self.stackedWidget.setCurrentIndex(0)
                # self.button_image = QIcon(self.cwd+'00_To_Pick-up.png')
                self.button_image = QIcon(self.cwd+'00.png')
            elif gcart_status =="WAITING":
                # self.lblOTP.setText("Enter OTP")
                self.stackedWidget.setCurrentIndex(1)
                #self.button_image = QIcon(self.cwd+'01_Ride-START-button.png')
                self.button_image = QIcon(self.cwd+'01.png')
                # print("Press Start button") 
            elif gcart_status =="TO_DESTINATION":
                self.stackedWidget.setCurrentIndex(0)
                # self.button_image = QIcon(self.cwd+'02_ONROUTE.png')
                self.button_image = QIcon(self.cwd+'02.png')
            elif gcart_status =="REACHED_DESTINATION":
                self.stackedWidget.setCurrentIndex(0)
                # self.button_image = QIcon(self.cwd+'03_DESTINATION_REACHED_button.png')
                self.button_image = QIcon(self.cwd+'03.png')
            elif gcart_status == "WRONG_OTP":
                # QtWidgets.QMessageBox.critical(QtWidgets.QWidget(), "Invalid OTP", "Entered OTP is incorrect. Re-enter Correct OTP")
                # self.OTP_text="Invalid OTP ! <br/> Re-Enter OTP"
                # self.lblOTP.setText("Invalid OTP ! <br/> Re-Enter OTP")
                self.stackedWidget.setCurrentIndex(1)
                self.button_image = QIcon(self.cwd+'05.png')
            elif gcart_status == "URL":
                # print('inside')
                self.browser = QWebView()
                URL_map1 = "https://www.fb.com/"
                self.browser.setUrl(QUrl(URL_map1))
                QWidget.update(self.browser)
                
                # self.Vlayout_1.addWidget(self.browser)
                global I
                I+=1
                self.stackedWidget.setCurrentIndex(0)
                self.lblTime.setText(str(I))

            self.pushButton_status.setIcon(self.button_image)
            self.pushButton_status.setIconSize(QSize(290,130))
            self.pushButton_status.setMaximumWidth(300)
            # self.pushButton_status.paintEvent()
            self.pushButton_status.update()  
  
        except Exception as err:
            print("Error message in status_pushButton_callback: ", err)  



########################################################################################################################
############TAB2 code############################################################################################################

class QWidget_Tab2(QWidget):
    def __init__(self):
        try:    
            super(QWidget, self).__init__()
            self.layout = QVBoxLayout(self)
            # self.setStyleSheet("background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(9, 41, 4, 255), stop:0.085 rgba(2, 79, 0, 255), stop:0.19 rgba(50, 147, 22, 255), stop:0.275 rgba(236, 191, 49, 255), stop:0.39 rgba(243, 61, 34, 255), stop:0.555 rgba(135, 81, 60, 255), stop:0.667 rgba(121, 75, 255, 255), stop:0.825 rgba(164, 255, 244, 255), stop:0.885 rgba(104, 222, 71, 255), stop:1 rgba(93, 128, 0, 255));")
            self.tabs = QTabWidget()
            self.tab1 = QWidget()	
            self.tab2 = QWidget()
            self.tabs.addTab(self.tab1,"            START               ")
            self.tabs.addTab(self.tab2,"            MONITOR             ")
            self.layout.addWidget(self.tabs)

            self.frame = QtWidgets.QFrame(self.tab1)
            self.frame.setGeometry(QtCore.QRect(10, 20, 261, 200))
            self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
            self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
            self.frame.setObjectName("frame")
            self.gridLayoutWidget = QtWidgets.QWidget(self.frame)
            self.gridLayoutWidget.setGeometry(QtCore.QRect(10, 30, 241, 58))
            self.gridLayoutWidget.setObjectName("gridLayoutWidget")
            self.gridLayout_2 = QtWidgets.QGridLayout(self.gridLayoutWidget)
            self.gridLayout_2.setContentsMargins(11, 11, 11, 11)
            self.gridLayout_2.setSpacing(6)
            self.gridLayout_2.setObjectName("gridLayout_2")
            self.label_2 = QtWidgets.QLabel(self.gridLayoutWidget)
            self.label_2.setObjectName("label_2")
            self.gridLayout_2.addWidget(self.label_2, 10, 0, 1, 1)
            self.label = QtWidgets.QLabel(self.gridLayoutWidget)
            self.label.setObjectName("label")
            self.gridLayout_2.addWidget(self.label, 6, 0, 1, 1)
            self.usr_lineEdit = QtWidgets.QLineEdit(self.gridLayoutWidget)
            self.usr_lineEdit.setObjectName("usr_lineEdit")
            self.gridLayout_2.addWidget(self.usr_lineEdit, 6, 1, 1, 1)
            self.pwd_lineEdit = QtWidgets.QLineEdit(self.gridLayoutWidget)
            self.pwd_lineEdit.setObjectName("pwd_lineEdit")
            self.gridLayout_2.addWidget(self.pwd_lineEdit, 10, 1, 1, 1)
            self.label_3 = QtWidgets.QLabel(self.frame)
            self.label_3.setGeometry(QtCore.QRect(80, 10, 101, 17))
            self.label_3.setObjectName("label_3")
            self.Login_Button = QtWidgets.QPushButton(self.frame)
            self.Login_Button.setGeometry(QtCore.QRect(100, 90, 89, 25))
            self.Login_Button.setObjectName("Login_Button")
            self.verticalLayoutWidget = QtWidgets.QWidget(self.tab1)
            self.verticalLayoutWidget.setGeometry(QtCore.QRect(300, 0, 311, 311))
            self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
            self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
            self.verticalLayout.setContentsMargins(11, 11, 11, 11)
            self.verticalLayout.setSpacing(6)
            self.verticalLayout.setObjectName("verticalLayout")
            self.START_CART = QtWidgets.QPushButton(self.verticalLayoutWidget)
            self.START_CART.setObjectName("START_CART")
            self.verticalLayout.addWidget(self.START_CART)
            self.listView = QtWidgets.QListView(self.verticalLayoutWidget)
            self.listView.setObjectName("listView")
            self.verticalLayout.addWidget(self.listView)
            self.frame_Release = QtWidgets.QFrame(self.tab2)
            self.frame_Release.setGeometry(QtCore.QRect(10, 0, 631, 91))
            self.frame_Release.setFrameShape(QtWidgets.QFrame.StyledPanel)
            self.frame_Release.setFrameShadow(QtWidgets.QFrame.Raised)
            self.frame_Release.setObjectName("frame_Release")
            self.horizontalLayoutWidget = QtWidgets.QWidget(self.frame_Release)
            self.horizontalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 301, 91))
            self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
            self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
            self.horizontalLayout.setContentsMargins(11, 11, 11, 11)
            self.horizontalLayout.setSpacing(6)
            self.horizontalLayout.setObjectName("horizontalLayout")
            self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
            self.horizontalLayout_2.setContentsMargins(11, 11, 11, 11)
            self.horizontalLayout_2.setSpacing(6)
            self.horizontalLayout_2.setObjectName("horizontalLayout_2")
            self.Fetch_status = QtWidgets.QPushButton(self.horizontalLayoutWidget)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Fetch_status.sizePolicy().hasHeightForWidth())
            self.Fetch_status.setSizePolicy(sizePolicy)
            self.Fetch_status.setObjectName("Fetch_status")
            self.horizontalLayout_2.addWidget(self.Fetch_status)
            self.Release_cart = QtWidgets.QPushButton(self.horizontalLayoutWidget)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Release_cart.sizePolicy().hasHeightForWidth())
            self.Release_cart.setSizePolicy(sizePolicy)
            self.Release_cart.setObjectName("Release_cart")
            self.horizontalLayout_2.addWidget(self.Release_cart)
            self.horizontalLayout.addLayout(self.horizontalLayout_2)
            self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.frame_Release)
            self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(320, 19, 311, 71))
            self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
            self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
            self.verticalLayout_2.setContentsMargins(11, 11, 11, 11)
            self.verticalLayout_2.setSpacing(6)
            self.verticalLayout_2.setObjectName("verticalLayout_2")
            self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
            self.horizontalLayout_4.setContentsMargins(11, 11, 11, 11)
            self.horizontalLayout_4.setSpacing(6)
            self.horizontalLayout_4.setObjectName("horizontalLayout_4")
            self.Cart_name_display = QtWidgets.QLabel(self.verticalLayoutWidget_2)
            self.Cart_name_display.setObjectName("Cart_name_display")
            self.horizontalLayout_4.addWidget(self.Cart_name_display)
            self.status_label = QtWidgets.QLabel(self.verticalLayoutWidget_2)
            self.status_label.setObjectName("status_label")
            self.horizontalLayout_4.addWidget(self.status_label)
            self.Cart_status_edit = QtWidgets.QLabel(self.verticalLayoutWidget_2)
            self.Cart_status_edit.setObjectName("Cart_status_edit")
            self.horizontalLayout_4.addWidget(self.Cart_status_edit)
            self.verticalLayout_2.addLayout(self.horizontalLayout_4)
            self.Cart_battery = QtWidgets.QProgressBar(self.verticalLayoutWidget_2)
            self.Cart_battery.setProperty("value", 55)
            self.Cart_battery.setObjectName("Cart_battery")
            self.verticalLayout_2.addWidget(self.Cart_battery)
            self.Invertor_battery = QtWidgets.QProgressBar(self.verticalLayoutWidget_2)
            self.Invertor_battery.setProperty("value", 24)
            self.Invertor_battery.setObjectName("Invertor_battery")
            self.verticalLayout_2.addWidget(self.Invertor_battery)
            self.frame_startHere_pause = QtWidgets.QFrame(self.tab2)
            self.frame_startHere_pause.setGeometry(QtCore.QRect(10, 110, 631, 81))
            self.frame_startHere_pause.setFrameShape(QtWidgets.QFrame.StyledPanel)
            self.frame_startHere_pause.setFrameShadow(QtWidgets.QFrame.Raised)
            self.frame_startHere_pause.setObjectName("frame_startHere_pause")
            self.horizontalLayoutWidget_4 = QtWidgets.QWidget(self.frame_startHere_pause)
            self.horizontalLayoutWidget_4.setGeometry(QtCore.QRect(0, 10, 631, 61))
            self.horizontalLayoutWidget_4.setObjectName("horizontalLayoutWidget_4")
            self.horizontalLayout_5 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_4)
            self.horizontalLayout_5.setContentsMargins(11, 11, 11, 11)
            self.horizontalLayout_5.setSpacing(6)
            self.horizontalLayout_5.setObjectName("horizontalLayout_5")
            self.start_ride_here_Button = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_ride_here_Button.sizePolicy().hasHeightForWidth())
            self.start_ride_here_Button.setSizePolicy(sizePolicy)
            self.start_ride_here_Button.setObjectName("start_ride_here_Button")
            self.horizontalLayout_5.addWidget(self.start_ride_here_Button)
            self.Pause_ride_Button = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Pause_ride_Button.sizePolicy().hasHeightForWidth())
            self.Pause_ride_Button.setSizePolicy(sizePolicy)
            self.Pause_ride_Button.setObjectName("Pause_ride_Button")
            self.horizontalLayout_5.addWidget(self.Pause_ride_Button)
            self.frame_files = QtWidgets.QFrame(self.tab2)
            self.frame_files.setGeometry(QtCore.QRect(10, 210, 631, 101))
            self.frame_files.setFrameShape(QtWidgets.QFrame.StyledPanel)
            self.frame_files.setFrameShadow(QtWidgets.QFrame.Raised)
            self.frame_files.setObjectName("frame_files")
            self.gridLayoutWidget_2 = QtWidgets.QWidget(self.frame_files)
            self.gridLayoutWidget_2.setGeometry(QtCore.QRect(0, 0, 611, 91))
            self.gridLayoutWidget_2.setObjectName("gridLayoutWidget_2")
            self.gridLayout_3 = QtWidgets.QGridLayout(self.gridLayoutWidget_2)
            self.gridLayout_3.setSizeConstraint(QtWidgets.QLayout.SetMinAndMaxSize)
            self.gridLayout_3.setContentsMargins(11, 11, 11, 11)
            self.gridLayout_3.setSpacing(6)
            self.gridLayout_3.setObjectName("gridLayout_3")
            self.cart_name_edit = QtWidgets.QLineEdit(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.cart_name_edit.sizePolicy().hasHeightForWidth())
            self.cart_name_edit.setSizePolicy(sizePolicy)
            self.cart_name_edit.setAlignment(QtCore.Qt.AlignCenter)
            self.cart_name_edit.setReadOnly(False)
            self.cart_name_edit.setObjectName("cart_name_edit")
            self.gridLayout_3.addWidget(self.cart_name_edit, 0, 0, 1, 1)
            self.Sart_Gcloud_int = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Sart_Gcloud_int.sizePolicy().hasHeightForWidth())
            self.Sart_Gcloud_int.setSizePolicy(sizePolicy)
            self.Sart_Gcloud_int.setObjectName("Sart_Gcloud_int")
            self.gridLayout_3.addWidget(self.Sart_Gcloud_int, 0, 1, 1, 1)
            self.Kill_gcloud_int = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Kill_gcloud_int.sizePolicy().hasHeightForWidth())
            self.Kill_gcloud_int.setSizePolicy(sizePolicy)
            self.Kill_gcloud_int.setObjectName("Kill_gcloud_int")
            self.gridLayout_3.addWidget(self.Kill_gcloud_int, 0, 2, 1, 1)
            self.start_code_b = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_code_b.sizePolicy().hasHeightForWidth())
            self.start_code_b.setSizePolicy(sizePolicy)
            self.start_code_b.setObjectName("start_code_b")
            self.gridLayout_3.addWidget(self.start_code_b, 1, 1, 1, 1)
            self.Start_code_a = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.Start_code_a.sizePolicy().hasHeightForWidth())
            self.Start_code_a.setSizePolicy(sizePolicy)
            self.Start_code_a.setObjectName("Start_code_a")
            self.gridLayout_3.addWidget(self.Start_code_a, 1, 0, 1, 1)
            self.start_code_f = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_code_f.sizePolicy().hasHeightForWidth())
            self.start_code_f.setSizePolicy(sizePolicy)
            self.start_code_f.setObjectName("start_code_f")
            self.gridLayout_3.addWidget(self.start_code_f, 2, 2, 1, 1)
            self.start_code_e = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_code_e.sizePolicy().hasHeightForWidth())
            self.start_code_e.setSizePolicy(sizePolicy)
            self.start_code_e.setObjectName("start_code_e")
            self.gridLayout_3.addWidget(self.start_code_e, 2, 1, 1, 1)
            self.start_code_d = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_code_d.sizePolicy().hasHeightForWidth())
            self.start_code_d.setSizePolicy(sizePolicy)
            self.start_code_d.setObjectName("start_code_d")
            self.gridLayout_3.addWidget(self.start_code_d, 2, 0, 1, 1)
            self.start_code_c = QtWidgets.QPushButton(self.gridLayoutWidget_2)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.start_code_c.sizePolicy().hasHeightForWidth())
            self.start_code_c.setSizePolicy(sizePolicy)
            self.start_code_c.setObjectName("start_code_c")
            self.gridLayout_3.addWidget(self.start_code_c, 1, 2, 1, 1)
            # self.toolBox.addItem(self.MONITOR, "")

            self.retranslateUi(self)
            # self.toolBox.setCurrentIndex(0)
            QtCore.QMetaObject.connectSlotsByName(self)

            self.setLayout(self.layout)
        except Exception as err:
            print("Error message in Tab2 initialization: ", err)


    # def retranslateUi(self, MainWindow):
    def retranslateUi(self, QWidget):
            _translate = QtCore.QCoreApplication.translate
            # MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
            QWidget.setWindowTitle(_translate("MainWindow", "MainWindow"))

            self.label_2.setText(_translate("MainWindow", "Password :"))
            self.label.setText(_translate("MainWindow", "User Name :"))
            self.label_3.setText(_translate("MainWindow", "Admin Login"))
            self.Login_Button.setText(_translate("MainWindow", "Login"))
            self.START_CART.setText(_translate("MainWindow", "START CART"))
            # self.toolBox.setItemText(self.toolBox.indexOf(self.tab1), _translate("MainWindow", "START"))
            self.Fetch_status.setText(_translate("MainWindow", "Fetch Status"))
            self.Release_cart.setText(_translate("MainWindow", "Release Cart"))
            self.Cart_name_display.setText(_translate("MainWindow", "Cart_name"))
            self.status_label.setText(_translate("MainWindow", " cart\'s status"))
            self.Cart_status_edit.setText(_translate("MainWindow", "cart_status-edit"))
            self.start_ride_here_Button.setText(_translate("MainWindow", "Start Ride Here"))
            self.Pause_ride_Button.setText(_translate("MainWindow", "Pause Ride"))
            self.cart_name_edit.setText(_translate("MainWindow", "MyCart"))
            self.Sart_Gcloud_int.setText(_translate("MainWindow", "Start Gcloud Int"))
            self.Kill_gcloud_int.setText(_translate("MainWindow", "Kill_gcloud_int"))
            self.start_code_b.setText(_translate("MainWindow", "Start code b"))
            self.Start_code_a.setText(_translate("MainWindow", "Start code a"))
            self.start_code_f.setText(_translate("MainWindow", "Start code f"))
            self.start_code_e.setText(_translate("MainWindow", "Start code e"))
            self.start_code_d.setText(_translate("MainWindow", "Start code d"))
            self.start_code_c.setText(_translate("MainWindow", "Start code c"))
            # self.toolBox.setItemText(self.toolBox.indexOf(self.tab2), _translate("MainWindow", "MONITOR"))







########################################################################################################################
############TAB3 code############################################################################################################


class QWidget_Tab3(QWidget):
    def __init__(self):
        try:
            super(QWidget, self).__init__()
            self.layout = QVBoxLayout(self)

            self.Reset_All = QPushButton()
            self.Reset_All.clicked.connect(self.Reset_All_Method)
            self.layout.addWidget(self.Reset_All)
            self.setLayout(self.layout)
            self.retranslateUi(self)
            QtCore.QMetaObject.connectSlotsByName(self)

        except Exception as err:
            print("Error message in Tab3 initialization: ", err)
    
    def Reset_All_Method(self):
        os.system('sh /home/infyav/Desktop/GCart_WS/Reset.sh')

    def retranslateUi(self, QWidget):
        _translate = QtCore.QCoreApplication.translate
        QWidget.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.Reset_All.setText(_translate("MainWindow", "Reset Everything"))




########################################################################################################################
#############TAB4 code###########################################################################################################

class QWidget_Tab4(QWidget):
    def __init__(self):
        try:
            super(QWidget, self).__init__()
            self.layout = QVBoxLayout(self)
            time.sleep(0.05)
            self.frame = rviz.VisualizationFrame()
            reader = rviz.YamlConfigReader()
            config = rviz.Config()
            print("in TAB4 check 1")
            Rviz_config_file = "//home/infyav/Desktop/GCart_WS/velodyne_rviz.rviz"
            reader.readFile(config, Rviz_config_file)
            self.frame.initialize()
            self.frame.load(config)
            self.manager = self.frame.getManager()


            self.layout.addWidget(self.frame)
            self.setLayout(self.layout)
            # atexit.register(self.kill_proc, RVIZ_APP)


        except Exception as err:
            print("Error message in Tab4 initialization: ", err)



########################################################################################################################
########################################################################################################################


if __name__ == '__main__':
    try:
        gcart_status= "IDLE"
        rospy.init_node('golf_cart_GUI')
        # rospy.Subscriber("/gcart_status",String, status_callback)
        GUI_to_Cart_topic_handle = rospy.Publisher("/gui_to_gcart",String, queue_size=1, latch=True )
        rate =rospy.Rate(2)

        app = QApplication(sys.argv)
        ex = App()
        rospy.Subscriber("/gcart_status",String, status_callback, ex)
        
        sys.exit(app.exec_())

        # ex.table_widget.button_image = QIcon('04_Cart_IDEL.png')

    except rospy.ROSInterruptException as ros_err:
        print("error in main",ros_err)
        # pass
            