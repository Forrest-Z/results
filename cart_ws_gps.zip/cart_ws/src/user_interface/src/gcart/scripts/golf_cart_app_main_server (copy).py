#!/usr/bin/env python

import requests
import rospy
import geocoder
import datetime
import json

from gcart.srv import *
from config import *

#Accept Booking Requests, Name of the cart is set here
def GolfCartBookingAccept_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/booking/accept/' + req.name
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = datastore['booking']
    return resp


def GolfCartBookingArrival_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/tour/alert/' + req.name
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = datastore['booking']
    return resp

def GolfCartBookingAssigned_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/booking/current/' + req.name
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = datastore['reference']
    return resp

def GolfCartBookingFinish_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/tour/finish/' + req.name
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = datastore['booking']
    return resp

def GolfCartBookingStarted_handler(req):
    print "Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/tour/start/' + req.name
    r = requests.get(url)
    datastore = json.loads(r.content)

    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = datastore['booking']
    return resp

def GolfCartLocationUpdater_handler(req):
    print "Requested [%s , %s]" % (req.latitude, req.longitude)
    g = geocoder.google([req.latitude, req.longitude], method='reverse')

    print( g.street_long )
    print(g.city ) 
    print( g.state_long )
    print( g.postal )
    print( g.country_long )

    #address = g.street_long + ", " + g.city + ", " + \
    address = "Location" 
#g.city + ", " + \
#        g.state_long + " - " + g.postal + ", " + g.country_long
    print("Returning [%s]" % (address))

    url = host+'/_ah/api/golfCartApi/v1/golfCart/location/update/' + req.id
    print(url)
    data={
             "latitude": req.latitude,
             "longitude": req.longitude
                         
         }
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data=json.dumps(data), headers=headers)

    print(r.content)

    return GolfCartLocationResponse(address)

def GeoToAddress_handler(req):
    print "Requested [%s , %s]" % (req.latitude, req.longitude)
    g = geocoder.google([req.latitude, req.longitude], method='reverse')
    address = g.street_long + ", " + g.city + ", " + g.state_long + " - " + g.postal+ ", " + g.country_long
    print("Returning [%s]" % (address))
    return GeoToAddressResponse(address)


### new handler function(for service 'golf_cart_status' call back) checking the cart status
def GolfCartStatus_handler(req):          
    print "Status Requested [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/' + req.name

    r = requests.get(url)
    datastore = json.loads(r.content)
    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']
    resp.bookingref = ""
    return resp

### new handler function(for service 'golf_cart_release_booking' call back) for releasing the cart from booking
def GolfCartReleaseBooking_handler(req):
    print "Release Requested for cart [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/booking/release/' + req.name # release the cart api call
    r = requests.get(url)
    datastore = json.loads(r.content)
    print(r.content)
    resp = GolfCartBookingResponse()
    resp.status = datastore['status']       # status fetched back should be available
    resp.bookingref = ""
    return resp


### new handler function(for service 'golf_cart_pick_dest_gps' call back) to fetch pick and destination GPS coordinates
def GolfCartStartDestGPS_handler(req):
    print "Requested Start and Destination Stations of cart [%s]" % (req.name)

    url = host+'/_ah/api/golfCartApi/v1/golfCart/booking/current/' + req.name # release the cart api call
    r = requests.get(url)
    datastore = json.loads(r.content)
    print(r.content)
    originStation = datastore['originStation']       # status fetched back should be available
    destinationStation = datastore['destinationStation']


    resp = PickDestGPSResponse()
    resp.pick_latitude, resp.pick_longitude  = StationGPS(originStation)
    resp.dest_latitude, resp.dest_longitude  = StationGPS(destinationStation)
    return resp

### new handler function(for service 'golf_cart_otp_verification' call back) to verify OTP
def OTPVerification_handler(req):
    print "Requested OTP verification" 
    resp = OTPVerificationResponse()
    # print(req.otp)
    if req.otp == '1234':
        print "Correct OTP from server"
        resp.status = True
        return resp
    else:
        print "InCorrect OTP from server"
        resp.status = False
        return resp

def StationGPS(station):
    print "Station [%s]" % (station)

    url = host+'/_ah/api/stationApi/v1/station/' + station # release the cart api call
    r = requests.get(url)
    datastore = json.loads(r.content)
    print(r.content)
    return datastore['location']['latitude'], datastore['location']['longitude']

if __name__ == "__main__":
    rospy.init_node('golf_cart_app_main_server')
    sGCBAC = rospy.Service('golf_cart_booking_accept_push',
                      GolfCartBooking, GolfCartBookingAccept_handler)
    sGCBAR = rospy.Service('golf_cart_booking_arrival_push',
                      GolfCartBooking, GolfCartBookingArrival_handler)
    sGCBAS = rospy.Service('golf_cart_booking_assigned_pull',
                      GolfCartBooking, GolfCartBookingAssigned_handler)
    sGCBFI = rospy.Service('golf_cart_booking_finish_push',
                      GolfCartBooking, GolfCartBookingFinish_handler)
    sGCBST = rospy.Service('golf_cart_booking_started_push',
                      GolfCartBooking, GolfCartBookingStarted_handler)
    sGCLUP = rospy.Service('golf_cart_location_updater',
                      GolfCartLocation, GolfCartLocationUpdater_handler)
    sGTA   = rospy.Service('geo_to_address', GeoToAddress, GeoToAddress_handler)

### service for checking if the cart has reached
    sGCREA = rospy.Service('golf_cart_status',
                      GolfCartBooking, GolfCartStatus_handler)
### service for releasing the cart from booking    
    sGCRBO = rospy.Service('golf_cart_release_booking',
                      GolfCartBooking, GolfCartReleaseBooking_handler)
### service to fetch pick and destination GPS coordinates
    sGCPDG = rospy.Service('golf_cart_pick_dest_gps',
                      PickDestGPS, GolfCartStartDestGPS_handler)
### service to verify OTP
    sGTA   = rospy.Service('golf_cart_otp_verification', OTPVerification, OTPVerification_handler)

    print "App server is ready"

    rospy.spin()
