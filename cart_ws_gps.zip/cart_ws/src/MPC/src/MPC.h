#ifndef MPC_H
#define MPC_H

#include <vector>
#include "Eigen-3.3/Eigen/Core"

#define NUM_STATE	6
#define NUM_ACTRS	2
#define MILPH_2_MPS	0.4470
#define ANG_2_STEER	1.0
#define ACC_2_THRTL	1.0 // 0.283 // 10 divided by time taken to accelerate from 0 to 22.72mph (10mps)
#define MPC_DT 		0.1

using namespace std;

class MPC {
	public:
	MPC();

	virtual ~MPC();

	// Solve the model given an initial state and polynomial coefficients.
	// Return the first actuatotions.
	vector<double> Solve(Eigen::VectorXd state, Eigen::VectorXd coeffs);

	// Adjust for communication latency
	void AdjustLatency( double& px, double& py, double& psi, double& v, double steer_curr, double throttle_curr, double latency ) ;
};

#endif /* MPC_H */
