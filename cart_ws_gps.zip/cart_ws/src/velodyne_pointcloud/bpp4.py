#!/usr/bin/env python


import numpy as np
import math as MT
import constants as constant
import rospy
from sensor_msgs.msg import NavSatFix 
from std_msgs.msg import Float64, Int8
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped,TransformStamped
import constants2 as constant
import tf
import matplotlib.pyplot as plt

class values:
  def __init__(self,grid_on_x,grid_on_y,resolution,GRID_TEST,start_global):
    self.grid_on_x=grid_on_x
    self.grid_on_y=grid_on_y
    self.resolution=resolution
    self.GRID_TEST=GRID_TEST
    self.start_global=start_global
    self.feed_map=True
    self.get_start_point=True
    self.path=[]


class waypoints():
    def __init__(self,input_co_ordinates,center):
        self.input_co_ordinates=input_co_ordinates
        self.center=center

### LANE CLASS
class vehicle_params():
  def __init__(self,lane_number,goal_lane,state):
    self.lane_number=lane_number
    self.goal_lane=goal_lane
    self.state=state


# def transform_frame_co_ordinates(current_frame_waypoints_obj, frame_expected):
#     displaced_matrix = np.array([frame_expected[0]-current_frame_waypoints_obj.center[0],frame_expected[1]-current_frame_waypoints_obj.center[1]])
#     transformed_matrix=np.add(current_frame_waypoints_obj.input_co_ordinates,displaced_matrix)

#     return waypoints(transformed_matrix,frame_expected)

def transform_frame_co_ordinates(current_frame_waypoints_obj,localization):
    wp_list=[]
    # print('len',len(current_frame_waypoints_obj))
    # print('localization',localization)
    # print('Normal Waypoints')
    # for i in current_frame_waypoints_obj:
    #   print(i)
    for wp in current_frame_waypoints_obj:
      psi=localization[2]
      px_Offset = wp[0] - localization[0]
      py_Offset = wp[1] - localization[1]

      ptsx = px_Offset * MT.cos(psi) + py_Offset * MT.sin(psi) 
      ptsy = py_Offset * MT.cos(psi) - px_Offset * MT.sin(psi)
      #wp_list.append([ptsx+15*1/get_value.resolution,ptsy+15*1/get_value.resolution])
      wp_list.append([ptsx+75,ptsy+75])
    print('Transformed Waypoints')
    # for i in wp_list:
    #   print(i)
    return wp_list



def closest_index(lane_index,localized_point):
  lane_waypoints=constant.waypoints_list[lane_index]
  waypoints_tree=constant.waypoint_tree_list[lane_index]

  closest_idx=waypoints_tree.query(localized_point,1)[1]
  closest_coord=lane_waypoints[closest_idx][:2]
  prev_coord=lane_waypoints[closest_idx-1][:2]
  cl_vect=np.array(closest_coord)
  prev_vect=np.array(prev_coord)
  pos_vect=np.array(localized_point)
  val= np.dot(cl_vect-prev_vect,pos_vect-cl_vect)
  if val>0:
    temp=closest_idx
    closest_idx=(closest_idx+1)%len(lane_waypoints)
    if(closest_idx==0 and temp>0):
      closest_idx=temp
  return closest_idx

### FLOOR VALUE
def idx(value):
  return int(MT.floor(value))


### TRANSFORM VEHICLE CO-ORDINATES 
def transform_vehicle_co_ordinates(vehicle_point_object, next_state, angle_of_rotation):
    displaced_matrix = np.array([next_state[0]-vehicle_point_object.center[0],next_state[1]-vehicle_point_object.center[1]])
    transformed_matrix=np.add(vehicle_point_object.input_co_ordinates,displaced_matrix)
    return constant.vehicle_points(rotate_vehicle_co_ordinates(constant.vehicle_points(transformed_matrix,next_state),angle_of_rotation),next_state)
  
  
### ROTATE VEHICLE CO-ORDINATES     
def rotate_vehicle_co_ordinates(vehicle_point_object,angle_of_rotation):
    rotation_matrix = np.array([[np.cos(angle_of_rotation), np.sin(angle_of_rotation)], 
                                [-np.sin(angle_of_rotation), np.cos(angle_of_rotation)]])
    return np.add(vehicle_point_object.center,np.matmul(np.subtract(vehicle_point_object.input_co_ordinates,vehicle_point_object.center), rotation_matrix))


### CHECK VEHICLE IN SAFE POSITION  
def is_vehicle_in_safe_position(vehicle_point_object,grid):
  grid_on_x=len(grid[0])
  grid_on_y=len(grid)
  for point in vehicle_point_object.input_co_ordinates:
    if(is_within_grid( idx(point[0]),idx(point[1]),grid_on_x,grid_on_y) and  
       (grid[idx(point[0])][idx(point[1])]==0)):
      continue
    else:
      return False
  return True

### CHECK WITHIN GRID  
def is_within_grid(x,y,grid_on_x,grid_on_y):
  return (x>=0 and x<grid_on_x and y>=0 and y<grid_on_y)

def validate_safe(waypoints,vehicle_pt_obj_actual,grid):
  for wp in waypoints:
    #print(wp)
    transformed_coordinates=transform_vehicle_co_ordinates(vehicle_pt_obj_actual,[wp[0],wp[1]],wp[2])
    #print(transformed_coordinates.input_co_ordinates)
    if(not is_vehicle_in_safe_position(transformed_coordinates,grid)):
      return False
  return True



def successor_states(lane,lanes_available,state,localization):
        """
        Provides the possible next states given the current state for the FSM discussed in the course,
        with the exception that lane changes happen instantaneously, so LCL and LCR can only transition back to KL.
        """
        if state in ("KL","STOP"):
            states = ["KL","STOP"]
            if lane != 0:
                states.append("LCL")
            if lane != (lanes_available-1):
                states.append("LCR")
        
        # elif state in ("LCL", "LCR"):
        #     waypoints_lst=constant.waypoints_list[lane]
        #     near_index=closest_index(lane,[localization[0],localization[1]])
        #     cte=MT.sqrt((localization[0]-waypoints_lst[near_index][0])**2+
        #     (localization[1]-waypoints_lst[near_index][1])**2)
        #     if(cte<0.2):
        #       states = ["KL","STOP"]
        #     else:
        #        states = [state,"STOP"]
        
        # elif state in ("LCL", "LCR"):
        #     states = ["KL","STOP"]

        elif state =="LCL":
             states = ["PLCL","STOP"]

        elif state =="LCR":
             states = ["PLCR","STOP"]

        elif state == "PLCL":
            print('cte',calculate_cte(lane,localization),state)
            if(calculate_cte(lane,localization)<0.2):
              
                states = ["KL","STOP"]
            else:
                states = ["PLCL","STOP"]
                
        elif state == "PLCR":
            print('cte',calculate_cte(lane,localization),state)
            if(calculate_cte(lane,localization)<0.2):
                states = ["KL","STOP"]
            else:
                states = ["PLCR","STOP"]
        return states
      
def calculate_cte(lane,localization):
    waypoints_lst=constant.waypoints_list[lane]
    near_index=closest_index(lane,[localization[0],localization[1]])
    wp=waypoints_lst[near_index:near_index+4]
    wp_x=[w[0] for w in wp]
    wp_y=[w[1] for w in wp]
    coeff=np.polyfit(wp_x,wp_y,2)
    cte=np.polyval(coeff,localization[0])
    print('CTEEEEEEEEEEEEEE',abs(cte-localization[1]))
    return cte

def calculate_cost(lane_num,goal_lane,localization,grid):
    waypoints_lst=constant.waypoints_list[lane_num]
    near_index=closest_index(lane_num,[localization[0],localization[1]])
    print(near_index)
    #near_index=0
    waypoints_lst=waypoints_lst[near_index:near_index + constant.offset_value]
    #print('near_index',near_index)
    print([localization[0],localization[1]])
    #wp_xy=np.array([[w[0]*1/get_value.resolution,w[1]*1/get_value.resolution] for w in waypoints_lst])
    wp_xy=np.array([[w[0],w[1]] for w in waypoints_lst])
    #waypoint_obj=waypoints(wp_xy,[localization[0]*1/get_value.resolution,localization[1]*1/get_value.resolution])
    #local_wp=transform_frame_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)])
    #I_CHANGED
    waypoint_obj=np.array(transform_frame_co_ordinates(wp_xy,localization))
    #vehicle_yaw=tf.transformations.euler_from_quaternion((localization[3],localization[4],localization[5],localization[6]))[2]
    #local_wp=transform_vehicle_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)],localization[2])
    #local_wp=transform_frame_co_ordinates(waypoint_obj,[0,75])
    #Multiply by resolution
    #get_value.path=local_wp.input_co_ordinates
    get_value.path=waypoint_obj

    wp_theta=np.array([[tf.transformations.euler_from_quaternion((w[3],w[4],w[5],w[6]))[2]] for w in waypoints_lst])
    # waypoints=transform_waypoints(waypoints,localization)
    #print(local_wp.input_co_ordinates)
    print('----------')
    #print(wp_theta)
    #waypoints_lst=np.hstack((local_wp.input_co_ordinates,wp_theta))
    waypoints_lst=np.hstack((waypoint_obj,wp_theta))
    show_path(waypoints_lst,constant.vehicle_pt_obj_actual)
    #print(validate_safe(waypoints_lst,constant.vehicle_pt_obj_actual,grid) and len(waypoints_lst)>=1)
    if(validate_safe(waypoints_lst,constant.vehicle_pt_obj_actual,grid) and len(waypoints_lst)>=1):
      delta_d=float(abs(lane_num-goal_lane))
      #print(delta_d)
      cost= 1 - MT.exp(-(abs(delta_d) / len(waypoints_lst)))
      return cost,near_index
    else:
      #print('in')
      return float('inf'),near_index
    
    
def choose_next_state(localization,grid):
        lanes_available = len(constant.waypoints_list)
        costs = []
        states = successor_states(vehicle_state.lane_number,lanes_available,vehicle_state.state,localization)
        #print(states)
        for state in states:
          print('selected state',state)
          value=constant.lane_direction[state]
          print('value',value)
          if value!=None:
            lane_index=vehicle_state.lane_number + value
            print('lane_index',lane_index)
            cost,near_index = calculate_cost(lane_index,vehicle_state.goal_lane,localization,grid)
            costs.append({"cost" : cost, "state": state,"lane_index":lane_index,"near_index":near_index})
          else:
            costs.append({"cost" : 100, "state": state,"lane_index":vehicle_state.lane_number,"near_index":0})
        #print(costs)   
        best = min(costs, key=lambda s: s['cost'])
        vehicle_state.lane_number=best["lane_index"]
        vehicle_state.state=best["state"]

        lane_to_be_selected = best["lane_index"]
        # pub = rospy.Publisher('/lane_index', Int8, queue_size=10)
        # pub.publish(lane_to_be_selected)
        print(best["state"])
        print(best["lane_index"])
        return best["lane_index"],best["near_index"]


        
#def compass(value):
#  global compass
#  #print("Value:", value)
#  compass = value.data

#def localization(data):
#  global current_location, compass
#  lat = data.latitude
#  long_ = data.longitude
#  current_location = [lat, long_, compass]


def trigger_behaviour_planning(msg):
  if(get_value.get_start_point==True):
    print('Behavior Planner Triggered!')
    get_value.get_start_point=False
    quaternion = (
        msg.transform.rotation.x,
        msg.transform.rotation.y,
        msg.transform.rotation.z,
        msg.transform.rotation.w)
    euler = tf.transformations.euler_from_quaternion(quaternion)
    roll = euler[0]
    pitch = euler[1]
    yaw = euler[2]
    get_value.start_global =[msg.transform.translation.x, msg.transform.translation.y, yaw]
    lane_index,near_index=choose_next_state(get_value.start_global,get_value.GRID_TEST)
    # ######Check
    # near_index=0
    waypoints_lst=constant.waypoints_list[vehicle_state.lane_number]
    waypoints_lst=waypoints_lst[near_index:near_index + constant.offset_value]
    
    #print(waypoints_lst)
    #print(waypoints_lst)
    #glob_waypoints=np.array([[w[0],w[1]] for w in waypoints_lst])
    #waypoint_obj=waypoints(glob_waypoints,[0,0])
    #local_waypoints=transform_frame_co_ordinates(waypoint_obj,[idx(get_value.grid_on_x/2),idx(get_value.grid_on_y/2)])
    
    pub = rospy.Publisher('/local_trajectory', Path, queue_size=50)
    # path_pub=Path()
    # path_pub.header.frame_id='world'
    # for i in range(len(waypoints_lst)):#
    #   new_pose=PoseStamped()
    #   path_now=waypoints_lst[i]
    #   # quaternion_map=tf.transformations.quaternion_from_euler(0.0, 0.0, path_now[2])
    #   new_pose.header.seq=i+1
    #   new_pose.header.frame_id='world'
    #   new_pose.pose.position.x=path_now[0]
    #   new_pose.pose.position.y=path_now[1]
    #   new_pose.pose.position.z=path_now[2]
    #   new_pose.pose.orientation.x= path_now[3]
    #   new_pose.pose.orientation.y= path_now[4]
    #   new_pose.pose.orientation.z= path_now[5]
    #   new_pose.pose.orientation.w= path_now[6]
    #   # new_pose.pose.orientation=path_now[3]
    #   path_pub.poses.append(new_pose)

    path_pub=Path()
    path_pub.header.frame_id='local_map'
    for i in range(len(waypoints_lst)):#
      new_pose=PoseStamped()
      path_now=get_value.path[i]
      path_now_2=waypoints_lst[i]
      # quaternion_map=tf.transformations.quaternion_from_euler(0.0, 0.0, path_now[2])
      new_pose.header.seq=i+1
      new_pose.header.frame_id='local_map'
      new_pose.pose.position.x=path_now[0]/(1/get_value.resolution)
      new_pose.pose.position.y=path_now[1]/(1/get_value.resolution)
      new_pose.pose.position.z=0
      new_pose.pose.orientation.x= path_now_2[3]
      new_pose.pose.orientation.y= path_now_2[4]
      new_pose.pose.orientation.z= path_now_2[5]
      new_pose.pose.orientation.w= path_now_2[6]
      # new_pose.pose.orientation=path_now[3]
      path_pub.poses.append(new_pose)
      # rate = rospy.Rate(50)
      # start_time=time.time()
    pub.publish(path_pub)
    #print('path published')
    get_value.feed_map=True
    #get_value.is_processing=True
    get_value.get_start_point=True



def feed_map(msg):
  if(get_value.feed_map==True):
    print('FEEDING THE MAP IN')
    get_value.feed_map=False
    local_grid=msg.data
    grid_on_x=msg.info.width
    grid_on_y=msg.info.height
    resolution=msg.info.resolution
    #local_grid=np.flipud(np.rot90(np.reshape(local_grid,(grid_on_x,grid_on_y))))
    local_grid=np.flipud(np.rot90(np.reshape(local_grid,(grid_on_x,grid_on_y))))
    local_grid[local_grid != 0]=1
    get_value.GRID_TEST=local_grid
    get_value.resolution=resolution
    #print(len(local_grid))
    get_value.grid_on_x=get_value.grid_on_y=get_value.GRID_TEST.shape[0]

    # X=[]
    # Y=[]
    # for i in range(len(get_value.GRID_TEST)):
    #   for j in range(len(get_value.GRID_TEST[0])):
    #     if(get_value.GRID_TEST[i][j]==1):
    #         X.append(i)
    #         Y.append(j)
    # plt.scatter(X,Y)
    # plt.show()
  
def show_path(path,vehicle_pt_obj_act):
  X=[]
  Y=[]
  Theta=[]
  X     += [p[0] for p in path]
  Y     += [p[1] for p in path]
  Theta+=[p[2] for p in path]
  for i in range(len(X)-1):
    Xj=[]
    Yj=[]
    vehicle_pt_obj_now=transform_vehicle_co_ordinates(vehicle_pt_obj_act,[X[i],Y[i]], Theta[i])
    rev=vehicle_pt_obj_now.input_co_ordinates
    revI=rev[:4]
    revL=rev[4:]
    revF=np.concatenate([revI,revL[::-1]])
    l=np.append(revF,[revF[0]],axis=0)
    for i in l:
      Xj.append(i[0])
      Yj.append(i[1])
    plt.plot(Xj,Yj)
  plt.plot(X,Y, color='black')
  X=[]
  Y=[]
  for i in range(len(get_value.GRID_TEST)):
    for j in range(len(get_value.GRID_TEST[0])):
      if(get_value.GRID_TEST[i][j]==1):
          X.append(i)
          Y.append(j)
  plt.scatter(X,Y)
  plt.show()


get_value=values(0,0,0,np.array([]),[])
vehicle_state=vehicle_params(constant.present_lane,constant.goal_lane,constant.present_state)


if __name__== "__main__":
  rospy.init_node( 'behavioural_planner', anonymous=True)      
  #sub_compasss = rospy.Subscriber('/compass_angle', Float64, compass)
  #sub_gps = rospy.Subscriber('/fix', NavSatFix, localization)
  rospy.Subscriber('/local_map', OccupancyGrid, feed_map)
  rospy.Subscriber('/gps_transform', TransformStamped, trigger_behaviour_planning)
  #print('I')
  
  rospy.spin()