#!/usr/bin/env python
import datetime


from weather import Weather, Unit
weather = Weather(unit=Unit.CELSIUS)

lookup = weather.lookup_by_location('Mysore')
condition = lookup.condition
today = datetime.datetime.now()
#print(today.strftime("%A, %d %b %Y, %I:%M %p IST"))
display_date = today.strftime("%A, %d %b %Y, Mysore")
print(display_date)
deg = u"\u2103"
display_weather = "Weather: " + condition.temp+deg+"  " + condition.text
print display_weather



# import webbrowser

# webbrowser.open("https://www.google.com")

# import os
# os.system("xdg-open https://www.google.com")
