#!/usr/bin/env python
from sensor_msgs.msg import Imu
import rospy
import numpy as np
import tf

def callback(msg):
    eul=tf.transformations.euler_from_quaternion(msg.orientation)
    print(eul[0],eul[1],eul[2])

if __name__== "__main__":

    rospy.init_node( 'quater', anonymous=True) 
    rospy.Subscriber('/mavros/imu/data', Imu, callback)
    rospy.spin()
  