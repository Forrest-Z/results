import numpy as np
from scipy.spatial import KDTree




### INPUT VEHICLE CO-ORDINATES
class vehicle_points():
  def __init__(self,input_co_ordinates,center):
    self.input_co_ordinates=input_co_ordinates
    self.center=center

def get_way_point_tree_list(waypoint_list):
  waypoint_tree_list=[]
  for lane_waypoints in waypoint_list:
    re_created_wp=[[w[0],w[1]] for w in lane_waypoints]
    waypoints_tree=KDTree(re_created_wp)
    waypoint_tree_list.append(waypoints_tree)
  return waypoint_tree_list

def cut_gps(x, n=0):
    waypoints = []
    for i in range(0,len(x), n):
        # waypoints.append([x[i][0],x[i][1], x[i][2]])
        #waypoints.append([x[i][0],x[i][1],x[i][2],x[i][3],x[i][4],x[i][5],x[i][6]])
        waypoints.append([x[i][0],x[i][1],x[i][2]])
    #print("Wow:",len(waypoints))
    return waypoints

def read_waypoints():
  #lane_1 = np.load('/home/stgat/graph/Final/lane_data/kud.npy') 
  lane_1 = np.load('/home/stgat/graph/Final/lane_data/sdb2-lane-0.npy') 
  lane_2 = np.load('/home/stgat/graph/Final/lane_data/sdb2-lane-1.npy')
  waypoints_lane_1 = cut_gps(lane_1,1 )
  waypoints_lane_2 = cut_gps(lane_2,1 )
  waypoints_list = [waypoints_lane_1,waypoints_lane_2]
  waypoint_tree_list=get_way_point_tree_list(waypoints_list)
  return waypoints_list,waypoint_tree_list

# def read_waypoints():
#   lane_1 = np.load('/home/stgat/graph/Final/lane_data/kudoos.npy')
#   waypoints_lane_1 = cut_gps(lane_1,1 )
#   waypoints_list = [waypoints_lane_1]
#   waypoint_tree_list=get_way_point_tree_list(waypoints_list)
#   return waypoints_list,waypoint_tree_list


  
#waypoint_list=[[[65,1,np.pi/2],[65,2,np.pi/2],[65,3,np.pi/2]],[[4,1,np.pi/2],[4,2,np.pi/2],[4,3,np.pi/2]]]  
#waypoint_tree_list=get_way_point_tree_list(waypoint_list)
# vehicle_pt_obj_actual = vehicle_points( np.array([[0.5,-3.5],[0.5,-2.5],[0.5,-1.5],[0.5,-0.5],[0.5,0.5],
#                                                   [0.5,1.5],[0.5,2.5],[0.5,3.5],[0.5,4.5],[0.5,5.5],
#                                                   [0.5,6.5],[0.5,7.5],
                                                  
#                                                   [1.5,-3.5],[1.5,-2.5],[1.5,-1.5],
#                                                   [1.5,-0.5],[1.5,0.5],[1.5,1.5],[1.5,2.5],[1.5,3.5],
#                                                   [1.5,4.5],[1.5,5.5],[1.5,6.5],[1.5,7.5]]),
                                                  
#                                                   [0,2] )

# vehicle_pt_obj_actual = vehicle_points( np.array([[0,1],[0,2],[0,3],[0,4],
#                                                  [0,-1],[0,-2],[0,-3],[0,-4],[0,-5]]),
                                                  
#                                                   [0,0] )

vehicle_pt_obj_actual = vehicle_points( np.array([[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],
                                                 [0,-1],[0,-2],[0,-3],[0,-4],[0,-5], [0,-6],[0,-7],[0,-8]]),
                                                  
                                                  [0,0] )

lane_direction = {"PLCL": 0, "LCL": -1, "LCR": 1, "PLCR": 0,"KL":0,"STOP":None,"STAY":0}
offset_value=25
present_lane=0
goal_lane=0
present_state="KL"
multiple_check_frames=12
wait_time = 8
minimum_count_obstacle_taken=20
cte_offset=0.8


##############################################################################
waypoints_list,waypoint_tree_list=read_waypoints()
angle = np.deg2rad(270)