# for python 3.6 and qtconsole 4.3.1
# from PyQt5.QtWebEngineWidgets import QWebEngineView as QWebView,QWebEnginePage as QWebPage
# from PyQt5.QtWebEngineWidgets import QWebEngineSettings as QWebSettings

from PyQt5.QtWebKitWidgets import *   # for python 2.7 with ROS
# from PyQt5.QtCore import pyqtSlot, QUrl
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QWidget, QAction, QTabWidget,QVBoxLayout, QHBoxLayout, QProgressBar, QDial
from PyQt5.QtWidgets import *
# from PyQt5.QtGui import QIcon
from PyQt5.QtGui import *

import rospy
from std_msgs.msg import String
import sys

from PyQt_GUI_tab1 import *  #, PyQt_GUI_tab2, PyQt_GUI_tab3, PyQt_GUI_tab4

 
class App(QMainWindow):
 
    def __init__(self):
        super(App, self).__init__()
        # super().__init__()
        self.title = 'Golf Cart'
        self.left = 0
        self.top = 0
        self.width = 300
        self.height = 200
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
    
        
        self.table_widget = MyTableWidget(self)
        self.setCentralWidget(self.table_widget)

        self.setGeometry(70, 50, 1100, 700)
        self.show()
 
class MyTableWidget(QWidget):        
 
    def __init__(self, parent):   
        super(QWidget, self).__init__(parent)
        self.layout = QVBoxLayout(self)

        # Initialize tab screen
        self.tabs = QTabWidget()
        self.tab1 = QWidget_Tab1()	
        self.tab2 = QWidget()
        # self.tabs.resize(300,200) 
        self.tab3 = QWidget()
        self.tab4 = QWidget()
        self.tabs.resize(500,1100) 
        
        # Add tabs
        self.tabs.addTab(self.tab1,"GPS tracking")
        self.tabs.addTab(self.tab2,"Admin")
        self.tabs.addTab(self.tab3,"Tour")
        self.tabs.addTab(self.tab4,"Sensor Visual")

         # Create second tab
        self.tab2.layout = QVBoxLayout(self)
        self.pushButton1 = QPushButton("PyQt5 button")
        self.tab2.layout.addWidget(self.pushButton1)
        self.tab2.setLayout(self.tab2.layout)
        
        # Add tabs to widget        
        self.layout.addWidget(self.tabs)

        self.setLayout(self.layout)
 





def status_callback(status, ex):
    global gcart_status
    # print("in topic call back: ", status.)
    print("in topic call back: ", status.data)                
    if status.data =="IDLE":
        gcart_status="IDLE"
    elif status.data =="TO_PICKUP_POINT":
        gcart_status="TO_PICKUP_POINT"
    elif status.data =="WAITING":
        gcart_status="WAITING"
    elif status.data =="TO_DESTINATION":
        gcart_status="TO_DESTINATION"
    elif status.data =="REACHED_DESTINATION":
        gcart_status="REACHED_DESTINATION" 
    
    ex.table_widget.tab1.button_img_update(gcart_status) 


if __name__ == '__main__':
    try:
        gcart_status= "IDLE"
        rospy.init_node('golf_cart_GUI')
        # rospy.Subscriber("/gcart_status",String, status_callback)
        GUI_to_Cart_topic_handle = rospy.Publisher("/gui_to_gcart",String, queue_size=1, latch=True )
        rate =rospy.Rate(2)

        app = QApplication(sys.argv)
        ex = App()
        rospy.Subscriber("/gcart_status",String, status_callback, ex)
        
        sys.exit(app.exec_())

        # ex.table_widget.button_image = QIcon('04_Cart_IDEL.png')

    except rospy.ROSInterruptException:
        pass
            